"""hostio byte-stream client -- ``docs/contracts/net-protocol.md`` TCP 6931 / 6933 (v0.20).

    6931 TCP  hostio CH1 (USRT1) -- raw byte stream (the DUT's second UART)
    6933 TCP  hostio CH0 (ADP)   -- raw byte stream (the Advanced Debug Protocol)

The sibling of :class:`pyverify.console.ConsoleReader` and built on it (same
buffered ``read_until`` / ``assert_contains``), with two differences that are the
contract's: writes are NOT paced (hostio4 carries its own flow control, ``ioack``;
the 20 ms/char of the UART consoles would only slow ADP down), and a connection
the board refuses on a CLAIMED board -- ONE JSON line
``{"ok":false,"err":"hostio locked: ...","code":"locked"}`` then the close, exactly
like XVC -- raises :class:`HostioLocked` instead of looking like an empty stream.
The mode (console / hostio4) is set with ``ShellClient.hostio_set_mode``; in console
mode the channels are idle.
"""
from __future__ import annotations

import json
import socket
from dataclasses import dataclass
from typing import Optional

from .console import ConsoleReader
from .mint4 import HOSTIO_ADP_PORT, HOSTIO_USRT1_PORT

__all__ = ["HOSTIO_USRT1_PORT", "HOSTIO_ADP_PORT", "HostioLocked", "HostioStream"]


class HostioLocked(ConnectionError):
    """The board is claimed and this peer is not the board itself (use ssh)."""

    def __init__(self, line: bytes) -> None:
        self.reply: dict = {}
        try:
            self.reply = json.loads(line)
        except ValueError:
            pass
        super().__init__(self.reply.get("err", "hostio locked: board claimed (use ssh)"))


_LOCK_PREFIX = b'{"ok":false'


@dataclass
class HostioStream(ConsoleReader):
    """A hostio channel: ``HostioStream(host, HOSTIO_ADP_PORT)`` or
    :meth:`usrt1` / :meth:`adp`. ``pace_s`` defaults to 0 (unpaced)."""

    pace_s: float = 0.0

    def _check_lock(self, chunk_or_eof: bytes) -> None:
        buf = bytes(self._buf)
        if buf.startswith(_LOCK_PREFIX) and b"\n" in buf:
            line = buf.split(b"\n", 1)[0]
            if b'"code":"locked"' in line:
                raise HostioLocked(line)

    def read_until(self, pattern: bytes, *, timeout: Optional[float] = None) -> bytes:
        try:
            return super().read_until(pattern, timeout=timeout)
        except (TimeoutError, ConnectionError):
            self._check_lock(b"")
            raise

    def read_exact(self, n: int, *, timeout: Optional[float] = None) -> bytes:
        """Exactly ``n`` bytes (an ADP reply is a fixed-size frame), or
        ``TimeoutError`` / ``ConnectionError`` / :class:`HostioLocked`."""
        import time
        sock = self._require_connected()
        deadline = time.monotonic() + (timeout if timeout is not None else self.timeout)
        while len(self._buf) < n:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                self._check_lock(b"")
                raise TimeoutError(f"wanted {n} bytes, got {len(self._buf)}")
            sock.settimeout(remaining)
            try:
                chunk = sock.recv(4096)
            except socket.timeout:              # (not a TimeoutError before Python 3.10)
                self._check_lock(b"")
                raise TimeoutError(f"wanted {n} bytes, got {len(self._buf)}") from None
            if not chunk:
                self._check_lock(b"")
                raise ConnectionError("hostio stream closed by the board")
            self._buf.extend(chunk)
            if len(self._buf) >= len(_LOCK_PREFIX):
                self._check_lock(b"")
        out = bytes(self._buf[:n])
        del self._buf[:n]
        return out

    def write(self, data: bytes, *, pace_s: "float | None" = None, sleep=None) -> int:  # type: ignore[override]
        """Send ``data`` as is (unpaced unless a ``pace_s`` is given)."""
        sock = self._require_connected()
        sock.settimeout(self.timeout)
        if pace_s:
            import time
            from .console import send_paced
            return send_paced(sock, data, pace_s, sleep=sleep or time.sleep)
        sock.sendall(data)
        return len(data)

    @classmethod
    def usrt1(cls, host: str, **kwargs: object) -> "HostioStream":
        return cls(host, HOSTIO_USRT1_PORT, **kwargs)  # type: ignore[arg-type]

    @classmethod
    def adp(cls, host: str, **kwargs: object) -> "HostioStream":
        return cls(host, HOSTIO_ADP_PORT, **kwargs)  # type: ignore[arg-type]
