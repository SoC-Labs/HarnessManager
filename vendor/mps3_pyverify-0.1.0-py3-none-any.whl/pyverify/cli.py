"""``python -m pyverify.cli`` — command-line entry point for pyverify.

Wires the concrete :class:`pyverify.pusher.BitstreamPusher` into
:class:`pyverify.swap.SwapOrchestrator` (which itself depends only on the
``Pusher`` protocol — a test seam, see ``swap.py``'s module docstring).
Referenced by ``host/tender/fpgahub_mps3_plugin.py``'s ``platform_deploy``
action (fpgahub shells out to ``python -m pyverify.cli deploy ...`` from a
manifest Action) and by ``host/notebooks/demo.md``.

pyverify is the FRONT DOOR to the board. Everything a board session needs is
a verb here, over ONE dialect each:

    lease acquire|release|cancel|status|heartbeat|preflight
        the fpgahub board lease (:mod:`pyverify.lease`). ``acquire`` prints the
        BARE token on stdout — ``TOKEN=$(pyverify lease acquire …)`` — and its
        progress on stderr, exactly as ``scripts/mps3_board.sh acquire`` did.
    sd write <bundle>
        the config-SD write, under the one-write-wait discipline
        (:mod:`pyverify.sd`).
    ping | version | diag
        the read-only control-channel verbs, over the conformance-pinned
        :class:`~pyverify.client.ShellClient` rather than a hand-rolled socket.
    deploy
        validate -> swap -> push -> await; ``--overlay <dir>`` or the DFX
        prod-dir shape ``--prod <dir> --rm <name>``.

``deploy`` exit codes (all failures are clean one-line stderr messages,
never tracebacks):

    0  swap confirmed by the shell (JSON result on stdout)
    1  the shell/validator rejected the deploy (SwapError /
       OverlayValidationError — e.g. static_id mismatch, swap NAK)
    2  bad overlay manifest (didn't parse / missing keys)
    3  network/transport failure — shell unreachable, control-channel
       connect refused, TFTP/raw-TCP push timeout or server abort

The other verbs use the same three codes: 0 ok, 1 the far end refused (a gate,
a lease that is not ours, an md5 mismatch), 3 the far end is unreachable or
unconfigured (no ``MPS3_HUB``, control channel refused).

The ``edge`` verb group (``edge channels`` / ``edge status``) is the CLI
front-end for :mod:`pyverify.edge` — the MPS3 Edge Device API model
(``docs/HARDWARE_HUB_INTEGRATION.md``). ``edge channels`` needs no network
at all (the channel table is static per-board shape, not live state).
``edge status`` optionally opens a real :class:`~pyverify.client.ShellClient`
against ``--host`` to pull ``rp`` truth (``{"op":"ping"}`` -> ``rm_id``,
net-protocol.md); omitting ``--host`` reports an honest "no shell reachable"
status (``rp.loaded: false``) instead of guessing, exactly like
:meth:`pyverify.edge.EdgeDeviceApi.status_fpga` does when ``shell=None``.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from .client import ShellClient
from .edge import EdgeDeviceApi, channel_to_dict, fpga_status_to_dict
from .fielded import FieldedError, overlay_from_prod_dir
from .lease import Lease, LeaseClient, LeaseError, hub_runner_from_env
from .overlay import Overlay, OverlayManifestError, OverlayValidationError
from .pusher import DEFAULT_ACK_WINDOW, RAW_TCP_PORT, TFTP_PORT, BitstreamPusher, PushError
from .swap import Pusher, SwapError, SwapOrchestrator


def _build_pusher(
    host: str,
    transport: str,
    *,
    tftp_port: int = TFTP_PORT,
    tcp_port: int = RAW_TCP_PORT,
    windowed: bool = False,
    window: int = DEFAULT_ACK_WINDOW,
) -> Pusher:
    return BitstreamPusher(
        host=host, transport=transport,  # type: ignore[arg-type]
        tftp_port=tftp_port, tcp_port=tcp_port,
        windowed=windowed, window=window,
    )


def _resolve_deploy_overlay(args: argparse.Namespace) -> Overlay:
    """``--overlay <dir>`` (overlay-manifest.md layout) or ``--prod <dir> --rm
    <name>`` (the DFX prod-dir shape: static_id.txt + overlay_inputs.txt).

    The second form is what ``scripts/mps3_push.py`` used to parse inline
    beside its own copy of the framing and the sockets; reading it through
    :func:`pyverify.fielded.overlay_from_prod_dir` means the ONE pusher drives
    both artefact shapes."""
    if args.overlay:
        return Overlay.load(Path(args.overlay))
    if not (args.prod and args.rm):
        raise OverlayManifestError(
            "need --overlay <dir>, or --prod <dir> together with --rm <name>")
    return overlay_from_prod_dir(Path(args.prod), args.rm)


def _cmd_deploy(args: argparse.Namespace) -> int:
    try:
        overlay = _resolve_deploy_overlay(args)
    except (OverlayManifestError, FieldedError) as exc:
        print(f"deploy: bad overlay manifest: {exc}", file=sys.stderr)
        return 2

    pusher = _build_pusher(
        args.host, args.pusher_transport,
        tftp_port=args.tftp_port, tcp_port=args.tcp_push_port,
        windowed=args.windowed, window=args.window,
    )
    client = ShellClient(args.host, port=args.control_port,
                         timeout=args.client_timeout)
    try:
        with client:
            orchestrator = SwapOrchestrator(client, pusher)
            result = orchestrator.deploy(overlay, rm_slot=args.rm_slot, src=args.src)
    except (SwapError, OverlayValidationError) as exc:
        print(f"deploy: {exc}", file=sys.stderr)
        return 1
    except (PushError, OSError) as exc:
        # OSError covers the control-channel socket (connection refused/
        # timed out/unreachable); PushError wraps the same class of
        # failure inside the TFTP/raw-TCP push. Either way: a clean
        # message + exit 3, not a traceback.
        what = (
            "bitstream push failed"
            if isinstance(exc, PushError)
            else f"cannot reach shell control channel at {args.host}:{args.control_port}"
        )
        print(f"deploy: {what}: {exc}", file=sys.stderr)
        return 3

    print(json.dumps({
        "ok": True,
        "rm_id": result.rm_id,
        "verified": result.verified,
        "ltx_path": result.reattach.ltx_path,
    }))
    return 0


def _cmd_display(args: argparse.Namespace) -> int:
    """Flip (or query) the on-board CLCD panel owner over the 6900 control
    channel (net-protocol.md ``display``). ``owner`` omitted => query.

    ``--confirm`` waits for the handover to COMMIT instead of reporting the
    send-now reply. The distinction is not cosmetic: `display` answers with
    ``CLCDKVM.STATUS.owner``, the committed owner, and a flip takes a drain ->
    panel reset -> settle -> grant (~7-9 ms), so the reply to a flip routinely
    names the owner that is going AWAY (net-protocol.md "Display" says so, and
    ends "a client confirms the landing with a follow-up query"). Without
    ``--confirm`` this verb prints that reply verbatim, which is the honest
    wire truth and is exactly what you do NOT want to paste into a bring-up log
    as evidence that the DUT got the panel.

    Exit codes mirror ``deploy``'s discipline (clean one-line stderr, never a
    traceback): 0 = ok, 1 = the shell declined the verb (``ok:false`` — e.g.
    ``clcd_kvm not present`` on a pre-Wave-4 bitstream, or a bad owner), 3 =
    the control channel is unreachable. Under ``--confirm`` a request the shell
    ACCEPTED but that did not commit inside ``--timeout`` exits **2**: that is
    INCONCLUSIVE, not a failure, and it must not be reported as either a
    landed flip (0) or a refusal (1). docs/CLCD_KVM_PLAN.md "Proving it" keys
    the board procedure on exactly that distinction.
    """
    client = ShellClient(args.host, port=args.control_port)
    try:
        with client:
            if args.owner is None:
                resp = client.display_owner()
            elif args.confirm:
                settled = client.display_settled(
                    args.owner, timeout=args.timeout,
                    interval=args.poll_interval)
                print(json.dumps({
                    "ok": settled.ok,
                    "requested": settled.requested,
                    "owner": settled.owner,
                    "landed": settled.landed,
                    "polls": settled.polls,
                    "waited_s": round(settled.waited_s, 3),
                    "err": settled.err,
                }))
                if not settled.ok:
                    return 1
                return 0 if settled.landed else 2
            else:
                resp = client.display(args.owner)
    except OSError as exc:
        print(
            f"display: cannot reach shell control channel at "
            f"{args.host}:{args.control_port}: {exc}",
            file=sys.stderr,
        )
        return 3

    print(json.dumps({"ok": resp.ok, "owner": resp.owner, "err": resp.err}))
    return 0 if resp.ok else 1


def _cmd_edge_channels(args: argparse.Namespace) -> int:
    api = EdgeDeviceApi(board=args.board)
    channels = [channel_to_dict(c) for c in api.enumerate_channels()]
    print(json.dumps({"board": args.board, "channels": channels}, indent=2))
    return 0


def _cmd_edge_status(args: argparse.Namespace) -> int:
    shell: ShellClient | None = None
    if args.host:
        # Real socket open, mirroring _cmd_deploy above.
        shell = ShellClient(args.host, port=args.control_port)
        try:
            shell.connect()
        except OSError as exc:
            print(
                f"edge status: cannot reach shell control channel at "
                f"{args.host}:{args.control_port}: {exc}",
                file=sys.stderr,
            )
            return 3
    try:
        api = EdgeDeviceApi(board=args.board, shell=shell)
        status = api.status_fpga()
    finally:
        if shell is not None:
            shell.close()

    print(json.dumps(fpga_status_to_dict(status), indent=2))
    return 0


# --------------------------------------------------------------------------- #
# lease — the fpgahub board lease, one dialect (pyverify.lease)
# --------------------------------------------------------------------------- #


def _lease_client(args: argparse.Namespace) -> LeaseClient:
    runner = getattr(args, "_runner", None) or hub_runner_from_env()
    return LeaseClient(runner, chassis=args.chassis, target=args.target)


def _holder(args: argparse.Namespace) -> "str | None":
    return args.holder or os.environ.get("MPS3_LEASE_HOLDER")


def _cmd_lease(args: argparse.Namespace) -> int:
    """Every lease verb, sharing one error discipline: a hub that is not
    configured or not reachable is exit 3, a hub that REFUSED is exit 1, and
    neither is ever a traceback."""
    try:
        client = _lease_client(args)
    except LeaseError as exc:
        print(f"lease: {exc}", file=sys.stderr)
        return 3

    verb = args.lease_verb
    try:
        if verb == "acquire":
            holder = _holder(args) or _default_holder()
            lease = client.acquire(
                holder, ttl=args.ttl, tier=args.tier,
                poll_s=args.poll, timeout_s=args.acquire_timeout,
                allow_preemptible=args.allow_preemptible,
                log=lambda m: print(m, file=sys.stderr),
            )
            # ONLY the token on stdout: TOKEN=$(pyverify lease acquire ...).
            print(lease.token)
            return 0
        if verb == "release":
            client.release(args.token, holder=_holder(args) or _default_holder())
            print("released")
            return 0
        if verb == "cancel":
            holder = _holder(args) or _default_holder()
            removed = client.cancel(holder)
            print("cancelled" if removed else "no matching wait to cancel")
            return 0
        if verb == "heartbeat":
            client.heartbeat(args.token, holder=_holder(args) or _default_holder(),
                             ttl=args.ttl)
            print("extended")
            return 0
        if verb == "status":
            st = client.status()
            print(json.dumps({"board": client.chassis, "held": st.held,
                              "holder": st.holder, "user": st.user,
                              "raw": st.raw}))
            return 0
        if verb == "preflight":
            holder = _holder(args)
            if client.preflight(holder):
                print(f"preflight OK: {client.chassis} is unheld or held by us")
                return 0
            st = client.status()
            print(
                f"preflight REFUSE: {client.chassis} held by {st.holder} -- do "
                f"not touch the board (no bitstream load, no xsdb stop, no 6910 "
                f"stream)", file=sys.stderr)
            return 1
    except LeaseError as exc:
        print(f"lease {verb}: {exc}", file=sys.stderr)
        return 1
    raise AssertionError(f"unhandled lease verb {verb!r}")  # pragma: no cover


def _default_holder() -> str:
    """A holder that identifies THIS run. Never a bare hostname: several agents
    share one host and one unix user, and "held by me" must not be guessable
    from the user alone (that mistake clobbered a live board once)."""
    import socket as _sock
    return "%s-%s-%d" % (
        os.environ.get("USER", "user"), _sock.gethostname().split(".")[0], os.getpid())


# --------------------------------------------------------------------------- #
# sd — the config-SD write (pyverify.sd)
# --------------------------------------------------------------------------- #


def _cmd_sd_write(args: argparse.Namespace) -> int:
    from .sd import SdWriteError, SdWriter

    try:
        runner = getattr(args, "_runner", None) or hub_runner_from_env()
        lease = LeaseClient(runner, chassis=args.chassis, target=args.target)
    except LeaseError as exc:
        print(f"sd write: {exc}", file=sys.stderr)
        return 3

    writer = SdWriter(
        runner, lease=lease, target=lease.target, wait_s=args.wait,
        state_dir=args.state_dir, log=lambda m: print(m, file=sys.stderr),
    )
    try:
        result = writer.write(
            args.bundle,
            holder=_holder(args) or _default_holder(),
            lease=(Lease(token=args.token, holder=_holder(args) or _default_holder(),
                         target=lease.target) if args.token else None),
            backup_dir=args.backup,
            require_backup=not args.no_backup,
            verify_path=args.verify_path,
            force=args.force,
        )
    except SdWriteError as exc:
        print(f"sd write: {exc}", file=sys.stderr)
        return 1
    except LeaseError as exc:
        print(f"sd write: {exc}", file=sys.stderr)
        return 3

    print(json.dumps({
        "ok": result.ok,
        "bundle": str(result.bundle),
        "target": result.target,
        "timed_out": result.timed_out,
        "waited_s": result.waited_s,
        "verified": result.verified,
        "verify_reason": result.verify_reason,
        "md5": result.md5,
        "fielded": result.fielded,
    }))
    return 0


# --------------------------------------------------------------------------- #
# ping / version / diag — the read-only control-channel verbs
# --------------------------------------------------------------------------- #


def _shell_read(args: argparse.Namespace, call, label: str):
    """Open the control channel, run one read-only verb, close. Exit 3 on an
    unreachable shell, exactly like ``deploy``."""
    client = ShellClient(args.host, port=args.control_port, timeout=args.timeout)
    try:
        with client:
            return call(client)
    except OSError as exc:
        print(
            f"{label}: cannot reach shell control channel at "
            f"{args.host}:{args.control_port}: {exc}",
            file=sys.stderr,
        )
        return None


def _cmd_ping(args: argparse.Namespace) -> int:
    """``{"op":"ping"}`` -> shell_id / rm_id.

    Replaces ``scripts/harness_gates/ping_check.py``'s hand-rolled socket. The
    ``--line`` form keeps that gate's exact ``shell_id=… rm_id=…`` stdout, which
    ``scripts/harness_regression.sh`` reads."""
    resp = _shell_read(args, lambda c: c.ping(), "ping")
    if resp is None:
        return 3
    if args.line:
        print(f"shell_id={resp.shell_id} rm_id={resp.rm_id}")
    else:
        print(json.dumps({"ok": resp.ok, "shell_id": resp.shell_id,
                          "rm_id": resp.rm_id}))
    return 0 if resp.shell_id else 1


def _cmd_version(args: argparse.Namespace) -> int:
    """``version`` -> the FIRMWARE identity. ``ping`` cannot give this: one
    static_id serves many harness releases (a firmware-only bump re-bakes the
    bitstream via updatemem without changing the static routing), so a board can
    report the expected static_id and still run an image built with the wrong
    flags (client.py's VersionResponse)."""
    resp = _shell_read(args, lambda c: c.version(), "version")
    if resp is None:
        return 3
    print(json.dumps({
        "ok": resp.ok, "harness": resp.harness, "ver32": resp.ver32,
        "sha": resp.sha, "dirty": resp.dirty, "lmb_kb": resp.lmb_kb,
        "features": list(resp.features),
    }))
    return 0 if resp.ok else 1


def _cmd_diag(args: argparse.Namespace) -> int:
    """``diag`` -> the always-on counters. NOTE 6900 is PARKED during a swap, so
    this is an idle-time verb; during a swap read the same counters from the
    DMEM mailbox over JTAG-MDM."""
    resp = _shell_read(args, lambda c: c.diag(), "diag")
    if resp is None:
        return 3
    from dataclasses import asdict
    print(json.dumps(asdict(resp)))
    return 0 if resp.ok else 1



def _cmd_dut_eth(args: argparse.Namespace) -> int:
    """``dutrx`` -> the frames the DUT TRANSMITTED (net-protocol.md v0.10).

    The other half of DUT ethernet. Reception has been silicon-proven since
    2026-07-30; the return path did not exist until the capture block was
    written, so a DUT could be talked to and could not answer.

    Reads up to --frames whole frames (following `more` across 256-byte chunks),
    stopping early when the FIFO is empty, and always prints the DROP COUNTERS
    beside them: the block cannot backpressure the
    bridge, so it drops, and `rx + drop_full + drop_giant` is the only place a
    lossy capture shows up. Reading zero frames is a RESULT, not a failure --
    an idle DUT looks exactly like that -- so it exits 0; a DECLINED verb
    ("dut_egress not present": a bitstream with no capture block) exits 1.
    """
    if args.frames < 1:
        print(f"dut-eth: --frames must be >= 1, got {args.frames}", file=sys.stderr)
        return 2

    def read(client):
        frames = []
        last = None
        for _ in range(args.frames):
            frame, last = client.read_dut_frame()
            if frame is None:
                break       # FIFO empty (or the verb declined) -- a result
            frames.append(frame)
            if last.frames == 0:
                break       # nothing else waiting; never spin on an idle FIFO
        return frames, last

    result = _shell_read(args, read, "dut-eth")
    if result is None:
        return 3
    frames, last = result
    if last is None:                      # pragma: no cover - frames >= 1 always reads
        return 3
    out = {
        "ok": last.ok,
        "frames_read": len(frames),
        "waiting": last.frames,
        "rx": last.rx,
        "drop_full": last.drop_full,
        "drop_giant": last.drop_giant,
        "ovf": last.ovf,
        "desync": last.desync,
    }
    if not last.ok:
        out["err"] = last.err
    else:
        out["frames"] = [{"len": len(f), "hex": f.hex()} for f in frames]
    print(json.dumps(out))
    return 0 if last.ok else 1


# --------------------------------------------------------------------------- #
# boot-rate — measure the MCC-config-from-SD boot lottery (pyverify.bootrate)
# --------------------------------------------------------------------------- #


def _cmd_boot_rate(args: argparse.Namespace) -> int:
    """Run a campaign, or compare two of them, or print the record schema.

    Exit codes follow the file's discipline: 0 the campaign ran (a 0% boot rate
    is a RESULT, not a failure), 1 a gate refused (no lease, `--method mcc`), 2
    bad input (unknown variant, unreadable record), 3 the hub is unreachable or
    unconfigured.
    """
    from . import bootrate as br

    verb = getattr(args, "boot_verb", None)
    if verb == "schema":
        print(json.dumps(br.RUN_RECORD_SCHEMA, indent=2))
        return 0
    if verb == "compare":
        try:
            before = br.load_record(args.before)
            after = br.load_record(args.after)
            result = br.compare(before, after)
        except br.BootRateInputError as exc:
            print(f"boot-rate compare: {exc}", file=sys.stderr)
            return 2
        print(json.dumps(result, indent=2) if args.json
              else br.format_compare(result))
        return 0

    # -- a campaign ---------------------------------------------------------- #
    if not args.host:
        print("boot-rate: --host <board-ip> is required (the ping probe is how "
              "a boot is counted). `boot-rate compare`/`schema` need no board.",
              file=sys.stderr)
        return 2
    try:
        br.check_method(args.method)            # refused BEFORE anything, dry run included
        delta = br.variant_delta(args.variant) if args.variant else None
    except br.BootRateError as exc:
        print(f"boot-rate: {exc}", file=sys.stderr)
        return 1
    except br.BootRateInputError as exc:
        print(f"boot-rate: {exc}", file=sys.stderr)
        return 2

    holder = _holder(args)
    plan = [
        "boot-rate plan:",
        f"  board        : {args.chassis or 'MPS3_CHASSIS/default'} "
        f"(lease target {args.target or 'MPS3_LEASE_TARGET/default'})",
        f"  holder       : {holder or '(NOT SET -- required)'}",
        f"  shell        : {args.host}:{args.control_port}",
        f"  iterations   : {args.n}",
        f"  reset method : {args.method}",
        f"  deadline     : {args.deadline}s per boot (poll {args.poll}s, "
        f"gap {args.gap}s, down-window {args.down_deadline}s)",
        f"  SD variant   : {args.variant or '(none -- default bundle)'}",
    ]
    if delta:
        plan.append(f"                 {delta['description']}")
        for fname, keys in sorted(delta["keys"].items()):
            for key, value in sorted(keys.items()):
                plan.append(f"                 {fname}: {key} -> {value}")
    plan += [
        f"  MCC log      : {args.mcc_log or '(none -- mcc_log_sha will be null)'}",
        f"  witness      : {args.witness_cmd or '(none -- JTAG DONE/USERCODE not used)'}",
        f"  output       : {args.out or '(stdout summary only)'}",
        "",
        "  The SD must ALREADY carry this variant: this tool measures the card "
        "in the board, it does not write one.",
        "  Assemble + write it with: fpga/mps3_sd/assemble_sd.sh C <bit> "
        f"--variant {args.variant or '<NAME>'}  ->  pyverify sd write",
    ]
    if args.dry_run:
        print("\n".join(plan))
        print("\n(dry run: nothing was contacted, nothing was written)")
        return 0

    try:
        runner = getattr(args, "_runner", None) or hub_runner_from_env()
        lease = LeaseClient(runner, chassis=args.chassis, target=args.target)
    except LeaseError as exc:
        print(f"boot-rate: {exc}", file=sys.stderr)
        return 3

    witness = br.CommandWitness(args.witness_cmd) if args.witness_cmd else None
    runner_obj = br.BootRateRunner(
        probe=br.ShellProbe(args.host, port=args.control_port,
                            timeout=args.probe_timeout),
        resetter=br.HubResetter(runner, target=lease.target),
        lease=lease, holder=holder, runner=runner,
        mcc_log_path=args.mcc_log, witness=witness,
        host=args.host, control_port=args.control_port,
        log=lambda m: print(m, file=sys.stderr),
    )
    print("\n".join(plan), file=sys.stderr)
    try:
        record = runner_obj.run(
            n=args.n, method=args.method, deadline_s=args.deadline,
            poll_s=args.poll, gap_s=args.gap,
            down_deadline_s=args.down_deadline, await_down=not args.no_await_down,
            variant=args.variant, token=args.token,
            notes=(args.note or []),
        )
    except br.BootRateError as exc:
        print(f"boot-rate: {exc}", file=sys.stderr)
        return 1
    except br.BootRateInputError as exc:
        print(f"boot-rate: {exc}", file=sys.stderr)
        return 2
    except LeaseError as exc:
        print(f"boot-rate: {exc}", file=sys.stderr)
        return 3

    if args.out:
        Path(args.out).write_text(json.dumps(record, indent=2) + "\n")
        print(f"boot-rate: run record written to {args.out}", file=sys.stderr)
    print(json.dumps(record["summary"], indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pyverify", description=__doc__)
    sub = parser.add_subparsers(dest="verb", required=True)

    deploy = sub.add_parser("deploy", help="validate -> swap -> push -> await an overlay onto a shell")
    deploy.add_argument("--host", required=True, help="shell host/IP (net-protocol.md)")
    deploy.add_argument("--overlay", default=None,
                        help="overlay directory (overlay-manifest.md layout)")
    deploy.add_argument("--prod", default=None,
                        help="DFX prod dir (static_id.txt + overlay_inputs.txt); "
                             "use with --rm. Defaults come from "
                             "pyverify.fielded, never from a hardcoded build dir")
    deploy.add_argument("--rm", default=None,
                        help="RM name inside --prod, e.g. regdemo_b")
    deploy.add_argument("--rm-slot", type=int, default=0, dest="rm_slot")
    deploy.add_argument("--src", default="tftp", choices=("tftp", "tcp"))
    deploy.add_argument(
        "--pusher-transport", default="tftp", choices=("tftp", "tcp"), dest="pusher_transport",
    )
    deploy.add_argument("--control-port", type=int, default=6900, dest="control_port")
    # A REAL shell (HWICAP FIFO mode + fire-and-hose off) needs BOTH the tcp
    # transport AND the windowed handshake, or the push starves the
    # single-threaded MicroBlaze and the connection resets. Proven on silicon
    # 2026-07-17. The defaults stay tftp/non-windowed only because the FakeShell
    # E2E double models neither FIFO mode nor window grants; for the KU115 use:
    #   --pusher-transport tcp --src tcp --windowed
    deploy.add_argument("--windowed", action="store_true",
                        help="tcp only: use the lock-step window-grant handshake "
                             "(REQUIRED for the real board; see net-protocol.md / "
                             "OVER_THE_WIRE_DEPLOY_STATUS.md).")
    deploy.add_argument("--window", type=int, default=DEFAULT_ACK_WINDOW,
                        help=f"windowed ACK window in bytes (default "
                             f"{DEFAULT_ACK_WINDOW}); MUST equal the shell BSP tcp_wnd.")
    deploy.add_argument("--client-timeout", type=float, default=180.0,
                        dest="client_timeout",
                        help="control-channel timeout (s). The shell parks the "
                             "6900 connection for the WHOLE reconfiguration, so "
                             "the 5 s ShellClient default cannot survive a real "
                             "swap. Default 180.")
    deploy.add_argument(
        "--tftp-port", type=int, default=TFTP_PORT, dest="tftp_port",
        help="TFTP push port (net-protocol.md default 69); overridable to "
             "target a fake shell on an ephemeral port",
    )
    deploy.add_argument(
        "--tcp-push-port", type=int, default=RAW_TCP_PORT, dest="tcp_push_port",
        help="raw-TCP push port (net-protocol.md default 6910); overridable "
             "to target a fake shell on an ephemeral port",
    )
    deploy.set_defaults(func=_cmd_deploy)

    display = sub.add_parser(
        "display",
        help="flip/query the on-board CLCD panel owner (net-protocol.md 'display')",
    )
    display.add_argument("--host", required=True, help="shell host/IP (net-protocol.md)")
    display.add_argument("--control-port", type=int, default=6900, dest="control_port")
    display.add_argument(
        "owner", nargs="?", default=None, choices=("harness", "dut", "toggle"),
        help="new panel owner; omit to QUERY the current owner (read-only)",
    )
    display.add_argument(
        "--confirm", action="store_true",
        help="wait for the handover to COMMIT (re-query until "
             "CLCDKVM.STATUS.owner is the requested one) instead of printing "
             "the send-now reply, which routinely still names the OUTGOING "
             "owner. Exit 0 = landed, 2 = accepted but not committed in time "
             "(INCONCLUSIVE), 1 = the shell declined.",
    )
    display.add_argument(
        "--timeout", type=float, default=2.0,
        help="--confirm budget in seconds (default 2.0). The hardware handover "
             "is ~7-9 ms; the budget is generous because the path to the board "
             "is a network, not because the KVM is slow.",
    )
    display.add_argument(
        "--poll-interval", type=float, default=0.05, dest="poll_interval",
        help="--confirm re-query interval in seconds (default 0.05)",
    )
    display.set_defaults(func=_cmd_display)

    edge = sub.add_parser(
        "edge", help="MPS3 Edge Device API (docs/HARDWARE_HUB_INTEGRATION.md)",
    )
    edge_sub = edge.add_subparsers(dest="edge_verb", required=True)

    edge_channels = edge_sub.add_parser(
        "channels", help="enumerate.channels — list this board's Channel descriptors",
    )
    edge_channels.add_argument("--board", default="mps3_01", help="board name (e.g. mps3_01)")
    edge_channels.set_defaults(func=_cmd_edge_channels)

    edge_status = edge_sub.add_parser(
        "status", help="status.fpga — two-level shell/rp FpgaStatus",
    )
    edge_status.add_argument("--board", default="mps3_01", help="board name (e.g. mps3_01)")
    edge_status.add_argument(
        "--host", default=None,
        help="shell host/IP for rp truth over the control channel (net-protocol.md); "
             "omit for an offline/no-shell status (rp.loaded reported false)",
    )
    edge_status.add_argument("--control-port", type=int, default=6900, dest="control_port")
    edge_status.set_defaults(func=_cmd_edge_status)

    flash = sub.add_parser(
        "flash",
        help="program the packed MicroPython image onto the board QSPI flash via "
             "the DUT controller over SWD (input: flash_pack.py .bin)",
    )
    flash.add_argument("--image", required=True,
                       help="packed flash image (.bin from firmware/micropython/flash_pack.py)")
    flash.add_argument("--host", default=None,
                       help="shell host/IP; the SWD path reaches the DUT qspi controller (swd.py)")
    flash.add_argument("--hub", default=None,
                       help="fpgahub host to ssh into; omit to run OpenOCD on the local host")
    flash.add_argument("--base", type=lambda x: int(x, 0), default=0,
                       help="flash byte offset to program at (default 0x0)")
    flash.add_argument("--verify-only", action="store_true", dest="verify_only",
                       help="read-back-verify an already-flashed image; no erase/program")
    flash.add_argument("--repo-dir", default=None, dest="repo_dir",
                       help="repo root ON THE EXECUTING HOST (the hub, unless "
                            "--hub is disabled). OpenOCD's cfg paths resolve "
                            "against this, so it must point at a checkout that "
                            "actually exists THERE — the hub does not "
                            "necessarily share the caller's home directory.")
    flash.add_argument("--clk-div", type=int, default=4, dest="clk_div",
                       help="QSPI CLK_DIV (SCLK=HCLK/(2*CLK_DIV)); default 4. "
                            "The controller resets to 1, which garbles RDID on "
                            "silicon, so the host always programs this first.")
    flash.add_argument("--no-verify", action="store_true", dest="no_verify",
                       help="skip the post-program read-back verify (NOT recommended)")
    flash.set_defaults(func=_cmd_flash)

    # ---------------------------------------------------------------------- #
    # lease
    # ---------------------------------------------------------------------- #
    lease_p = sub.add_parser(
        "lease",
        help="fpgahub board lease (docs/internal/MPS3_BOARD_LEASE.md)",
        description="The board is shared and the lease is ADVISORY -- nothing "
                    "gates JTAG or hub-local ethernet today -- so honour it by "
                    "convention. NOTE the two names: `status` addresses the "
                    "CHASSIS (--chassis, default mps3_01) because that is what "
                    "`lease show` accepts; acquire/release/cancel/heartbeat "
                    "address the LEASE TARGET (--target, default mps3_01_pl). "
                    "Both are real; each verb takes exactly one of them.",
    )
    lease_sub = lease_p.add_subparsers(dest="lease_verb", required=True)

    def _lease_common(sp):
        sp.add_argument("--chassis", default=None,
                        help="chassis/board name for `lease show` (env MPS3_CHASSIS)")
        sp.add_argument("--target", default=None,
                        help="lease target for acquire/release/cancel (env "
                             "MPS3_LEASE_TARGET)")
        sp.add_argument("--holder", default=None,
                        help="lease holder (env MPS3_LEASE_HOLDER). Identify "
                             "THIS run: several agents share one unix user, and "
                             "matching on the user alone once cost a live board.")
        sp.set_defaults(func=_cmd_lease)
        return sp

    acq = _lease_common(lease_sub.add_parser(
        "acquire", help="take the lease, BLOCKING through queued responses; "
                        "prints the bare token on stdout"))
    acq.add_argument("--ttl", type=int, default=3600, help="lease TTL (s)")
    acq.add_argument("--tier", default="interactive",
                     choices=("interactive", "background"),
                     help="interactive (default) is NOT revocable; a background "
                          "lease can be pre-empted mid-swap, which is the exact "
                          "corruption the lease exists to prevent")
    acq.add_argument("--allow-preemptible", action="store_true",
                     dest="allow_preemptible",
                     help="required to actually use --tier background")
    acq.add_argument("--poll", type=float, default=20.0,
                     help="seconds between re-acquires while queued. This fpgahub's "
                          "QUEUED response carries no token, so `lease wait` cannot "
                          "be used for the initial FCFS wait -- we re-acquire, which "
                          "keeps FCFS position (the server keys the queue by holder).")
    acq.add_argument("--acquire-timeout", type=float, default=3600.0,
                     dest="acquire_timeout",
                     help="give up after this long AND cancel our queue entry")

    rel = _lease_common(lease_sub.add_parser(
        "release", help="release the lease (needs BOTH --token and --holder)"))
    rel.add_argument("--token", required=True,
                     help="token from acquire. Without a matching --holder the "
                          "hub replies 'no lease to release' and the board stays HELD.")

    can = _lease_common(lease_sub.add_parser(
        "cancel", help="cancel a stray QUEUE entry by holder (no token needed)"))

    hb = _lease_common(lease_sub.add_parser(
        "heartbeat", help="extend the lease during a long operation"))
    hb.add_argument("--token", required=True)
    hb.add_argument("--ttl", type=int, default=None)

    _lease_common(lease_sub.add_parser("status", help="who holds the board (JSON)"))
    _lease_common(lease_sub.add_parser(
        "preflight",
        help="exit 0 iff it is safe for US to touch the board (unheld, or held "
             "by --holder EXACTLY). Deliberately does not probe the board: the "
             "only JTAG way to ask 'is a swap running?' halts the MicroBlaze."))

    # ---------------------------------------------------------------------- #
    # sd
    # ---------------------------------------------------------------------- #
    sd_p = sub.add_parser(
        "sd", help="MPS3 config-SD operations",
        description="sd_install ALWAYS times the client out (~12 MB over "
                    "USB-MSC) and that is NOT a failure. One write, wait, then "
                    "reset -- a retry mid-write corrupts the SD and darkens the "
                    "board.",
    )
    sd_sub = sd_p.add_subparsers(dest="sd_verb", required=True)
    sdw = sd_sub.add_parser("write", help="write a bitstream/bundle to the config SD")
    sdw.add_argument("bundle", help="the .bit to install (path ON the executing host)")
    sdw.add_argument("--token", default=None, help="lease token (proof the board is ours)")
    sdw.add_argument("--holder", default=None, help="lease holder (env MPS3_LEASE_HOLDER)")
    sdw.add_argument("--chassis", default=None)
    sdw.add_argument("--target", default=None)
    sdw.add_argument("--backup", default=None,
                     help="directory holding a CAPTURED, verified backup of the "
                          "current SD. sd_install overwrites in place; on "
                          "2026-07-16 the previous nanosoc.bit was overwritten "
                          "with no backup and is gone.")
    sdw.add_argument("--no-backup", action="store_true", dest="no_backup",
                     help="waive the backup gate (says so, loudly, in the log)")
    sdw.add_argument("--wait", type=float, default=300.0,
                     help="settle interval after the write (s); the hub keeps "
                          "writing long after the client returns")
    sdw.add_argument("--verify-path", default=None, dest="verify_path",
                     help="path of the written file on the MOUNTED SD, for an "
                          "md5 read-back. Omitted, the write is reported "
                          "UNVERIFIED rather than assumed good -- the fpgahub "
                          "API exposes no read-back of its own.")
    sdw.add_argument("--state-dir", default=None, dest="state_dir",
                     help="where the in-flight marker lives (env MPS3_STATE_DIR)")
    sdw.add_argument("--force", action="store_true",
                     help="clear a stale in-flight marker first. Only when you "
                          "are CERTAIN no write is running.")
    sdw.set_defaults(func=_cmd_sd_write)

    # ---------------------------------------------------------------------- #
    # boot-rate
    # ---------------------------------------------------------------------- #
    boot = sub.add_parser(
        "boot-rate",
        help="measure the MCC-config-from-SD boot rate (docs/BOOT_RATE.md)",
        description="Reboot the board N times through the hub's reset surface, "
                    "poll ping until a deadline, and record what came back -- a "
                    "rate with a denominator, a 95%% interval, and the SD "
                    "configuration under test. `--method mcc` is REFUSED (a "
                    "proven no-op: it reports ok and reconfigures nothing, so it "
                    "would measure a board that never rebooted). Refuses without "
                    "a lease HELD BY --holder: this reboots a shared board.",
    )
    boot.add_argument("--host", default=None,
                      help="shell host/IP for the ping probe (net-protocol.md)")
    boot.add_argument("--control-port", type=int, default=6900, dest="control_port")
    boot.add_argument("--n", type=int, default=10,
                      help="iterations (default 10 -- the audit's N; at N=10 the "
                           "95%% interval is about half the scale, and the "
                           "summary says so)")
    boot.add_argument("--method", default="msd",
                      help="fpgahub reset method (default msd: TRM 100765 3.2 "
                           "reboot.txt + USB_REMOTE). 'mcc' is refused.")
    boot.add_argument("--deadline", type=float, default=90.0,
                      help="seconds to wait for ping after each reset (default 90)")
    boot.add_argument("--poll", type=float, default=5.0,
                      help="seconds between probes (default 5)")
    boot.add_argument("--gap", type=float, default=10.0,
                      help="settle seconds between iterations (default 10)")
    boot.add_argument("--down-deadline", type=float, default=30.0,
                      dest="down_deadline",
                      help="seconds to wait for the shell to STOP answering "
                           "before counting the boot. A reset the shell survives "
                           "is recorded as hub-error, not as an instant boot -- "
                           "that is the --method mcc signature.")
    boot.add_argument("--no-await-down", action="store_true", dest="no_await_down",
                      help="do not require an observed down edge (the first "
                           "answer may then be the PRE-reboot shell; the record "
                           "says so)")
    boot.add_argument("--variant", default=None,
                      help="the fpga/mps3_sd/variants/<NAME> config the SD is "
                           "carrying. Its key deltas are READ from that "
                           "directory into the record; an unknown name is "
                           "refused rather than recorded as a claim.")
    boot.add_argument("--out", default=None, help="write the run record here (JSON)")
    boot.add_argument("--mcc-log", default=None, dest="mcc_log",
                      help="path of the MCC LOG.TXT on the EXECUTING host (the "
                           "mounted config SD), captured as a sha256 per "
                           "iteration. No default: the mount point is "
                           "site-specific, exactly like `sd write --verify-path`.")
    boot.add_argument("--witness-cmd", default=None, dest="witness_cmd",
                      help="OPTIONAL command printing {\"configured\":bool,"
                           "\"usercode\":\"0x..\"} -- a JTAG DONE/USERCODE "
                           "witness. Off by default and never required; with it, "
                           "configured+inert is recorded as timeout, not dark.")
    boot.add_argument("--probe-timeout", type=float, default=3.0,
                      dest="probe_timeout")
    boot.add_argument("--token", default=None,
                      help="lease token; given, the lease is heartbeaten each "
                           "iteration (a long campaign can outlive a short TTL)")
    boot.add_argument("--note", action="append", default=None,
                      help="free-text note to store in the record (repeatable)")
    boot.add_argument("--holder", default=None,
                      help="lease holder (env MPS3_LEASE_HOLDER). REQUIRED: this "
                           "verb must prove the board is ours.")
    boot.add_argument("--chassis", default=None)
    boot.add_argument("--target", default=None)
    boot.add_argument("--dry-run", action="store_true", dest="dry_run",
                      help="print the plan and touch nothing at all")
    boot.set_defaults(func=_cmd_boot_rate, boot_verb=None)

    boot_sub = boot.add_subparsers(dest="boot_verb")
    boot_cmp = boot_sub.add_parser(
        "compare", help="before/after two run records, naming the variable that "
                        "changed")
    boot_cmp.add_argument("before")
    boot_cmp.add_argument("after")
    boot_cmp.add_argument("--json", action="store_true", help="machine-readable")
    boot_cmp.set_defaults(func=_cmd_boot_rate, boot_verb="compare")
    boot_schema = boot_sub.add_parser(
        "schema", help="print the versioned JSON schema for a run record")
    boot_schema.set_defaults(func=_cmd_boot_rate, boot_verb="schema")

    # ---------------------------------------------------------------------- #
    # ping / version / diag / dut-eth
    # ---------------------------------------------------------------------- #
    for name, fn, helptext in (
        ("ping", _cmd_ping, "{\"op\":\"ping\"} -> shell_id / rm_id (read-only, swap-safe)"),
        ("version", _cmd_version, "the RUNNING firmware's build identity + feature flags"),
        ("diag", _cmd_diag, "the shell's always-on diagnostic counters"),
        ("dut-eth", _cmd_dut_eth,
         "read the frames the DUT TRANSMITTED out of the egress FIFO (dutrx)"),
    ):
        sp = sub.add_parser(name, help=helptext)
        sp.add_argument("--host", required=True, help="shell host/IP (net-protocol.md)")
        sp.add_argument("--control-port", type=int, default=6900, dest="control_port")
        sp.add_argument("--timeout", type=float, default=6.0)
        if name == "ping":
            sp.add_argument("--line", action="store_true",
                            help="print `shell_id=... rm_id=...` instead of JSON "
                                 "(the shape scripts/harness_regression.sh greps)")
        if name == "dut-eth":
            # NOTE every read CONSUMES: the block's DATA port is destructive, so
            # a frame this command prints is gone from the FIFO. --frames is a
            # CAP, not a demand; reading fewer (an idle DUT) is a result.
            sp.add_argument("--frames", type=int, default=1, metavar="N",
                            help="read at most N whole frames (default 1); "
                                 "stops early when the FIFO is empty. EVERY "
                                 "READ CONSUMES -- the block's DATA port is "
                                 "destructive, so a frame printed here is gone")
        sp.set_defaults(func=fn)

    return parser


def _cmd_flash(args: argparse.Namespace) -> int:
    """Program the packed MicroPython image onto the board SST26 via the DUT's
    qspi controller over SWD. Halts the M0 (so the host owns the controller
    registers), programs + read-back-verifies, then resumes. BOARD-UNPROVEN:
    the fake-controller unit tests cover the command sequencing; real
    SWD-over-AHB throughput and SST26 timing are not exercised here."""
    from .qspi_flash import QspiFlashProgrammer, QspiFlashError
    from .swd import SwdDebugger

    try:
        image = Path(args.image).read_bytes()
    except OSError as exc:
        print(f"flash: cannot read image {args.image}: {exc}", file=sys.stderr)
        return 2

    swd_kwargs = {"hub": args.hub}
    if args.host:
        swd_kwargs["shell_host"] = args.host
    if args.repo_dir:
        swd_kwargs["repo_dir"] = args.repo_dir
    swd = SwdDebugger(**swd_kwargs)
    prog = QspiFlashProgrammer(swd, clk_div=args.clk_div)
    try:
        swd.halt()
        if args.verify_only:
            res = prog.verify_image(image, base=args.base)
            print(f"flash verify OK: {res.length} B match at 0x{args.base:X}")
        else:
            res = prog.program_image(image, base=args.base, do_verify=not args.no_verify)
            print(
                f"flash OK: {res.bytes_programmed} B, {res.pages_programmed} pages, "
                f"{res.sectors_erased} sectors erased ({res.jedec})"
                + ("" if res.verify is None else "; verify OK")
            )
    except QspiFlashError as exc:
        print(f"flash FAILED: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"flash: board/SWD path unreachable: {exc}", file=sys.stderr)
        return 3
    finally:
        try:
            swd.resume()
        except Exception:
            pass
    return 0


def main(argv: "list[str] | None" = None, *, runner: Any = None) -> int:
    """``runner`` is the hub-command injection seam (:class:`pyverify.lease.HubRunner`
    or any ``(argv, timeout=None) -> RunResult`` callable). Tests pass an
    in-process fpgahub double; on a real host it is built from ``MPS3_HUB`` /
    ``MPS3_ON_HUB``."""
    parser = build_parser()
    args = parser.parse_args(argv)
    if runner is not None:
        args._runner = runner
    func: Any = args.func
    return func(args)


if __name__ == "__main__":
    raise SystemExit(main())
