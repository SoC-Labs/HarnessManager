"""Debug-tool launch wrappers — OpenOCD (remote_bitbang -> SWD, TCP 6920)
and Vivado XVC (TCP 2542). ARCHITECTURE_SPEC.md §10 "Debug architecture".

Command-string / argv construction is real and matches net-protocol.md's
port map and §10.1's protocol-char table exactly. The launch functions
are real ``subprocess.run`` wrappers with an injectable *runner* seam
(:data:`SubprocessRunner`): tests pass a fake runner and assert on the
argv/stdin/timeout it receives (``tests/test_debug_launch.py``); real use
leaves ``runner=None`` and gets :func:`default_runner` — the same
capture-output/text/timeout/no-check shape as
``fpgahub.debug_plugins.swd_openocd`` / ``xvc_jtag_openocd``
(``/home/dam1n19/SoCLabs/fpgahub``, reference-only). What still needs a
board is only the *target*: a live shell listening on 6920/2542 plus the
tool binaries installed on the calling host.
"""
from __future__ import annotations

import shlex
import subprocess
from dataclasses import dataclass
from typing import Callable, Optional

__all__ = [
    "SWD_REMOTE_BITBANG_PORT",
    "JTAG_REMOTE_BITBANG_PORT",
    "XVC_PORT",
    "OpenOcdRemoteBitbangConfig",
    "XvcTarget",
    "SubprocessRunner",
    "default_runner",
    "launch_openocd",
    "launch_vivado_xvc_tcl",
]

# net-protocol.md port map.
SWD_REMOTE_BITBANG_PORT = 6920
#: The JTAG bridge's OpenOCD ``remote_bitbang`` port (net-protocol.md TCP 6921,
#: ``firmware/common/net_proto.h`` ``MPS3_PORT_JTAG``, served by
#: ``firmware/jtag_server/``). On the JTAG-bridge shell introduced by ``0xCD74B6AE``
#: and every shell since (docs/FIELDED_SHELL.md), this — not
#: 6920 — is the live DUT-debug path: the SWD→JTAG migration made ``swd_server``
#: dormant and put a SoC-400 SWJ-DP behind ``jtag_bb``. ``host/openocd/
#: nanosoc_mps3_jtag.cfg`` defaults ``RBB_PORT`` to this.
JTAG_REMOTE_BITBANG_PORT = 6921
XVC_PORT = 2542


@dataclass(frozen=True)
class OpenOcdRemoteBitbangConfig:
    """Builds the OpenOCD argv for the v1 "dumb pin-wiggler" SWD front-end
    (ARCHITECTURE_SPEC.md §10.1, D10=v1): OpenOCD's ``remote_bitbang``
    adapter driver, talking the byte protocol over TCP to the shell's SWD
    probe endpoint (net-protocol.md port 6920)::

        O SWDIO drive   o SWDIO release   c sample SWDIO
        d {CLK0,DIO0}   e {CLK0,DIO1}     f {CLK1,DIO0}   g {CLK1,DIO1}
        B/b LED   r/s/t/u trst/srst   Q quit

    Requires OpenOCD >= the Jan-2021 remote_bitbang-SWD merge (spec
    §16). The exact CLK/DIO bit order should be confirmed against the
    shell firmware's ``bitbang.c``-equivalent at bring-up (spec §10.1
    parenthetical) — this wrapper only builds the OpenOCD-side command;
    it has no opinion on the shell's internal wiring.
    """

    shell_host: str
    port: int = SWD_REMOTE_BITBANG_PORT
    openocd: str = "openocd"
    adapter_speed_khz: int = 1000
    #: Path OpenOCD's `source [find ...]` resolves. The nanosoc-on-MPS3
    #: single-core target cfg doesn't exist yet in this repo (that's
    #: A2/A3 territory — DFX/shell-FW); placeholder name kept here so the
    #: shape of the invocation is reviewable. Flag for A6: where does this
    #: file eventually live (fpga/dfx/? firmware/?), and does it get
    #: shipped alongside the overlay manifest so pyverify can point at the
    #: right one per-RM instead of a single hardcoded default?
    target_cfg: str = "target/nanosoc_mps3.cfg"
    extra_search_dirs: tuple[str, ...] = ()
    timeout_s: float = 30.0

    def command(self, op_cmd: str = "init") -> list[str]:
        """Build the full ``openocd -c ... -c ...`` argv.

        Every directive goes via ``-c`` (no temp cfg file needed), mirroring
        the pattern in the fpgahub reference plugins, wrapped in ``init ...
        shutdown`` so the op runs against a live target then cleanly exits.
        """
        argv = [self.openocd]
        for d in self.extra_search_dirs:
            argv += ["-c", f"add_script_search_dir {d}"]
        argv += [
            "-c", "adapter driver remote_bitbang",
            "-c", f"remote_bitbang host {self.shell_host}",
            "-c", f"remote_bitbang port {self.port}",
            "-c", "transport select swd",
            "-c", f"adapter speed {self.adapter_speed_khz}",
            "-c", f"source [find {self.target_cfg}]",
            "-c", "init",
            "-c", op_cmd,
            "-c", "shutdown",
        ]
        return argv

    def command_str(self, op_cmd: str = "init") -> str:
        """Shell-quoted string form of :meth:`command`, for logging or
        building an ssh-wrapped remote invocation (see fpgahub's
        ``vivado_jtag``/``xvc_jtag_openocd`` for the ssh-wrap pattern)."""
        return " ".join(shlex.quote(a) for a in self.command(op_cmd))


@dataclass(frozen=True)
class XvcTarget:
    """Vivado hw_server / "Add Xilinx Virtual Cable" target, pointed at the
    shell's XVC server (net-protocol.md port 2542, A3 ``xvc_server``).

    ILA-over-Ethernet re-attach after a swap needs the *new* RM's ``.ltx``
    reloaded (spec §6.3/§10 "XVC can't detect overlay replacement") —
    that path comes from the overlay manifest (``pyverify.overlay``), not
    from this class.
    """

    shell_host: str
    port: int = XVC_PORT

    def open_hw_target_tcl(self) -> str:
        """Vivado Tcl to attach an XVC hw_target (mirrors
        ``open_hw_target -xvc_url <host>:<port>``, as fpgahub's
        ``vivado_jtag`` companion scripts do for a physical hw_server)."""
        return f"open_hw_target -xvc_url {self.shell_host}:{self.port}"

    def refresh_ila_tcl(self, ltx_path: str) -> str:
        """Tcl to reload the new RM's probes file and re-arm an ILA — the
        concrete steps spec §10/§6.3 call for after every swap."""
        return (
            f"open_hw_target\n"
            f"set_property PROBES.FILE {shlex.quote(ltx_path)} [current_hw_device]\n"
            f"refresh_hw_device [current_hw_device]\n"
        )


# --------------------------------------------------------------------------- #
# Launch wrappers (real subprocess, injectable runner seam)
# --------------------------------------------------------------------------- #

#: The runner seam: ``(argv, timeout_s=..., input_text=...) -> CompletedProcess``.
#: Tests inject a fake; ``None`` selects :func:`default_runner`.
SubprocessRunner = Callable[..., "subprocess.CompletedProcess[str]"]


def default_runner(
    argv: list[str], *, timeout_s: float, input_text: "str | None" = None,
) -> "subprocess.CompletedProcess[str]":
    """Real runner: captured/teed text output, bounded by ``timeout_s``,
    ``check=False`` (callers inspect ``returncode`` — a failed ``init``
    against an unreachable shell is an *expected* outcome to report, not
    an exception). Mirrors the fpgahub debug plugins' subprocess shape.
    """
    return subprocess.run(
        argv, input=input_text, capture_output=True, text=True,
        timeout=timeout_s, check=False,
    )


def launch_openocd(
    config: OpenOcdRemoteBitbangConfig,
    op_cmd: str = "init",
    *,
    runner: Optional[SubprocessRunner] = None,
) -> "subprocess.CompletedProcess[str]":
    """Run OpenOCD against the shell's remote_bitbang SWD endpoint.

    Builds the argv via :meth:`OpenOcdRemoteBitbangConfig.command` and
    hands it to ``runner`` (default :func:`default_runner` — a real
    ``subprocess.run``). Needs the ``openocd`` binary on the calling host
    and a live shell at ``config.shell_host:config.port`` to do anything
    useful; the wrapper itself has no other environmental dependency.
    """
    run = runner if runner is not None else default_runner
    return run(config.command(op_cmd), timeout_s=config.timeout_s)


def launch_vivado_xvc_tcl(
    target: XvcTarget,
    tcl_script: str,
    *,
    vivado: str = "vivado",
    timeout_s: float = 60.0,
    runner: Optional[SubprocessRunner] = None,
) -> "subprocess.CompletedProcess[str]":
    """Run a Vivado batch Tcl script against the shell's XVC endpoint.

    ``tcl_script`` is expected to start with
    :meth:`XvcTarget.open_hw_target_tcl` (or :meth:`XvcTarget.refresh_ila_tcl`
    for a post-swap re-attach) — it is piped to Vivado on stdin
    (``-source /dev/stdin``), so no temp file is written. ``target`` names
    the XVC endpoint the script is *about*; the endpoint itself appears
    inside the script (via the ``XvcTarget`` helpers), not on the argv.
    """
    run = runner if runner is not None else default_runner
    argv = [vivado, "-mode", "batch", "-nojournal", "-nolog", "-source", "/dev/stdin"]
    return run(argv, timeout_s=timeout_s, input_text=tcl_script)
