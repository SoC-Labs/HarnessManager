"""Swap orchestrator — ARCHITECTURE_SPEC.md §6.2 (swap sequence) / §6.3
(re-attach).

Sequences a full overlay deploy: **validate -> swap -> push -> await -> re-attach**
(the swap RPC is sent first and PARKS, the pair is pushed into it, the reply is
read last — see the ORDERING note below and :meth:`SwapOrchestrator.deploy`).
The sequencing itself is real; the network work for each step is delegated
to injected collaborators (:class:`~pyverify.client.ShellClient` and a
pusher — see :class:`Pusher` below), both of which are themselves real
implementations awaiting only a live shell to point at.

Packaging note (RESOLVED — this used to be a flagged-for-A6 open
question): the bitstream pusher, historically a deliberately separate
sibling directory (``host/pusher/push.py``) reachable only via the
structural :class:`Pusher` protocol, is now part of this package as
:mod:`pyverify.pusher` (W-PKG, docs/NEXT_WAVE_PLAN.md). ``host/pusher/
push.py`` survives only as a thin re-export shim for path-based
consumers. The :class:`Pusher` Protocol below is *kept* — no longer as a
package boundary, but as the dependency-injection seam that lets tests
(and :class:`pyverify.board.Mps3Board`) substitute fake pushers without
monkeypatching.

ORDERING — RESOLVED ON SILICON (2026-07-14). This module used to *assume* the
host pushes the pair **ahead of** the ``swap`` RPC, and said so with a caveat:
"confirm with A3 before this is load-bearing." **That assumption was wrong.**
The real sequence, verified end-to-end against the KU115 (led swapped over
Ethernet, ``DFXCTL.RM_ID`` = 0x0100001E), is:

    swap_begin()  ->  push_pair()  ->  swap_await()

The shell only listens for the bitstream on 6910 once the ``swap`` RPC has driven
its FSM into AWAIT_INCOMING_CLEARING / AWAIT_PARTIAL — which is precisely *why* it
PARKS the 6900 control connection for the whole reconfiguration. Push first and the
shell is not expecting data: it **resets** the 6910 connection (ECONNRESET, its
``diag.got`` counter stays 0), and the swap then reports ``"swap failed"`` because
no partial was ever staged.

The bug survived because :class:`pyverify.testing.fakeshell.FakeShell` encoded the
same wrong assumption (it accepts a push in any state), so the end-to-end tests were
green against a fake **more permissive than the firmware**. The fake now enforces the
real ordering.

A real board additionally needs the matched pair on both sides — firmware built
``HWICAP_FIFO=1 WINDOWED=1`` and a windowed pusher (``BitstreamPusher(windowed=True)``);
a fire-and-hose push starves the single-threaded MicroBlaze's RX poll and the shell
resets the connection. See ``docs/OVER_THE_WIRE_DEPLOY_STATUS.md``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol, runtime_checkable

from .client import ShellClient, SwapResponse
from .overlay import Overlay, OverlayValidationError

__all__ = [
    "Pusher",
    "SwapError",
    "ReattachPlan",
    "ReattachExecutor",
    "SwapDeployResult",
    "SwapOrchestrator",
]


@runtime_checkable
class Pusher(Protocol):
    """Structural interface this orchestrator needs from a bitstream
    pusher. Satisfied by :class:`pyverify.pusher.BitstreamPusher` (the
    real one) and by any test fake with a matching ``push_pair`` — kept as
    the injection seam even now that the real pusher lives inside this
    package (see module docstring).
    """

    def push_pair(self, overlay: Overlay, *, rm_slot: int = 0) -> tuple[Any, Any]:
        ...


class SwapError(Exception):
    """Any step of validate -> swap -> push -> await failed."""


#: One re-attach step: takes the plan, returns that step's outcome (opened
#: console readers, a hint string, a subprocess result, ...).
ReattachExecutor = Callable[["ReattachPlan"], Any]


@dataclass(frozen=True)
class ReattachPlan:
    """Client-side re-attach steps after a swap (spec §6.3).

    Descriptive first (the fields tell the caller what to do and in what
    shape, based on what the manifest/response carried), and now also
    *executable* via :meth:`apply` — with injectable per-step executors,
    because each step needs a different tool: reloading the ``.ltx`` is a
    Vivado/XVC action (:class:`pyverify.debug.XvcTarget`), the SWD line
    reset + DP connect is an OpenOCD action
    (:class:`pyverify.debug.OpenOcdRemoteBitbangConfig`), and only the
    console reopen is trivially a fresh TCP connect
    (:class:`pyverify.console.ConsoleReader`). :meth:`apply`'s defaults
    reflect exactly that split: console reopen is done for real, the
    tool-bound steps return their hint unless the caller injects a real
    executor.
    """

    ltx_path: str | None
    swd_reconnect_hint: str
    console_reopen_ports: tuple[int, ...]
    vphy_relink_hint: str
    #: The shell host the swap ran against — recorded so :meth:`apply`'s
    #: default console executor knows where to reconnect. ``None`` (e.g. a
    #: hand-built plan, or an injected client without a ``host``) degrades
    #: the console step to returning the ports as a hint.
    shell_host: str | None = None

    #: Step names :meth:`apply` recognises, in execution order (spec §6.3's
    #: three tool-specific steps + the VPHY re-link nudge).
    STEP_NAMES = ("ltx", "swd", "console", "vphy")

    # -- default executors -------------------------------------------------- #

    def _default_ltx(self) -> str | None:
        """Return-hint default: reloading probes needs Vivado + XVC (see
        :meth:`pyverify.debug.XvcTarget.refresh_ila_tcl`)."""
        if self.ltx_path is None:
            return None
        return (
            f"reload probes file {self.ltx_path!r} over XVC — see "
            "pyverify.debug.XvcTarget.refresh_ila_tcl() / launch_vivado_xvc_tcl()"
        )

    def _default_swd(self) -> str:
        """Return-hint default: the DP reconnect needs OpenOCD."""
        return self.swd_reconnect_hint

    def _default_console(self) -> Any:
        """Real default: consoles reopen with a plain TCP connect. Returns
        a tuple of connected :class:`~pyverify.console.ConsoleReader`\\ s
        (caller owns closing them); degrades to returning the port tuple
        as a hint when no ``shell_host`` was recorded."""
        if self.shell_host is None:
            return self.console_reopen_ports
        from .console import ConsoleReader  # local: avoid import cycle at module load

        readers = []
        try:
            for port in self.console_reopen_ports:
                readers.append(ConsoleReader(self.shell_host, port).connect())
        except Exception:
            for r in readers:
                r.close()
            raise
        return tuple(readers)

    def _default_vphy(self) -> str:
        """Return-hint default: re-linking is a live control-channel verb
        (``client.link(event="up")``) the caller times deliberately."""
        return self.vphy_relink_hint

    def apply(
        self, executors: Mapping[str, ReattachExecutor] | None = None,
    ) -> dict[str, Any]:
        """Execute the re-attach steps, returning ``{step: outcome}``.

        ``executors`` overrides any subset of :attr:`STEP_NAMES` with a
        callable taking this plan. Defaults: ``console`` reopens the TCP
        consoles for real (when :attr:`shell_host` is known); ``ltx``,
        ``swd`` and ``vphy`` return their descriptive hint, since doing
        them for real requires Vivado/OpenOCD/a live control channel the
        caller must supply (inject e.g.
        ``{"swd": lambda plan: launch_openocd(cfg)}``).
        """
        defaults: dict[str, ReattachExecutor] = {
            "ltx": lambda plan: plan._default_ltx(),
            "swd": lambda plan: plan._default_swd(),
            "console": lambda plan: plan._default_console(),
            "vphy": lambda plan: plan._default_vphy(),
        }
        overrides = dict(executors) if executors else {}
        unknown = sorted(set(overrides) - set(self.STEP_NAMES))
        if unknown:
            raise ValueError(
                f"unknown re-attach step(s) {unknown}; valid: {list(self.STEP_NAMES)}"
            )
        merged = {**defaults, **overrides}
        return {name: merged[name](self) for name in self.STEP_NAMES}


@dataclass(frozen=True)
class SwapDeployResult:
    rm_id: str
    verified: bool
    reattach: ReattachPlan


class SwapOrchestrator:
    """Sequences an overlay deploy end to end.

    Parameters
    ----------
    client:
        A connected :class:`~pyverify.client.ShellClient`.
    pusher:
        Anything satisfying :class:`Pusher` — typically
        ``pusher.push.BitstreamPusher(host=...)``.
    """

    #: TCP ports the UART0/UART1/SWO consoles listen on (net-protocol.md).
    CONSOLE_PORTS: tuple[int, ...] = (6930, 6931, 6932)

    def __init__(self, client: ShellClient, pusher: Pusher) -> None:
        self._client = client
        self._pusher = pusher

    def deploy(
        self, overlay: Overlay, *, rm_slot: int = 0, src: str = "tftp",
    ) -> SwapDeployResult:
        """Validate -> push clearing+partial -> ``swap`` RPC -> re-attach plan.

        Raises :class:`SwapError` (chaining the original exception) if
        validation fails or the shell rejects the swap.
        """
        # 1. Learn the shell's static_id from a live ping; overlay-manifest.md
        #    requires the manifest's static_id to match the *running* shell
        #    ("a shell rebuild invalidates every stored partial").
        ping = self._client.ping()
        expected_static_id: int | None
        if not ping.shell_id:
            # The shell reported no id at all — no info to check against.
            # (net-protocol.md says ping always returns shell_id, so this is
            # itself unusual, but it is not the dangerous case below.)
            expected_static_id = None
        else:
            try:
                expected_static_id = int(ping.shell_id, 0)
            except ValueError as exc:
                # The shell reported a NON-EMPTY but unparseable shell_id.
                # Silently skipping static_id validation here (the old
                # behaviour) would push a partial to a shell whose static we
                # could not verify — exactly what overlay-manifest.md's
                # static_id rule exists to prevent. Fail loud instead.
                raise SwapError(
                    f"shell reported an unparseable shell_id {ping.shell_id!r}; "
                    "refusing to deploy without a verifiable static_id "
                    "(a partial is only valid against its exact static)"
                ) from exc

        try:
            overlay.validate(expected_static_id=expected_static_id)
        except OverlayValidationError as exc:
            raise SwapError(f"overlay validation failed: {exc}") from exc

        # 2. Issue the swap RPC FIRST — WITHOUT awaiting its reply.
        #
        #    ⚠⚠ THE ORDER IS LOAD-BEARING. PROVEN ON SILICON 2026-07-14.
        #    The shell only listens for the bitstream on 6910 once this RPC has
        #    driven its swap FSM into AWAIT_INCOMING_CLEARING / AWAIT_PARTIAL —
        #    which is exactly WHY it parks the 6900 connection for the whole
        #    reconfiguration. This module used to push FIRST and swap second (the
        #    "design assumption ... confirm with A3 before this is load-bearing"
        #    flagged in the module docstring). That assumption was WRONG: a push
        #    to a shell that is not awaiting one is RESET (ECONNRESET; the shell's
        #    `diag.got` stays 0), and the swap then fails "swap failed" because no
        #    partial was ever staged. It survived because FakeShell encoded the
        #    same wrong assumption — the tests were green against a fake more
        #    permissive than the firmware.
        self._client.swap_begin(rm=overlay.manifest.rm_name, src=src)

        # 3. Push clearing then partial INTO the parked swap — the shell is now
        #    awaiting exactly this.
        #    ⚠ A real board also needs the matched pair on BOTH sides: firmware
        #    built `HWICAP_FIFO=1 WINDOWED=1`, and a windowed pusher
        #    (`BitstreamPusher(windowed=True)`). A fire-and-hose push starves the
        #    single-threaded MicroBlaze's RX poll and the shell resets the
        #    connection. See docs/OVER_THE_WIRE_DEPLOY_STATUS.md.
        self._pusher.push_pair(overlay, rm_slot=rm_slot)

        # 4. Collect the parked reply. This blocks for the whole server-side
        #    gate -> decouple -> clear -> load -> verify -> release sequence, so
        #    the client needs a GENEROUS timeout (the 5 s default cannot survive
        #    a real reconfiguration).
        try:
            resp: SwapResponse = self._client.swap_await()
        except OSError as exc:
            # A socket timeout/reset HERE means the control channel WAS reachable
            # (we ping'd it in step 1) but the swap did not complete in time —
            # almost always the client timeout being shorter than a real swap.
            # Left bare, cli.py mislabels an OSError as "cannot reach the control
            # channel"; that misdiagnosis cost real debugging time. Raise a
            # precise SwapError so the true cause surfaces.
            raise SwapError(
                f"swap did not complete for rm={overlay.manifest.rm_name!r} "
                f"(client timeout {getattr(self._client, 'timeout', '?')}s): {exc}. "
                "The shell parks the 6900 control connection for the entire swap, "
                "so a real reconfiguration needs a longer ShellClient(timeout=…). "
                "This is NOT an unreachable control channel."
            ) from exc
        if not resp.ok:
            raise SwapError(
                f"swap RPC rejected for rm={overlay.manifest.rm_name!r}: {resp}"
            )

        # 4. Re-attach plan (spec §6.3) — descriptive, and executable via
        #    ReattachPlan.apply() with injectable per-step executors.
        reattach = ReattachPlan(
            ltx_path=overlay.manifest.ltx,
            swd_reconnect_hint=(
                "re-run SWD line reset + DP connect (read DPIDR) over the "
                "remote_bitbang endpoint; DUT must be clocked and out of "
                "reset first (see pyverify.debug.OpenOcdRemoteBitbangConfig)"
            ),
            console_reopen_ports=self.CONSOLE_PORTS,
            vphy_relink_hint=(
                "client.link(event='up') once the DUT's MAC has had time to "
                "restart PHY bring-up against the virtual PHY (spec §6.3)"
            ),
            shell_host=getattr(self._client, "host", None),
        )
        return SwapDeployResult(rm_id=resp.rm_id, verified=resp.verified, reattach=reattach)
