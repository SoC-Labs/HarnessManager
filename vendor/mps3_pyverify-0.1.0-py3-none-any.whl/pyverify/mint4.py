"""net-protocol v0.20 (mint 4): request codecs + the shared policy tables.

docs/contracts/net-protocol.md "Mint 4 — hostio streams, `sensors`, `mcc`, `cosim`,
`hostio`". Everything here is pure: it builds and VALIDATES request dicts (so a
client never puts a hard-denied or malformed request on the wire: fail closed,
before the socket) and names the closed sets both ends share. The replies are
passed through raw (ENGINE verbs: the reply carries ``op``/``act``), like
``identity``/``locate``.

:class:`MccDenied` is a ``ValueError``: it is raised BEFORE sending. The FakeShell
(and the engine) enforce the same lists server-side, so a hand-rolled request is
still refused with ``code`` ``denied``.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, Optional

__all__ = [
    "HOSTIO_USRT1_PORT", "HOSTIO_ADP_PORT", "MINT4_FEATURES",
    "CODES", "code_of",
    "HOSTIO_MODES", "hostio_request",
    "SENSORS_ACTS", "SENSORS_SET_KEYS", "SENSORS_ALARM_BITS", "sensors_request",
    "MCC_ACTS", "MCC_ROUTES", "MCC_DENY_ACTS", "MCC_OSC_PROTECTED", "MCC_OSC_ALLOWED",
    "MCC_PROBE_FUNCS", "MCC_LOCKED_ACTS", "MccDenied", "mcc_request",
    "COSIM_ACTS", "COSIM_STEP_MAX", "cosim_request",
    "RESET_MINT4_TARGETS",
]

#: hostio CH1 (USRT1) / CH0 (ADP): raw TCP byte streams (net-protocol.md).
HOSTIO_USRT1_PORT = 6931
HOSTIO_ADP_PORT = 6933

#: The v0.20 ENGINE feature names, in wire order (after ``locate``).
MINT4_FEATURES = ("hostio", "cosim", "sysmon", "mccif", "mcc_local")

#: The ``code`` values of a v0.20 failure line.
CODES = ("not_supported", "no_hw", "locked", "invalid", "denied", "no_route",
         "busy", "not_held", "timeout")


def code_of(resp: Dict[str, Any]) -> Optional[str]:
    """The ``code`` of a failure reply (``None`` on success or when absent)."""
    return None if resp.get("ok") else resp.get("code")


def _int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


# --------------------------------------------------------------------------- #
# hostio
# --------------------------------------------------------------------------- #
HOSTIO_MODES = ("console", "hostio4")


def hostio_request(act: str = "get", mode: Optional[str] = None) -> Dict[str, Any]:
    if act not in ("get", "set"):
        raise ValueError("hostio act must be 'get' or 'set'")
    op: Dict[str, Any] = {"op": "hostio", "act": act}
    if act == "set":
        if mode not in HOSTIO_MODES:
            raise ValueError(f"hostio mode must be one of {HOSTIO_MODES}")
        op["mode"] = mode
    elif mode is not None:
        raise ValueError("hostio get takes no mode")
    return op


# --------------------------------------------------------------------------- #
# sensors
# --------------------------------------------------------------------------- #
SENSORS_ACTS = ("get", "set", "clear_alm")
SENSORS_SET_KEYS = ("temp_hi_c", "temp_ot_c", "vccint_lo_v", "vccint_hi_v", "k")
#: ``alm`` bit names (SYSMON AOSR order).
SENSORS_ALARM_BITS = ("ot", "temp", "vccint", "vccaux", "vccbram")


def sensors_request(act: str = "get", **fields: Any) -> Dict[str, Any]:
    if act not in SENSORS_ACTS:
        raise ValueError(f"sensors act must be one of {SENSORS_ACTS}")
    op: Dict[str, Any] = {"op": "sensors", "act": act}
    if act != "set":
        if fields:
            raise ValueError(f"sensors {act} takes no fields")
        return op
    unknown = set(fields) - set(SENSORS_SET_KEYS)
    if unknown:
        raise ValueError(f"sensors set takes {SENSORS_SET_KEYS}, not {sorted(unknown)}")
    if not fields:
        raise ValueError("sensors set: nothing to set")
    for k, v in fields.items():
        if not _num(v):
            raise ValueError(f"sensors set {k}: not a number")
    op.update(fields)
    return op


# --------------------------------------------------------------------------- #
# mcc
# --------------------------------------------------------------------------- #
MCC_ROUTES = ("scc", "loopback")
#: The route each act uses when the request names none ("auto" = first present
#: of the tuple), and the routes it can use at all.
MCC_ACT_ROUTES: Dict[str, "tuple[str, ...]"] = {
    "status": ("scc", "loopback"), "temp": ("loopback",), "osc": ("scc", "loopback"),
    "osc_set": ("scc", "loopback"), "probe": ("scc",), "mbox": ("scc",),
    "log": ("loopback", "scc"), "reboot": ("loopback",),
}
#: THE MCC POLICY: docs/contracts/mcc_policy.json is the one source of truth (harnessd
#: builds its header from it, the Harness Manager vendors it). pyverify reads it: from the
#: repo when this module runs from the platform tree, else the copy packaged beside this
#: module (pyverify/mcc_policy.json, shipped in the wheel; tests/test_mcc_policy_source.py
#: holds the copy byte-identical to the contract file).
_POLICY_REPO = Path(__file__).resolve().parents[3] / "docs" / "contracts" / "mcc_policy.json"
_POLICY_PKG = Path(__file__).resolve().parent / "mcc_policy.json"


def _load_mcc_policy() -> Dict[str, Any]:
    for p in (_POLICY_REPO, _POLICY_PKG):
        if p.is_file():
            d = json.loads(p.read_text(encoding="utf-8"))
            if d.get("version") != 1:
                raise ImportError(f"{p}: mcc policy version {d.get('version')!r}, pyverify reads 1")
            return d
    raise ImportError(f"mcc policy not found ({_POLICY_REPO} or {_POLICY_PKG})")


MCC_POLICY: Dict[str, Any] = _load_mcc_policy()
MCC_POLICY_PATH = _POLICY_REPO if _POLICY_REPO.is_file() else _POLICY_PKG
#: Acts that are NEVER sent and never served (net-protocol.md "mcc": the shared policy).
MCC_DENY_ACTS = frozenset(MCC_POLICY["deny_acts"])
#: osc_set devices that are protected: 0 LAN9220 25 MHz, 1 the harness's own
#: clock, 3 USB 12 MHz (until proven separate), 6 the DDR4 reference.
MCC_OSC_WHY = {int(k): v for k, v in MCC_POLICY["osc"]["protected"].items()}
MCC_OSC_PROTECTED = frozenset(MCC_OSC_WHY)
MCC_OSC_ALLOWED = frozenset(MCC_POLICY["osc"]["allowed"])
#: probe: SYS_CFG functions that are read-only (func 8 SHUTDOWN is never allowed).
MCC_PROBE_FUNCS = frozenset(MCC_POLICY["probe"]["funcs"])
#: acts (or act forms) that are claim-locked (the policy's "mbox_write" = mbox with w keys).
MCC_LOCKED_ACTS = tuple("mbox (with w keys)" if a == "mbox_write" else a
                        for a in MCC_POLICY["claim_locked"])
OSC_HZ_MIN, OSC_HZ_MAX = MCC_POLICY["osc"]["hz_min"], MCC_POLICY["osc"]["hz_max"]
MCC_ACTS = tuple(MCC_POLICY["acts"])
_TOKEN = re.compile(r"^[0-9A-Fa-f]{%d,%d}$" % (MCC_POLICY["reboot"]["token_min_hex"],
                                               MCC_POLICY["reboot"]["token_max_hex"]))
MCC_OSC_DEV_MAX = MCC_POLICY["osc"]["dev_max"]
MCC_PROBE_DEV_MAX = MCC_POLICY["probe"]["dev_max"]


class MccDenied(ValueError):
    """The request is hard-denied by the MCC policy (never sent)."""


def mcc_request(act: str, **f: Any) -> Dict[str, Any]:
    """Build + validate one ``mcc`` request. Raises :class:`MccDenied` for a
    hard-denied act/value, ``ValueError`` for any other bad argument."""
    if not isinstance(act, str):
        raise ValueError("mcc act must be a string")
    if act in MCC_DENY_ACTS:
        raise MccDenied(f"mcc {act} denied: not an act this harness will ever send")
    if act not in MCC_ACTS:
        raise ValueError(f"mcc act must be one of {MCC_ACTS}")
    op: Dict[str, Any] = {"op": "mcc", "act": act}
    route = f.pop("route", None)
    if route is not None:
        if route not in MCC_ROUTES:
            raise ValueError(f"mcc route must be one of {MCC_ROUTES}")
        if route not in MCC_ACT_ROUTES[act]:
            raise ValueError(f"mcc {act} cannot use route {route!r} "
                             f"(routes: {MCC_ACT_ROUTES[act]})")
        op["route"] = route
    allowed = {"status": (), "temp": (), "osc": ("dev",), "osc_set": ("dev", "hz", "arm"),
               "probe": ("func", "dev"), "mbox": ("w0", "w1", "w2", "w3"),
               "log": ("off",), "reboot": ("token",)}[act]
    extra = set(f) - set(allowed)
    if extra:
        raise ValueError(f"mcc {act} takes {allowed}, not {sorted(extra)}")
    if act in ("osc", "osc_set"):
        dev = f.get("dev")
        if not _int(dev) or not 0 <= dev <= MCC_OSC_DEV_MAX:
            raise ValueError(f"mcc dev must be an integer 0..{MCC_OSC_DEV_MAX}")
        if act == "osc_set":
            if dev in MCC_OSC_PROTECTED:
                raise MccDenied(f"mcc osc_set denied: dev {dev} is {MCC_OSC_WHY[dev]}")
            hz = f.get("hz")
            if not _int(hz) or not OSC_HZ_MIN <= hz <= OSC_HZ_MAX:
                raise ValueError(f"mcc hz must be an integer {OSC_HZ_MIN}..{OSC_HZ_MAX}")
            if f.get("arm") is not True:
                raise ValueError("mcc osc_set must be armed (arm=True)")
            op.update(dev=dev, hz=hz, arm=True)
        else:
            op["dev"] = dev
    elif act == "probe":
        func, dev = f.get("func"), f.get("dev", 0)
        if not _int(func):
            raise ValueError("mcc func must be an integer")
        if func not in MCC_PROBE_FUNCS:
            raise MccDenied(f"mcc probe denied: func {func} (read-only funcs: "
                            f"{sorted(MCC_PROBE_FUNCS)})")
        if not _int(dev) or not 0 <= dev <= MCC_PROBE_DEV_MAX:
            raise ValueError(f"mcc dev must be an integer 0..{MCC_PROBE_DEV_MAX}")
        op.update(func=func, dev=dev)
    elif act == "mbox":
        for k, v in f.items():
            if not _int(v) or not 0 <= v <= 0xFFFFFFFF:
                raise ValueError(f"mcc {k} must be a u32")
            op[k] = v
    elif act == "log":
        off = f.get("off", 0)
        if not _int(off) or off < 0:
            raise ValueError("mcc off must be an integer >= 0")
        op["off"] = off
    elif act == "reboot":
        tok = f.get("token")
        if not isinstance(tok, str) or not _TOKEN.match(tok):
            raise ValueError("mcc reboot needs token= 8-32 hex digits (the caller's witness)")
        op["token"] = tok
    return op


# --------------------------------------------------------------------------- #
# cosim
# --------------------------------------------------------------------------- #
COSIM_ACTS = ("step", "halt", "run", "cycles")
COSIM_STEP_MAX = 100_000_000


def cosim_request(act: str, n: Optional[int] = None) -> Dict[str, Any]:
    if act not in COSIM_ACTS:
        raise ValueError(f"cosim act must be one of {COSIM_ACTS}")
    op: Dict[str, Any] = {"op": "cosim", "act": act}
    if act == "step":
        if not _int(n) or not 1 <= n <= COSIM_STEP_MAX:
            raise ValueError(f"cosim step n must be an integer 1..{COSIM_STEP_MAX}")
        op["n"] = n
    elif n is not None:
        raise ValueError(f"cosim {act} takes no n")
    return op


#: ``reset`` targets v0.20 adds (feature ``mccif``).
RESET_MINT4_TARGETS = ("mcc_warm", "ddr")
