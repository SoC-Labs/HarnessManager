"""``pyverify.bootrate`` — MEASURE the MPS3 boot lottery instead of quoting it.

THE FACT THIS TOOL EXISTS TO REPLACE
    Every plan in this tree says MCC-config-from-SD works "about 1 time in 4",
    and every one of them is quoting the same internal note recording **four**
    power-ups: one clean, two dark, one partial. That is not a rate. It has no
    denominator worth the name, no interval, and no record of which config the
    board was running — so no change to that config can ever be shown to have
    helped, which is why nothing has been tried.

    The same image comes up lit on some power-ups and dark on others, and the
    MCC's ``LOG.TXT`` is byte-identical on a good boot and a dark one: the
    failure is at the **unlogged release-to-RUN step**. Nothing in the log will
    ever tell us. Only counting will.

WHAT A MEASUREMENT HAS TO CARRY TO BE ONE
    * a **denominator** — how many reboots were actually performed, which is not
      the same as how many were asked for (a hub error is an experiment that did
      not happen, not a dark boot);
    * an **interval** — with N=10 the 95% Wilson interval on 7/10 is
      (0.40, 0.89). Half the range. Anyone comparing 7/10 against 9/10 without
      it is reading noise, and this tool prints it beside every rate so that
      reading is available to be refused;
    * the **configuration under test**, read from the SD-bundle variant it names
      rather than typed into the record by hand (``fpga/mps3_sd/variants/``);
    * a **before and an after** for ONE variable — :func:`compare`.

THE FOUR OUTCOMES, AND WHY DARK IS NOT AN ERROR
    ``up``          ping answered with a ``shell_id`` inside the deadline.
    ``dark``        the deadline passed with nothing answering at all. THE
                    MEASUREMENT — the thing being counted, recorded as data and
                    never as a failed run.
    ``timeout``     something was there and never converged: the control channel
                    accepted a connection without answering, or the optional
                    JTAG witness said the FPGA IS configured. Configured+inert
                    is a **hung firmware**, a different defect from a failed
                    configuration, and folding it into ``dark`` would poison the
                    rate this tool exists to produce.
    ``hub-error``   the reboot never happened: the reset surface refused, or it
                    reported ok and the shell went on answering across it (the
                    ``--method mcc`` signature — see below). Excluded from the
                    rate's denominator and reported separately.

WHAT IT REFUSES
    * a run without a lease **held by us**. :meth:`~pyverify.lease.LeaseClient.preflight`
      answers True for an UNHELD board, which is right for a read-only probe and
      wrong for a campaign that power-cycles a shared board ten times.
    * ``--method mcc``. ``fpgahub target reset --method mcc`` is a proven no-op:
      it reports ok and reconfigures nothing, so a campaign driven by it would
      measure the boot rate of a board that never rebooted — 100%, and a lie.
      Refused before anything is contacted, dry run included.

SEAMS (nothing site-specific, nothing that needs a board to test)
    ``probe``     ``() -> Probe`` — liveness. Default: :class:`ShellProbe` over
                  the conformance-pinned :class:`~pyverify.client.ShellClient`.
    ``resetter``  ``(method) -> ResetOutcome``. Default: :class:`HubResetter`,
                  ``fpgahub target reset <target> --method <m> --yes`` through
                  the same :class:`~pyverify.lease.HubRunner` seam every other
                  hub call in this package uses.
    ``witness``   OPTIONAL ``() -> Witness`` — DONE/USERCODE over JTAG is the
                  stronger evidence, but it needs ``xsdb`` on the hub, so it is
                  a hook that is **off by default** and never a requirement.
                  :class:`CommandWitness` adapts any command that prints
                  ``{"configured": bool, "usercode": "0x…"}``.
    ``now``/``sleep``/``wall``  the clock. A 10×90 s campaign is 15 minutes; a
                  test that waited it out would be deleted within the week.
    ``mcc_log_path``  where ``LOG.TXT`` is readable on the executing host — the
                  same seam ``sd.py``'s ``--verify-path`` uses, because there is
                  no site-independent mount path and guessing one would be a
                  hardcoded site fact wearing a default's clothes.
"""
from __future__ import annotations

import json
import math
import os
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .lease import LeaseClient, LeaseError, RunResult
from .sd import sd_file_sha256

__all__ = [
    "SCHEMA_ID",
    "OUTCOMES",
    "OUTCOME_UP",
    "OUTCOME_DARK",
    "OUTCOME_TIMEOUT",
    "OUTCOME_HUB_ERROR",
    "RUN_RECORD_SCHEMA",
    "BootRateError",
    "BootRateInputError",
    "Probe",
    "Witness",
    "ResetOutcome",
    "ShellProbe",
    "HubResetter",
    "CommandWitness",
    "BootRateRunner",
    "check_method",
    "summarise",
    "wilson",
    "validate_record",
    "compare",
    "format_compare",
    "variant_delta",
    "list_variants",
]

#: The run-record schema id. VERSIONED: a record written by a future, different
#: shape must be rejected rather than half-read, because the whole value of
#: these files is that a run from months ago can still be compared.
SCHEMA_ID = "mps3.boot-rate/1"

OUTCOME_UP = "up"
OUTCOME_DARK = "dark"
OUTCOME_TIMEOUT = "timeout"
OUTCOME_HUB_ERROR = "hub-error"
OUTCOMES = (OUTCOME_UP, OUTCOME_DARK, OUTCOME_TIMEOUT, OUTCOME_HUB_ERROR)

#: Reset methods this tool will not drive, and why. `mcc` is not "unsupported":
#: it is worse than unsupported, because it SUCCEEDS.
REFUSED_METHODS = {
    "mcc": (
        "`fpgahub target reset --method mcc` is a proven no-op on this board: "
        "the MCC console sits in FPGA-UART passthrough while an application "
        "runs, so the REBOOT lands on the application's UART, the hub reports "
        "ok, and the KU115 is never reconfigured (confirmed 2026-07-28 x3, "
        "07-30, 08-04). A boot-rate campaign driven by it would measure a board "
        "that never rebooted -- 100%, and meaningless. Use --method msd (TRM "
        "100765 3.2 reboot.txt + USB_REMOTE) or a physical power-cycle."
    ),
}

DEFAULT_DEADLINE_S = 90.0
DEFAULT_POLL_S = 5.0
DEFAULT_GAP_S = 10.0
DEFAULT_DOWN_DEADLINE_S = 30.0
DEFAULT_PROBE_TIMEOUT_S = 3.0
DEFAULT_RESET_TIMEOUT_S = 120.0

#: Where the SD-bundle experiment variants live, relative to the repo root.
VARIANTS_REL = os.path.join("fpga", "mps3_sd", "variants")
VARIANT_META = "variant.txt"


class BootRateError(Exception):
    """A gate refused: no lease, the wrong lease, a refused method."""


class BootRateInputError(Exception):
    """Bad input: an unknown variant, an unreadable or foreign run record."""


# --------------------------------------------------------------------------- #
# the seams
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class Probe:
    """One liveness observation.

    ``connected`` is deliberately separate from ``up``: a TCP connect that
    succeeds while the verb never returns a ``shell_id`` is a **configured
    board with hung firmware**, which is the difference between ``timeout`` and
    ``dark``.
    """

    up: bool
    shell_id: str = ""
    version: Optional[Dict[str, Any]] = None
    connected: bool = False
    error: str = ""


@dataclass(frozen=True)
class Witness:
    """What a JTAG DONE/USERCODE probe saw. ``configured`` is tri-state:
    ``None`` means the witness could not tell, which must never be read as
    "not configured"."""

    configured: Optional[bool]
    usercode: Optional[str] = None
    raw: str = ""

    def to_json(self) -> Dict[str, Any]:
        return {"configured": self.configured, "usercode": self.usercode,
                "raw": self.raw}


@dataclass(frozen=True)
class ResetOutcome:
    ok: bool
    detail: str = ""


class ShellProbe:
    """Liveness over the 6900 control channel: ``ping`` for the fabric identity,
    then ``version`` for the firmware identity (one static_id serves many
    firmware builds, so the pair is the honest answer to "what came up").

    A short timeout on purpose — during a campaign this is called every few
    seconds against a board that is expected to be down half the time.
    """

    def __init__(self, host: str, port: int = 6900,
                 timeout: float = DEFAULT_PROBE_TIMEOUT_S) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout

    def __call__(self) -> Probe:
        from .client import ShellClient, ShellProtocolError

        client = ShellClient(self.host, port=self.port, timeout=self.timeout)
        try:
            with client:
                ping = client.ping()
                if not ping.shell_id:
                    # Connected, answered, said nothing identifying: alive but
                    # not converged.
                    return Probe(up=False, connected=True,
                                 error="ping carried no shell_id")
                version: Optional[Dict[str, Any]] = None
                try:
                    v = client.version()
                    version = {"harness": v.harness, "ver32": v.ver32,
                               "sha": v.sha, "dirty": v.dirty,
                               "lmb_kb": v.lmb_kb, "features": list(v.features)}
                except (OSError, ShellProtocolError) as exc:
                    # An older image without `version` is still UP.
                    version = {"error": str(exc)}
                return Probe(up=True, shell_id=ping.shell_id, version=version,
                             connected=True)
        except ShellProtocolError as exc:
            return Probe(up=False, connected=True, error=str(exc))
        except OSError as exc:
            return Probe(up=False, connected=False, error=str(exc))


class HubResetter:
    """``fpgahub target reset <target> --method <m> --yes`` over the HubRunner
    seam — the dialect ``scripts/mps3_shell_update.sh`` already uses."""

    def __init__(self, runner: Callable[..., RunResult], *, target: str,
                 timeout: float = DEFAULT_RESET_TIMEOUT_S) -> None:
        self._runner = runner
        self.target = target
        self.timeout = timeout

    def argv(self, method: str) -> List[str]:
        return ["fpgahub", "target", "reset", self.target,
                "--method", method, "--yes"]

    def __call__(self, method: str) -> ResetOutcome:
        try:
            res = self._runner(self.argv(method), timeout=self.timeout)
        except TimeoutError as exc:
            return ResetOutcome(False, "reset command timed out: %s" % exc)
        except (LeaseError, OSError) as exc:
            return ResetOutcome(False, "cannot run the reset command: %s" % exc)
        text = res.text.strip()
        if res.returncode != 0:
            return ResetOutcome(False, text or "(no output)")
        # The CLI prints `ok <name> reset ...` / `failed ...` and exits 0 either
        # way for a dispatched-but-failed reset.
        if "failed" in text.lower() and "ok" not in text.split("\n")[0].lower():
            return ResetOutcome(False, text)
        return ResetOutcome(True, text)


class CommandWitness:
    """Adapt any command that prints ``{"configured": …, "usercode": "0x…"}``
    into the witness seam.

    Deliberately NOT an xsdb recipe: DONE/USERCODE needs ``xsdb`` on the hub and
    a JTAG cable that the swap path also wants, so the readback stays a
    site-supplied command instead of a hardcoded one this repo cannot test.
    """

    def __init__(self, cmd: str, *, timeout: float = 60.0) -> None:
        self.cmd = cmd
        self.timeout = timeout

    def __call__(self) -> Witness:
        proc = subprocess.run(["/bin/sh", "-c", self.cmd], capture_output=True,
                              text=True, timeout=self.timeout)
        raw = (proc.stdout or "") + (proc.stderr or "")
        if proc.returncode != 0:
            return Witness(configured=None, raw=raw.strip())
        try:
            obj = json.loads(proc.stdout)
        except (json.JSONDecodeError, ValueError):
            return Witness(configured=None, raw=raw.strip())
        configured = obj.get("configured")
        return Witness(
            configured=(bool(configured) if configured is not None else None),
            usercode=(str(obj["usercode"]) if obj.get("usercode") is not None else None),
            raw=raw.strip(),
        )


# --------------------------------------------------------------------------- #
# the campaign
# --------------------------------------------------------------------------- #


def check_method(method: str) -> None:
    """Raise :class:`BootRateError` for a method that cannot measure anything."""
    reason = REFUSED_METHODS.get(method)
    if reason:
        raise BootRateError("refusing --method %s: %s" % (method, reason))


def _iso(epoch: float) -> str:
    return datetime.utcfromtimestamp(epoch).strftime("%Y-%m-%dT%H:%M:%SZ")


class BootRateRunner:
    """Reboot N times, count what came back, and write down the configuration."""

    #: Test seam: called as ``(iteration, t_reset_monotonic)`` immediately after
    #: each reset is issued. Nothing in production sets it.
    on_iteration_start: Optional[Callable[[int, float], None]] = None

    def __init__(
        self,
        *,
        probe: Callable[[], Probe],
        resetter: Callable[[str], ResetOutcome],
        lease: Optional[LeaseClient] = None,
        holder: Optional[str] = None,
        runner: Optional[Callable[..., RunResult]] = None,
        mcc_log_path: Optional[str] = None,
        witness: Optional[Callable[[], Witness]] = None,
        host: str = "",
        control_port: int = 6900,
        sleep: Callable[[float], None] = time.sleep,
        now: Callable[[], float] = time.monotonic,
        wall: Callable[[], float] = time.time,
        log: Optional[Callable[[str], None]] = None,
    ) -> None:
        self._probe = probe
        self._reset = resetter
        self._lease = lease
        self.holder = holder
        self._runner = runner
        self.mcc_log_path = mcc_log_path
        self._witness = witness
        self.host = host
        self.control_port = control_port
        self._sleep = sleep
        self._now = now
        self._wall = wall
        self._log_to = log
        self.on_iteration_start = None

    # -- plumbing ----------------------------------------------------------- #

    def _say(self, msg: str) -> None:
        if self._log_to:
            self._log_to(msg)

    def _require_lease(self) -> str:
        """The board is SHARED. A campaign that reboots it N times must own it,
        and "nobody holds it" is not ownership."""
        if self._lease is None:
            raise BootRateError(
                "no lease client: a boot-rate campaign reboots a SHARED board "
                "N times and must hold the lease")
        if not self.holder:
            raise BootRateError(
                "boot-rate needs an explicit --holder (or MPS3_LEASE_HOLDER): "
                "it has to prove the lease on the board is OURS, and the "
                "per-PID default holder every other verb falls back to can "
                "never match a lease another process took")
        if not self._lease.held_by(self.holder):
            st = self._lease.status()
            raise BootRateError(
                "lease gate: %s is not held by %r (hub says: %s). Take it first "
                "-- `pyverify lease acquire --holder %s` -- this campaign "
                "reboots the board %s times."
                % (self._lease.chassis, self.holder, st.raw or "free",
                   self.holder, "N"))
        return self.holder

    def _heartbeat(self, token: Optional[str], notes: List[str]) -> None:
        if not token or self._lease is None:
            return
        try:
            self._lease.heartbeat(token, holder=self.holder)
        except LeaseError as exc:
            # Never fatal: a campaign that dies at iteration 7 of 10 because a
            # heartbeat 404'd has thrown away the measurement it was making.
            notes.append("lease heartbeat failed (continuing): %s" % exc)

    def _mcc_log_sha(self, notes: List[str]) -> Optional[str]:
        if not self.mcc_log_path:
            return None
        if self._runner is None:
            notes.append("no hub runner: cannot read %s" % self.mcc_log_path)
            return None
        digest = sd_file_sha256(self._runner, self.mcc_log_path)
        if digest.sha256 is None:
            notes.append("MCC log unreadable (%s): %s"
                         % (self.mcc_log_path, digest.reason))
        return digest.sha256

    def _ask_witness(self, notes: List[str]) -> Optional[Witness]:
        if self._witness is None:
            return None
        try:
            return self._witness()
        except Exception as exc:  # noqa: BLE001 - a witness must never fail a run
            notes.append("witness hook failed (ignored): %s" % exc)
            return None

    # -- one iteration ------------------------------------------------------- #

    def _iteration(
        self,
        index: int,
        *,
        method: str,
        deadline_s: float,
        poll_s: float,
        down_deadline_s: float,
        await_down: bool,
        token: Optional[str],
    ) -> Dict[str, Any]:
        notes: List[str] = []
        self._heartbeat(token, notes)

        pre = self._probe()
        t_reset_wall = self._wall()
        t0 = self._now()

        reset = self._reset(method)
        if self.on_iteration_start is not None:
            self.on_iteration_start(index, t0)
        if not reset.ok:
            notes.append("reset refused: %s" % reset.detail)
            return self._record_iteration(
                index, t_reset_wall, None, 0.0, OUTCOME_HUB_ERROR,
                None, None, notes)
        self._say("iteration %d: reset issued (%s)" % (index, method))

        # -- phase 1: the board must actually go DOWN ------------------------ #
        if not pre.up:
            notes.append("already down before the reset: nothing was answering "
                         "when this iteration began, so there is no down edge "
                         "to wait for")
        elif not await_down:
            notes.append(
                "--no-await-down: the first answer is TRUSTED as the new boot, "
                "but it may be the PRE-reboot shell still answering")
        else:
            down_budget = min(down_deadline_s, deadline_s)
            while True:
                if not self._probe().up:
                    notes.append("down edge seen after %.1fs" % (self._now() - t0))
                    break
                waited = self._now() - t0
                if waited >= down_budget:
                    notes.append(
                        "the shell NEVER stopped answering %.0fs after the "
                        "reset: the reset surface reported ok and rebooted "
                        "nothing (this is the --method mcc signature). Recorded "
                        "as hub-error, NOT as a boot." % waited)
                    return self._record_iteration(
                        index, t_reset_wall, None, waited, OUTCOME_HUB_ERROR,
                        None, self._ask_witness(notes), notes)
                self._sleep(max(0.0, min(poll_s, down_budget - waited)))

        # -- phase 2: wait for it to come back ------------------------------- #
        saw_connect = False
        probe: Optional[Probe] = None
        while True:
            probe = self._probe()
            if probe.up:
                waited = self._now() - t0
                return self._record_iteration(
                    index, t_reset_wall, self._wall(), waited, OUTCOME_UP,
                    probe, self._ask_witness(notes), notes)
            saw_connect = saw_connect or probe.connected
            waited = self._now() - t0
            if waited >= deadline_s:
                break
            self._sleep(max(0.0, min(poll_s, deadline_s - waited)))

        witness = self._ask_witness(notes)
        waited = self._now() - t0
        if witness is not None and witness.configured is True:
            notes.append("witness says the FPGA IS configured (usercode %s) but "
                         "nothing answered: configured+inert is a hung image, "
                         "not a dark boot" % (witness.usercode or "?"))
            outcome = OUTCOME_TIMEOUT
        elif saw_connect:
            notes.append("the control channel accepted a connection but never "
                         "reported a shell_id: alive, not converged")
            outcome = OUTCOME_TIMEOUT
        else:
            outcome = OUTCOME_DARK
            if witness is None:
                notes.append("no witness configured: 'dark' here means 'nothing "
                             "answered within the deadline', not 'DONE low'")
        return self._record_iteration(index, t_reset_wall, None, waited, outcome,
                                      probe if probe and probe.up else None,
                                      witness, notes)

    def _record_iteration(self, index, t_reset_wall, t_ping_wall, waited,
                          outcome, probe, witness, notes) -> Dict[str, Any]:
        sha = self._mcc_log_sha(notes)
        return {
            "iteration": index,
            "t_reset": _iso(t_reset_wall),
            "t_first_ping": (_iso(t_ping_wall) if t_ping_wall is not None else None),
            "time_to_ping_s": (round(waited, 3) if outcome == OUTCOME_UP else None),
            "waited_s": round(waited, 3),
            "outcome": outcome,
            "static_id": (probe.shell_id if probe is not None and probe.shell_id
                          else None),
            "version": (probe.version if probe is not None else None),
            "mcc_log_sha": sha,
            "witness": (witness.to_json() if witness is not None else None),
            "notes": notes,
        }

    # -- the campaign -------------------------------------------------------- #

    def run(
        self,
        *,
        n: int,
        method: str,
        deadline_s: float = DEFAULT_DEADLINE_S,
        poll_s: float = DEFAULT_POLL_S,
        gap_s: float = DEFAULT_GAP_S,
        down_deadline_s: float = DEFAULT_DOWN_DEADLINE_S,
        await_down: bool = True,
        variant: Optional[str] = None,
        token: Optional[str] = None,
        notes: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        check_method(method)
        if n < 1:
            raise BootRateInputError("--n must be at least 1")
        if poll_s <= 0:
            # The poll interval is what makes the wait loops advance. At 0 they
            # busy-spin on the shell for the whole deadline, and against an
            # injected clock they never advance at all.
            raise BootRateInputError("--poll must be greater than 0")
        if deadline_s <= 0:
            raise BootRateInputError("--deadline must be greater than 0")
        if await_down and down_deadline_s <= 0:
            # A zero down-window would record EVERY iteration as hub-error
            # ("never stopped answering" at t=0) for anyone who meant "do not
            # wait for a down edge". Say which flag they wanted.
            raise BootRateInputError(
                "--down-deadline must be greater than 0; to skip the down-edge "
                "wait entirely pass --no-await-down (the record then says the "
                "first answer may be the pre-reboot shell)")
        variant_keys: Dict[str, Dict[str, str]] = {}
        variant_desc = None
        if variant:
            delta = variant_delta(variant)      # refuses an unknown name
            variant_keys = delta["keys"]
            variant_desc = delta["description"]
        holder = self._require_lease()

        started = self._wall()
        iterations: List[Dict[str, Any]] = []
        for i in range(n):
            iterations.append(self._iteration(
                i, method=method, deadline_s=deadline_s, poll_s=poll_s,
                down_deadline_s=down_deadline_s, await_down=await_down,
                token=token))
            self._say("iteration %d: %s" % (i, iterations[-1]["outcome"]))
            if gap_s and i < n - 1:
                self._sleep(gap_s)

        campaign = {
            "n": n,
            "method": method,
            "deadline_s": deadline_s,
            "poll_s": poll_s,
            "gap_s": gap_s,
            "down_deadline_s": down_deadline_s,
            "await_down": await_down,
            "variant": variant,
            "variant_keys": variant_keys,
            "variant_description": variant_desc,
            "started_at": _iso(started),
            "finished_at": _iso(self._wall()),
            "chassis": (self._lease.chassis if self._lease else None),
            "target": (self._lease.target if self._lease else None),
            "holder": holder,
            "host": self.host,
            "control_port": self.control_port,
            "mcc_log_path": self.mcc_log_path,
            # The COMMAND, when there is one: "CommandWitness" is not a fact
            # anyone can reproduce six weeks later, and which xsdb script read
            # DONE is exactly the sort of thing that goes missing.
            "witness": (getattr(self._witness, "cmd", None)
                        or type(self._witness).__name__) if self._witness else None,
            "tool": "pyverify boot-rate",
            "notes": list(notes or []),
        }
        summary = summarise(iterations)
        # The summary is what gets printed, pasted into a report and read six
        # weeks later. A rate without the configuration it was measured in is
        # the "about 1 time in 4" problem all over again, so the three fields
        # that identify the experiment ride along with it.
        summary["variant"] = variant
        summary["method"] = method
        summary["deadline_s"] = deadline_s
        return {"schema": SCHEMA_ID, "campaign": campaign,
                "iterations": iterations, "summary": summary}


# --------------------------------------------------------------------------- #
# arithmetic
# --------------------------------------------------------------------------- #


def wilson(k: int, n: int, z: float = 1.96) -> Tuple[float, float]:
    """95% Wilson score interval for ``k`` successes in ``n`` trials.

    Wilson rather than the textbook normal interval because at N=10 and p near
    0 or 1 the normal one runs off the end of the scale and reports impossible
    bounds — precisely the regime this board is in. No SciPy: pyverify has no
    runtime dependencies by design.
    """
    if n <= 0:
        return (0.0, 1.0)
    p = k / float(n)
    z2 = z * z
    denom = 1.0 + z2 / n
    centre = (p + z2 / (2.0 * n)) / denom
    half = z * math.sqrt(p * (1.0 - p) / n + z2 / (4.0 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def fisher_exact(a: int, b: int, c: int, d: int) -> float:
    """Two-sided Fisher exact p for the 2x2 table ``[[a, b], [c, d]]``.

    WHY THIS AND NOT "DO THE INTERVALS OVERLAP"
        Overlapping 95% intervals are NOT a test — at N=10 even 3/10 -> 9/10
        overlaps (0.11-0.60 against 0.60-0.98), while the exact test puts that
        same pair at p = 0.020. Reading overlap as "no difference" would have
        the lead discard a genuine fix; the interval is for showing how little
        one campaign pins down, and this is for comparing two.

    Exact enumeration over the hypergeometric distribution — the counts here are
    tens, and pyverify carries no SciPy (values cross-checked against
    ``scipy.stats.fisher_exact`` in the tests).
    """
    from math import comb

    n = a + b + c + d
    if n == 0:
        return 1.0
    row1, col1 = a + b, a + c
    denom = comb(n, col1)
    if denom == 0 or row1 == 0 or row1 == n or col1 == 0 or col1 == n:
        return 1.0

    def prob(x: int) -> float:
        return comb(row1, x) * comb(n - row1, col1 - x) / denom

    lo = max(0, col1 - (n - row1))
    hi = min(row1, col1)
    p_obs = prob(a)
    total = sum(prob(x) for x in range(lo, hi + 1)
                if prob(x) <= p_obs * (1.0 + 1e-9))
    return min(1.0, total)


def summarise(iterations: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Counts, rate, interval and timings.

    THE DENOMINATOR IS THE POINT: a ``hub-error`` iteration is an experiment
    that never ran (the hub refused, or the board never went down), so it is
    excluded from the rate and reported on its own. Counting it as a dark boot
    would report a worse board than we have; counting it as a success, a better
    one.
    """
    counts = {o: 0 for o in OUTCOMES}
    for it in iterations:
        counts[it.get("outcome", OUTCOME_DARK)] = counts.get(
            it.get("outcome", OUTCOME_DARK), 0) + 1
    n = len(iterations)
    valid = n - counts[OUTCOME_HUB_ERROR]
    up = counts[OUTCOME_UP]
    times = [it["time_to_ping_s"] for it in iterations
             if it.get("outcome") == OUTCOME_UP
             and it.get("time_to_ping_s") is not None]
    lo, hi = wilson(up, valid) if valid > 0 else (0.0, 1.0)
    return {
        "n": n,
        "valid": valid,
        "up": up,
        "dark": counts[OUTCOME_DARK],
        "timeout": counts[OUTCOME_TIMEOUT],
        "hub_error": counts[OUTCOME_HUB_ERROR],
        "rate": (up / float(valid) if valid > 0 else None),
        "rate_basis": "up / (n - hub_error)",
        "ci95": [lo, hi],
        "ci_method": "Wilson score, 95%",
        "mean_time_to_ping_s": (sum(times) / len(times) if times else None),
        "max_time_to_ping_s": (max(times) if times else None),
    }


# --------------------------------------------------------------------------- #
# the run record: schema, validation, comparison
# --------------------------------------------------------------------------- #

RUN_RECORD_SCHEMA: Dict[str, Any] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://soclabs.org/mps3/boot-rate/v1.schema.json",
    "title": "MPS3 boot-rate run record",
    "description": (
        "One boot-rate campaign: N reboots of one board in one recorded SD "
        "configuration. Versioned by `schema`; a record of another version is "
        "refused rather than half-read."
    ),
    "type": "object",
    "required": ["schema", "campaign", "iterations", "summary"],
    "properties": {
        "schema": {"const": SCHEMA_ID},
        "campaign": {
            "type": "object",
            "required": ["n", "method", "deadline_s", "variant", "variant_keys",
                         "started_at", "finished_at"],
            "properties": {
                "n": {"type": "integer", "minimum": 1},
                "method": {"type": "string",
                           "description": "the fpgahub reset method driven "
                                          "('mcc' is refused: proven no-op)"},
                "deadline_s": {"type": "number", "exclusiveMinimum": 0},
                "poll_s": {"type": "number"},
                "gap_s": {"type": "number"},
                "down_deadline_s": {"type": "number"},
                "await_down": {"type": "boolean"},
                "variant": {"type": ["string", "null"],
                            "description": "fpga/mps3_sd/variants/<name>, or "
                                           "null for the default bundle"},
                "variant_keys": {
                    "type": "object",
                    "description": "the config-file key deltas that variant "
                                   "applies, READ from the variant directory",
                    "additionalProperties": {
                        "type": "object",
                        "additionalProperties": {"type": "string"},
                    },
                },
                "started_at": {"type": "string"},
                "finished_at": {"type": "string"},
                "chassis": {"type": ["string", "null"]},
                "target": {"type": ["string", "null"]},
                "holder": {"type": ["string", "null"]},
                "host": {"type": "string"},
                "control_port": {"type": "integer"},
                "mcc_log_path": {"type": ["string", "null"]},
                "witness": {"type": ["string", "null"]},
                "notes": {"type": "array", "items": {"type": "string"}},
            },
        },
        "iterations": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["iteration", "t_reset", "t_first_ping", "outcome",
                             "static_id", "version", "mcc_log_sha", "notes"],
                "properties": {
                    "iteration": {"type": "integer", "minimum": 0},
                    "t_reset": {"type": "string",
                                "description": "UTC ISO-8601 of the reset"},
                    "t_first_ping": {"type": ["string", "null"]},
                    "time_to_ping_s": {"type": ["number", "null"]},
                    "waited_s": {"type": "number"},
                    "outcome": {"enum": list(OUTCOMES)},
                    "static_id": {"type": ["string", "null"]},
                    "version": {"type": ["object", "null"]},
                    "mcc_log_sha": {
                        "type": ["string", "null"],
                        "description": "sha256 of the MCC LOG.TXT read through "
                                       "the SD seam, or null with a note",
                    },
                    "witness": {"type": ["object", "null"]},
                    "notes": {"type": "array", "items": {"type": "string"}},
                },
            },
        },
        "summary": {
            "type": "object",
            "required": ["n", "up", "rate", "ci95"],
            "properties": {
                "n": {"type": "integer"},
                "valid": {"type": "integer"},
                "up": {"type": "integer"},
                "dark": {"type": "integer"},
                "timeout": {"type": "integer"},
                "hub_error": {"type": "integer"},
                "rate": {"type": ["number", "null"]},
                "rate_basis": {"type": "string"},
                "ci95": {"type": "array", "items": {"type": "number"},
                         "minItems": 2, "maxItems": 2},
                "ci_method": {"type": "string"},
                "mean_time_to_ping_s": {"type": ["number", "null"]},
                "max_time_to_ping_s": {"type": ["number", "null"]},
                "variant": {"type": ["string", "null"],
                            "description": "carried here as well as in the "
                                           "campaign: a rate without its "
                                           "configuration is folklore"},
                "method": {"type": "string"},
            },
        },
    },
}


def validate_record(record: Any) -> None:
    """Structural validation against :data:`RUN_RECORD_SCHEMA`, by hand.

    Hand-rolled because pyverify is dependency-free on purpose (it gets
    vendored onto a Pi-5 tender and a Jupyter host with nothing but the
    stdlib). This checks what actually goes wrong — a foreign or future schema,
    a missing block, an outcome outside the enum — not every keyword in the
    schema document.
    """
    if not isinstance(record, dict):
        raise BootRateInputError("run record is not a JSON object")
    schema = record.get("schema")
    if schema != SCHEMA_ID:
        raise BootRateInputError(
            "run record schema %r is not %r: this file was written by a "
            "different version of the tool and its fields cannot be trusted to "
            "mean the same thing" % (schema, SCHEMA_ID))
    for key, kind in (("campaign", dict), ("iterations", list), ("summary", dict)):
        if not isinstance(record.get(key), kind):
            raise BootRateInputError("run record is missing a %s block" % key)
    for key in RUN_RECORD_SCHEMA["properties"]["campaign"]["required"]:
        if key not in record["campaign"]:
            raise BootRateInputError("run record campaign is missing %r" % key)
    required_it = RUN_RECORD_SCHEMA["properties"]["iterations"]["items"]["required"]
    for i, it in enumerate(record["iterations"]):
        if not isinstance(it, dict):
            raise BootRateInputError("iteration %d is not an object" % i)
        for key in required_it:
            if key not in it:
                raise BootRateInputError("iteration %d is missing %r" % (i, key))
        if it["outcome"] not in OUTCOMES:
            raise BootRateInputError(
                "iteration %d has outcome %r, which is not one of %s"
                % (i, it["outcome"], ", ".join(OUTCOMES)))


def load_record(path: "os.PathLike[str] | str") -> Dict[str, Any]:
    try:
        raw = Path(path).read_text()
    except OSError as exc:
        raise BootRateInputError("cannot read %s: %s" % (path, exc)) from exc
    try:
        record = json.loads(raw)
    except (json.JSONDecodeError, ValueError) as exc:
        raise BootRateInputError("%s is not valid JSON: %s" % (path, exc)) from exc
    validate_record(record)
    return record


#: Campaign fields whose change makes two runs a BEFORE and an AFTER.
COMPARED_FIELDS = ("variant", "method", "deadline_s", "await_down", "n")


def compare(before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Any]:
    """Diff two campaigns: the rates, the intervals, and the variable(s) that
    changed between them.

    Names every difference rather than assuming the caller changed only one
    thing — an experiment that moved two variables at once is still worth
    printing, but it must SAY it moved two.
    """
    validate_record(before)
    validate_record(after)
    variables: List[Dict[str, Any]] = []
    for field_name in COMPARED_FIELDS:
        b = before["campaign"].get(field_name)
        a = after["campaign"].get(field_name)
        if b != a:
            variables.append({"name": field_name, "before": b, "after": a})
    b_keys = before["campaign"].get("variant_keys") or {}
    a_keys = after["campaign"].get("variant_keys") or {}
    for fname in sorted(set(b_keys) | set(a_keys)):
        bk = b_keys.get(fname, {})
        ak = a_keys.get(fname, {})
        for key in sorted(set(bk) | set(ak)):
            if bk.get(key) != ak.get(key):
                variables.append({"name": "%s:%s" % (fname, key),
                                  "before": bk.get(key, "(template default)"),
                                  "after": ak.get(key, "(template default)")})
    fields_changed = [v["name"] for v in variables if ":" not in v["name"]]
    key_rows = [v for v in variables if ":" in v["name"]]
    # The same variant NAME on both sides with different keys means the variant
    # directory was edited between the runs: each record describes a card the
    # other one is not talking about, and nothing downstream can see that.
    variant_redefined = bool(key_rows) and "variant" not in fields_changed
    bs, as_ = before["summary"], after["summary"]
    b_ci = bs.get("ci95") or [0.0, 1.0]
    a_ci = as_.get("ci95") or [0.0, 1.0]
    overlap = not (b_ci[1] < a_ci[0] or a_ci[1] < b_ci[0])
    b_up, b_valid = bs.get("up", 0), bs.get("valid", bs.get("n", 0))
    a_up, a_valid = as_.get("up", 0), as_.get("valid", as_.get("n", 0))
    p_value = fisher_exact(b_up, b_valid - b_up, a_up, a_valid - a_up)
    return {
        "schema": SCHEMA_ID,
        "before": bs,
        "after": as_,
        "before_campaign": before["campaign"],
        "after_campaign": after["campaign"],
        "variables": variables,
        "fields_changed": fields_changed,
        "variant_redefined": variant_redefined,
        "overlap": overlap,
        "p_value": p_value,
        "p_method": "Fisher exact, two-sided",
        "alpha": 0.05,
        "significant": bool(p_value < 0.05),
        "delta_rate": (None if bs.get("rate") is None or as_.get("rate") is None
                       else as_["rate"] - bs["rate"]),
    }


def _fmt_rate(summary: Dict[str, Any]) -> str:
    rate = summary.get("rate")
    ci = summary.get("ci95") or [0.0, 1.0]
    if rate is None:
        return "no valid attempts (%d hub-error of %d)" % (
            summary.get("hub_error", 0), summary.get("n", 0))
    return "%.2f  (%d/%d, 95%% CI %.2f-%.2f)" % (
        rate, summary.get("up", 0), summary.get("valid", 0), ci[0], ci[1])


def format_compare(cmp: Dict[str, Any]) -> str:
    """The before/after, in the shape a human reads in a terminal."""
    lines = ["boot rate: before -> after", ""]
    lines.append("  before : %s" % _fmt_rate(cmp["before"]))
    lines.append("  after  : %s" % _fmt_rate(cmp["after"]))
    if cmp.get("delta_rate") is not None:
        lines.append("  delta  : %+.2f" % cmp["delta_rate"])
    lines.append("")
    if not cmp["variables"]:
        lines.append("  variable: NONE recorded -- the two campaigns ran the "
                     "same configuration.")
        lines.append("  This is a REPEATABILITY pair, not a before/after.")
    else:
        lines.append("  variable(s) that changed:")
        for var in cmp["variables"]:
            lines.append("    %-24s %s -> %s"
                         % (var["name"], var["before"], var["after"]))
        # The key rows are the DETAIL of a variant change, not extra variables:
        # `--variant ETH_SMB0` moves one variable and shows two keys, and a tool
        # that nagged about that on every legitimate comparison would be ignored
        # by the third one.
        if len(cmp["fields_changed"]) > 1:
            lines.append("    NOTE: %d campaign settings moved (%s). The rule "
                         "is one variable at a time; read this as a story, not "
                         "a result." % (len(cmp["fields_changed"]),
                                        ", ".join(cmp["fields_changed"])))
        if cmp["variant_redefined"]:
            lines.append("    WARNING: both runs name the SAME variant but its "
                         "keys differ -- the variant directory was edited "
                         "between them, so neither record describes the other's "
                         "card.")
    lines.append("")
    lines.append("  Fisher exact (two-sided): p = %.4g" % cmp["p_value"])
    if cmp["significant"]:
        lines.append("  VERDICT: a real difference at this sample size "
                     "(p < %.2f)." % cmp["alpha"])
        if cmp["overlap"]:
            lines.append("  (The 95% intervals still overlap -- at this N "
                         "they almost always do. The exact test is the "
                         "comparison; the interval only shows how little ONE "
                         "campaign pins down.)")
    else:
        lines.append("  VERDICT: NOT a demonstrated difference (p >= %.2f). "
                     "More iterations, or it is noise." % cmp["alpha"])
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# the SD-bundle experiment variants
# --------------------------------------------------------------------------- #


def _variants_dir(root: Optional[Path] = None) -> Path:
    from .fielded import repo_root

    return (Path(root) if root else repo_root()) / VARIANTS_REL


def list_variants(root: Optional[Path] = None) -> List[str]:
    base = _variants_dir(root)
    if not base.is_dir():
        return []
    return sorted(p.name for p in base.iterdir()
                  if p.is_dir() and (p / VARIANT_META).is_file())


def _parse_keys(text: str) -> Dict[str, str]:
    """``KEY: VALUE  ;comment`` — the MCC config dialect the templates use."""
    keys: Dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(";") or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        keys[key.strip()] = value.split(";")[0].strip()
    return keys


def variant_delta(name: str, root: Optional[Path] = None) -> Dict[str, Any]:
    """What ``fpga/mps3_sd/variants/<name>/`` changes, read from the directory.

    The harness never types the keys into the record: an experiment recorded as
    "ETH_SMB0" whose keys were typed by hand is one rename away from claiming a
    configuration the SD never carried.
    """
    base = _variants_dir(root)
    path = base / name
    known = list_variants(root)
    if not (path.is_dir() and (path / VARIANT_META).is_file()):
        raise BootRateInputError(
            "no such SD variant %r under %s. Known variants: %s"
            % (name, base, ", ".join(known) or "(none)"))
    meta = _parse_keys((path / VARIANT_META).read_text())
    keys: Dict[str, Dict[str, str]] = {}
    for f in sorted(path.iterdir()):
        if f.name == VARIANT_META or not f.is_file() or f.suffix.lower() != ".txt":
            continue
        keys[f.name] = _parse_keys(f.read_text())
    return {
        "name": name,
        "description": meta.get("DESCRIPTION", ""),
        "keys": keys,
        "path": str(path),
    }
