"""Board lease client (net-protocol v0.21, feature ``board_lease``).

Single-user mode: the board itself is the lease server; this is the client side.
Interface frozen at F0 (Release 3, 14 Oct 2026, RELEASE3_LANES.md); lane P1 filled it.
Every parser tolerates missing optional keys and extra keys (a newer board).

Wire rules (docs/contracts/net-protocol.md, v0.21 "Board lease and panel access"):
- verb ``lease`` with the acts in ``ACTS``; every time on the wire is RELATIVE seconds
  (the board has no wall clock);
- ``acquire`` returns a 32-hex token; every gated verb then carries a top-level
  ``"lease": "<token>"`` (``with_token``);
- refusals keep the usual shape ``{"ok": false, "err": ..., "code": ...}``.

Not to be confused with ``pyverify.lease`` (the fpgahub hub-lease client).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

#: Engine feature names (clients test names, never the protocol version).
FEATURE = "board_lease"
FEATURE_PANEL_ACCESS = "panel_access"

#: The ``lease`` verb's acts.
ACTS = ("show", "history", "acquire", "heartbeat", "release", "request", "respond",
        "cancel", "revoke", "mode")

#: Modes.
MODE_OPEN = "open"
MODE_SINGLE = "single_user"

#: Refusal codes added by v0.21 (on top of the v0.20 set and the claim gate's ``locked``).
CODES = ("leased", "lease_required", "lease_held", "bad_token", "queue_full", "local_hold",
         "not_holder", "busy_access")

#: Defaults (the plan's recommended policy; the board is the authority).
DEFAULT_TTL_S = 3600
REQUEST_WINDOW_S = 120
RECLAIM_S = 300
LOCAL_HOLD_S = 900
QUEUE_MAX = 4
TOKEN_HEX = 32

#: Field limits the board enforces (``invalid <field>``); checked here so a bad call
#: raises ``ValueError`` before anything is sent.
TTL_MIN_S, TTL_MAX_S = 300, 14400
MSG_MAX = 48
MINUTES_MIN, MINUTES_MAX = 5, 60
HISTORY_MAX = 8
MODES = (MODE_OPEN, MODE_SINGLE)


def _int(v: Any, default: int = 0) -> int:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return default
    return int(v)


def _str(v: Any) -> str:
    return v if isinstance(v, str) else ""


@dataclass(frozen=True)
class Holder:
    who: str
    app: str = ""
    held_s: int = 0
    expires_in_s: int = 0
    you: bool = False

    @classmethod
    def from_reply(cls, d: Dict[str, Any]) -> "Holder":
        return cls(who=_str(d.get("who")), app=_str(d.get("app")),
                   held_s=_int(d.get("held_s")), expires_in_s=_int(d.get("expires_in_s")),
                   you=d.get("you") is True)


@dataclass(frozen=True)
class Waiter:
    id: str
    who: str
    msg: str = ""
    age_s: int = 0

    @classmethod
    def from_reply(cls, d: Dict[str, Any]) -> "Waiter":
        return cls(id=_str(d.get("id")), who=_str(d.get("who")), msg=_str(d.get("msg")),
                   age_s=_int(d.get("age_s")))


@dataclass(frozen=True)
class LeaseView:
    """``lease show`` (also the ``heartbeat`` / ``mode`` reply): the board's lease table
    as seen by this peer. ``persistent`` False = no card, the mode is lost at power-off
    (an absent key is read as True: only an explicit false warns). ``owner``: this caller
    presented the owner key (absent = False)."""
    mode: str
    holder: Optional[Holder]
    queue: List[Waiter] = field(default_factory=list)
    local_hold_s: int = 0
    reclaim_s: int = 0
    persistent: bool = True
    owner: bool = False

    @classmethod
    def from_reply(cls, reply: Dict[str, Any]) -> "LeaseView":
        h = reply.get("holder")
        q = reply.get("queue")
        return cls(
            mode=_str(reply.get("mode")) or MODE_OPEN,
            holder=Holder.from_reply(h) if isinstance(h, dict) else None,
            queue=[Waiter.from_reply(w) for w in q if isinstance(w, dict)]
            if isinstance(q, list) else [],
            local_hold_s=_int(reply.get("local_hold_s")),
            reclaim_s=_int(reply.get("reclaim_s")),
            persistent=reply.get("persistent") is not False,
            owner=reply.get("owner") is True,
        )


@dataclass(frozen=True)
class AcquireResult:
    """``acquire``: granted with a token, or QUEUED (``ok:true``, ``granted:false``,
    ``position`` / ``id`` / ``code`` ``lease_held``). A queued caller is in the queue:
    it is not a refusal."""
    granted: bool
    token: str = ""
    expires_in_s: int = 0
    position: int = 0
    code: str = ""
    id: str = ""

    @classmethod
    def from_reply(cls, reply: Dict[str, Any]) -> "AcquireResult":
        if reply.get("granted") is True:
            return cls(granted=True, token=_str(reply.get("token")),
                       expires_in_s=_int(reply.get("expires_in_s")))
        return cls(granted=False, position=_int(reply.get("position")),
                   code=_str(reply.get("code")), id=_str(reply.get("id")))


@dataclass(frozen=True)
class IdentifyLease:
    """The ``lease`` block of an identify reply (never a token): ``who`` only while held."""
    mode: str
    held: bool = False
    who: str = ""
    left_s: int = 0
    queue: int = 0


def identify_lease(raw: Dict[str, Any]) -> Optional[IdentifyLease]:
    """Parse identify's ``lease`` key from the reply object (``IdentifyReply.raw``);
    None when absent (no ``board_lease`` feature, or a v0.20 board)."""
    d = raw.get("lease")
    if not isinstance(d, dict):
        return None
    return IdentifyLease(mode=_str(d.get("mode")) or MODE_OPEN, held=d.get("held") is True,
                         who=_str(d.get("who")), left_s=_int(d.get("left_s")),
                         queue=_int(d.get("queue")))


@dataclass(frozen=True)
class PresenceLease:
    """The optional ``lease`` key of a ``hello`` or ``panel`` REPLY: whether the board is in
    single-user mode, whether the lease is held, and how many wait. No holder name, never a
    token. (Unrelated to the hello REQUEST's ``lease`` key, the hub relay dict.)"""
    single_user: bool
    held: bool
    queue: int


def presence_lease(reply: Dict[str, Any]) -> Optional[PresenceLease]:
    """Parse the ``lease`` key of a hello/panel reply; None when absent (an old board, or
    lease not served) or malformed (not an object, or a wrong-typed field)."""
    d = reply.get("lease") if isinstance(reply, dict) else None
    if not isinstance(d, dict):
        return None
    su, held, q = d.get("single_user"), d.get("held"), d.get("queue")
    if not isinstance(su, bool) or not isinstance(held, bool):
        return None
    if isinstance(q, bool) or not isinstance(q, int) or q < 0:
        return None
    return PresenceLease(su, held, q)


class BoardLeaseError(Exception):
    """A board refusal of a lease act; ``code`` is one of ``CODES`` or a v0.20 code."""

    def __init__(self, err: str, code: str = "") -> None:
        super().__init__(err)
        self.err = err
        self.code = code


def with_token(request: Dict[str, Any], token: Optional[str]) -> Dict[str, Any]:
    """Add ``"lease": token`` to a gated request (no-op without a token; STRING only: the
    board answers a non-string top-level ``lease`` with ``bad args``). Returns a new
    dict (the input is not changed); a ``"lease"`` already in the request wins."""
    out = dict(request)
    if token and isinstance(token, str) and "lease" not in out:
        out["lease"] = token
    return out


def _check_ok(reply: Dict[str, Any]) -> Dict[str, Any]:
    if not reply.get("ok"):
        raise BoardLeaseError(_str(reply.get("err")) or "lease refused", _str(reply.get("code")))
    return reply


class BoardLease:
    """The board-lease acts over a :class:`pyverify.client.ShellClient` (anything with
    ``lease(act, **fields) -> raw reply``). ``token`` is kept on the instance after a
    grant; when the client has a ``lease_token`` attribute it is kept in step, so the
    client's gated verbs carry it too. Refusals raise :class:`BoardLeaseError`."""

    def __init__(self, client: Any) -> None:
        self._client = client
        self.token: Optional[str] = None
        #: ``expires_in_s`` of the last grant (acquire or mode on); 0 = none yet.
        self.expires_in_s: int = 0

    # -- token bookkeeping ------------------------------------------------ #

    def with_token(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """:func:`with_token` with this instance's token."""
        return with_token(request, self.token)

    def use_token(self, token: Optional[str]) -> None:
        """Adopt a token obtained elsewhere (e.g. ``--token`` on the CLI)."""
        self.token = token or None
        if hasattr(self._client, "lease_token"):
            self._client.lease_token = self.token

    def _need_token(self) -> str:
        if not self.token:
            raise BoardLeaseError("no lease token (acquire first)", "lease_required")
        return self.token

    def _call(self, act: str, **fields: Any) -> Dict[str, Any]:
        return _check_ok(self._client.lease(act, **fields))

    # -- acts ------------------------------------------------------------- #

    def show(self) -> LeaseView:
        f: Dict[str, Any] = {"lease": self.token} if self.token else {}
        return LeaseView.from_reply(self._call("show", **f))

    def history(self, n: int = HISTORY_MAX) -> List[Dict[str, Any]]:
        if not 1 <= n <= HISTORY_MAX:
            raise ValueError("history n must be 1..%d" % HISTORY_MAX)
        # each event: ev, who (the ACTOR; "" = the board), age_s, info (a revoke's info
        # reads "from <revoked holder>")
        ev = self._call("history", n=n).get("events")
        return [e for e in ev if isinstance(e, dict)] if isinstance(ev, list) else []

    def acquire(self, who: str, app: str = "", ttl_s: int = DEFAULT_TTL_S) -> AcquireResult:
        if not who:
            raise ValueError("acquire needs who")
        if not TTL_MIN_S <= ttl_s <= TTL_MAX_S:
            raise ValueError("ttl_s must be %d..%d" % (TTL_MIN_S, TTL_MAX_S))
        f: Dict[str, Any] = {"who": who, "ttl_s": ttl_s}
        if app:
            f["app"] = app
        res = AcquireResult.from_reply(self._call("acquire", **f))
        if res.granted:
            self.use_token(res.token)
            self.expires_in_s = res.expires_in_s
        return res

    def heartbeat(self, ttl_s: Optional[int] = None) -> LeaseView:
        f: Dict[str, Any] = {"lease": self._need_token()}
        if ttl_s is not None:
            if not TTL_MIN_S <= ttl_s <= TTL_MAX_S:
                raise ValueError("ttl_s must be %d..%d" % (TTL_MIN_S, TTL_MAX_S))
            f["ttl_s"] = ttl_s
        return LeaseView.from_reply(self._call("heartbeat", **f))

    def release(self) -> None:
        self._call("release", lease=self._need_token())
        self.use_token(None)

    def request(self, who: str, msg: str = "") -> str:
        """Ask the holder; returns the request id."""
        if not who:
            raise ValueError("request needs who")
        if len(msg) > MSG_MAX:
            raise ValueError("msg is at most %d characters" % MSG_MAX)
        f: Dict[str, Any] = {"who": who}
        if msg:
            f["msg"] = msg
        return _str(self._call("request", **f).get("id"))

    def respond(self, request_id: str, accept: bool, minutes: Optional[int] = None) -> None:
        f: Dict[str, Any] = {"lease": self._need_token(), "id": request_id,
                             "accept": bool(accept)}
        if not accept:
            if minutes is not None:
                if not MINUTES_MIN <= minutes <= MINUTES_MAX:
                    raise ValueError("minutes must be %d..%d" % (MINUTES_MIN, MINUTES_MAX))
                f["minutes"] = minutes
        elif minutes is not None:
            raise ValueError("minutes only applies to accept=False (keep)")
        self._call("respond", **f)
        if accept:                       # the lease was given back
            self.use_token(None)

    def cancel(self, request_id: str) -> None:
        self._call("cancel", id=request_id)

    def revoke(self, confirm_board: str = "") -> None:
        """(Reply is exactly ``{"ok":true,"op":"lease","act":"revoke"}``; a ``busy`` refusal
        also reads ``lease revoke: no unanswered request``.) Force, as the queue head, after the holder left a request unanswered 120 s.
        ``confirm_board`` is the board's label, typed by the user."""
        self._call("revoke", confirm=confirm_board)

    def set_mode(self, mode: str, ttl_s: Optional[int] = None) -> LeaseView:
        """Switch the mode. ``single_user`` also grants the owner the lease (``ttl_s``
        300-14400, board default 3600): the token (and ``expires_in_s``) in the reply are
        kept on this instance."""
        if mode not in MODES:
            raise ValueError("mode must be one of %s" % (MODES,))
        f: Dict[str, Any] = {"mode": mode}
        if ttl_s is not None:
            if mode != MODE_SINGLE:
                raise ValueError("ttl_s only applies to mode single_user")
            if not TTL_MIN_S <= ttl_s <= TTL_MAX_S:
                raise ValueError("ttl_s must be %d..%d" % (TTL_MIN_S, TTL_MAX_S))
            f["ttl_s"] = ttl_s
        reply = self._call("mode", **f)
        if mode == MODE_SINGLE and _str(reply.get("token")):
            self.use_token(_str(reply.get("token")))
            self.expires_in_s = _int(reply.get("expires_in_s"))
        elif mode == MODE_OPEN:
            self.use_token(None)
        return LeaseView.from_reply(reply)
