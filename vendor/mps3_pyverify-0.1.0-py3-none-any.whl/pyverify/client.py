"""``ShellClient`` — control-channel client for the shell coordinator.

Speaks the JSON-line request/response protocol on **TCP 6900** described in
``docs/contracts/net-protocol.md`` ("Control channel (TCP 6900) — JSON
lines"). pyverify is the *client*; the MicroBlaze/lwIP shell firmware (A3)
is the *server*.

Framing (net-protocol.md): one JSON object per line, ``\\n``-terminated,
strict request -> response (no pipelining, no server-initiated pushes).
This module implements that framing for real over a plain TCP socket; the
only thing that requires a live shell is actually opening the connection,
which happens in :meth:`ShellClient.connect` / on first use as a context
manager.

Testability: all I/O goes through the :class:`Transport` protocol. The
default (:class:`SocketTransport`) is a real, correct socket implementation.
Tests inject a fake transport (see ``host/pyverify/tests/test_client.py``)
so the request/response framing and response-parsing logic can be verified
with no socket, no board, and no network — only the *framing* is claimed
"REAL" per the task brief; there is no way to exercise "does the real
board answer" without hardware.
"""
from __future__ import annotations

import json
import socket
import time
from dataclasses import dataclass
from typing import Any, Optional, Protocol, Sequence, runtime_checkable

__all__ = [
    "CONTROL_PORT",
    "DEFAULT_CLK_PRESETS",
    "MACGEN_INJECTS",
    "validate_clk_preset",
    "validate_macgen_inject",
    "ShellClient",
    "ShellProtocolError",
    "PingResponse",
    "ResetResponse",
    "SetClkResponse",
    "SwapResponse",
    "LinkResponse",
    "CommitResponse",
    "TelemetryResponse",
    "MacGenResponse",
    "DiagResponse",
    "DisplayResponse",
    "DisplaySettleResponse",
    "DISPLAY_OWNERS",
    "validate_display_owner",
    "Transport",
    "SocketTransport",
]

# net-protocol.md port map: "6900 | TCP | control/status ... | A3 coordinator"
CONTROL_PORT = 6900

#: The closed set of ``macgen`` inject fault names (net-protocol.md "MAC
#: gen/checker control"; mirrors shell-regmap.md GENCHK.INJECT + the firmware
#: ``macgen_inject_bits`` table). ``"none"`` clears/arms nothing.
MACGEN_INJECTS: "tuple[str, ...]" = (
    "none", "bad_fcs", "runt", "giant", "ifg", "dribble",
)

#: The closed set of owner values a ``display`` *request* may name (the CLCD KVM
#: remote flip, net-protocol.md "display"; mirrors the firmware
#: ``coordinator_handle_display`` accepted set minus the read-only ``"query"``,
#: which :meth:`ShellClient.display_owner` sends on its own). ``"toggle"`` flips
#: the requested target the way ``USER_nPB[1]`` does.
DISPLAY_OWNERS: "tuple[str, ...]" = ("harness", "dut", "toggle")

#: Client-side closed set of ``set_clk`` preset names. Source of truth:
#: ``firmware/clkrst/clkrst.c``'s ``clkrst_preset_table`` — currently the
#: explicit *placeholder* table ``"25mhz"/"50mhz"/"100mhz"`` (ids 0/1/2).
#: The contract still doesn't enumerate presets: that's
#: ``docs/contracts/OPEN_ISSUES.md`` **I16** (A6-owned — the real DRP table
#: is A1/A3's to publish; this tuple does not close it). When I16 lands,
#: update this tuple in lockstep with the firmware table. Matching is
#: exact/case-sensitive, mirroring the firmware's ``strcmp`` lookup.
DEFAULT_CLK_PRESETS: "tuple[str, ...]" = ("25mhz", "50mhz", "100mhz")


def validate_clk_preset(
    preset: str, presets: "Optional[Sequence[str]]" = DEFAULT_CLK_PRESETS,
) -> None:
    """Fail a ``set_clk`` typo client-side instead of round-tripping it.

    Raises ``ValueError`` when ``preset`` is not in ``presets``. Escape
    hatch so the closed set can evolve ahead of this client:
    ``presets=None`` skips the check entirely (send anything — useful the
    moment the firmware table grows a name this tuple hasn't caught up
    with), or pass your own sequence to validate against a different set.
    """
    if presets is None:
        return
    if preset not in presets:
        raise ValueError(
            f"set_clk: unknown preset {preset!r} (client-side check; known "
            f"presets: {', '.join(presets)} — placeholder table from "
            "firmware/clkrst/clkrst.c, pending OPEN_ISSUES.md I16; pass "
            "presets=None to send it to the shell anyway)"
        )


def validate_macgen_inject(
    inject: str, injects: "Optional[Sequence[str]]" = MACGEN_INJECTS,
) -> None:
    """Fail a ``macgen`` inject typo client-side instead of round-tripping it.

    Raises ``ValueError`` when ``inject`` is not in ``injects``. Like
    :func:`validate_clk_preset`, ``injects=None`` skips the check entirely so
    the closed set can evolve ahead of this client. The raw
    :meth:`ShellClient.macgen` is wire-transparent by default (sends anything,
    so the conformance suites can prove the *server* rejects an unknown fault);
    :meth:`pyverify.board.Mps3Board.macgen` and :mod:`pyverify.mactest`
    validate up front.
    """
    if injects is None:
        return
    if inject not in injects:
        raise ValueError(
            f"macgen: unknown inject {inject!r} (client-side check; known: "
            f"{', '.join(injects)} — shell-regmap.md GENCHK.INJECT; pass "
            "injects=None to send it to the shell anyway)"
        )


def validate_display_owner(
    owner: str, owners: "Optional[Sequence[str]]" = DISPLAY_OWNERS,
) -> None:
    """Fail a ``display`` owner typo client-side instead of round-tripping it.

    Raises ``ValueError`` when ``owner`` is not in ``owners``. Escape hatch
    ``owners=None`` skips the check (send anything — the server validates too:
    an unknown owner is a clean ``{"ok":false,"err":"bad owner"}``). The
    read-only ``"query"`` value is deliberately NOT in the default set —
    :meth:`ShellClient.display_owner` sends it; a caller flipping ownership
    should not.
    """
    if owners is None:
        return
    if owner not in owners:
        raise ValueError(
            f"display: unknown owner {owner!r} (client-side check; known: "
            f"{', '.join(owners)} — net-protocol.md 'display'; pass owners=None "
            "to send it to the shell anyway)"
        )


class ShellProtocolError(Exception):
    """The shell's response didn't parse, or violated the line-JSON framing.

    Distinct from a verb-level failure (``{"ok": false}``), which is
    reported through the response dataclass's ``ok`` field so callers can
    decide how to react (e.g. ``swap`` failing is often recoverable; a
    malformed line from the shell is not).
    """


# --------------------------------------------------------------------------- #
# Response shapes (net-protocol.md "Control channel" examples)
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class PingResponse:
    ok: bool
    shell_id: str = ""
    rm_id: str = ""


@dataclass(frozen=True)
class ResetResponse:
    ok: bool


@dataclass(frozen=True)
class SetClkResponse:
    ok: bool
    locked: bool = False


@dataclass(frozen=True)
class SwapResponse:
    ok: bool
    rm_id: str = ""
    verified: bool = False


@dataclass(frozen=True)
class LinkResponse:
    ok: bool


@dataclass(frozen=True)
class CommitResponse:
    ok: bool
    slot: str = ""


@dataclass(frozen=True)
class TelemetryResponse:
    """``telemetry`` reply — **always a failure** (net-protocol.md v0.6).

    ``ok`` is always ``False`` and ``err`` is always ``"no power sensor"``:
    this platform has **no power sensor reachable by any path** (the TELEM
    block's sample inputs are tied to ground in the block design, its INA228
    I2C engine was never written, its pads are not on the top level, and the
    MPS3 MCC refuses voltage reads). The verb has no success shape at all.

    **There are deliberately no ``mv``/``ma`` fields.** They are *absent*,
    not zero. Until v0.6 this dataclass carried ``mv: float = 0.0`` /
    ``ma: float = 0.0`` parsed with ``float(resp.get("mv", 0.0))`` — which,
    against a v0.6 shell, would hand every caller a permanent, plausible
    ``mv=0.0`` alongside ``ok=False``: exactly the reading-shaped lie the
    protocol change exists to kill, only host-side. Removing the attributes
    (rather than defaulting or Optional-ing them) means there is nothing for
    a caller to misread: ``resp.mv`` is an ``AttributeError``, and a caller
    who wants to know why gets the explicit :attr:`err`.

    :attr:`lockup` IS real and is carried on the failure line — the single
    documented carve-out to the protocol's uniform failure shape (telemetry
    is its only carrier, because it has no success line to put it on). It is
    the raw ``DFXCTL.RM_STATUS.dut_lockup`` pin and is read regardless of
    ``ok``. Note it is only *meaningful* for RMs that actually drive that pin
    (``nanosoc_multicore`` does; ``nanosoc``, ``eth_ss`` and the OOC RMs
    hard-tie it to 0) — ``lockup=False`` from an RM that ties it off means
    "cannot report lockup", NOT "the DUT is healthy".
    """

    ok: bool
    err: str = ""
    lockup: bool = False


@dataclass(frozen=True)
class DisplayResponse:
    """``display`` reply — the CLCD KVM remote ownership flip (net-protocol.md
    "display"; shell-regmap.md CLCDKVM).

    On success :attr:`owner` is the **committed** panel owner read back from
    ``CLCDKVM.STATUS.owner`` — ``"harness"`` or ``"dut"``. Note it is the
    *committed* owner, which can lag a just-requested flip by the hardware
    handover (drain → reset → settle → grant, ~7–9 ms): immediately after
    ``set_display_owner("dut")`` this may still read ``"harness"``. Re-query
    with :meth:`ShellClient.display_owner` to confirm the landing.

    On a shell whose bitstream has **no** CLCD KVM slave (``MPS3_HAS_CLCD_KVM``
    off — today's board, before the Wave-4 rebuild) the verb decodes but the
    handler declines: ``ok=False`` and :attr:`err` == ``"clcd_kvm not present"``
    (:attr:`owner` empty). Clients key on :attr:`ok`.
    """

    ok: bool
    owner: str = ""
    err: str = ""


@dataclass
class DisplaySettleResponse:
    """The result of a flip that WAITED for the hardware handover to land.

    ``display`` is send-now: the reply carries ``CLCDKVM.STATUS.owner``, the
    *committed* owner, and a flip takes a drain -> panel reset -> settle ->
    grant to commit (~7-9 ms), so the reply to the flip itself routinely names
    the OUTGOING owner (net-protocol.md "Display"). Every caller that actually
    wants "the panel is now the DUT's" therefore has to re-``query`` until it
    is -- which is exactly what a human doing the board proof was doing by
    hand, badly, with no timeout.

    :attr:`landed` is the whole point: True means a follow-up read-only query
    reported the requested owner. False with ``ok=True`` means the shell
    accepted the request and the owner had not committed within the budget --
    an INCONCLUSIVE result, not a failure, and the two must not be confused
    (see docs/CLCD_KVM_PLAN.md "Proving it").
    """

    ok: bool
    requested: str = ""
    owner: str = ""            # the last committed owner observed
    landed: bool = False
    polls: int = 0             # follow-up queries sent
    waited_s: float = 0.0
    err: str = ""


@dataclass(frozen=True)
class MacGenResponse:
    """``macgen`` reply — the three GENCHK counters after the CTRL/INJECT
    write (net-protocol.md "MAC gen/checker control").

    ``err`` here is the ``ERR_CNT`` *counter* (an int), populated only when
    ``ok`` is true; on a failure reply the wire ``"err"`` key is the
    diagnostic *string* (uniform failure shape) and is not parsed into this
    field — callers key on :attr:`ok`.
    """

    ok: bool
    tx: int = 0
    rx: int = 0
    err: int = 0


@dataclass(frozen=True)
class VersionResponse:
    """``version`` reply — the build identity of the RUNNING image
    (net-protocol.md v0.8).

    This is the answer to "which firmware is on this board", which
    :meth:`ShellClient.ping` cannot give: ``ping`` reports ``shell_id`` (the
    fabric's ``static_id``) and ``rm_id`` (what is in the RP), and **one
    static_id serves many harness releases** — a firmware-only bump re-bakes the
    bitstream via ``updatemem`` without changing the static routing. So a board
    can report the expected ``static_id``, pass every acceptance gate, and still
    be running an image built with the wrong flags. That is not hypothetical: an
    image built without ``HWICAP_FIFO=1`` against a FIFO shell pings, reports the
    right ``static_id``, and silently loads no RM.

    - ``harness`` — semantic release, e.g. ``"1.0.0"`` (``"0.0.0"`` = built with
      no generated identity, i.e. "not provisioned" — never a shipped harness);
    - ``ver32`` — the packed ``HARNESS_VER32`` as ``"0x"`` + 8 lowercase hex.
      The SAME 32-bit value is stamped into the bitstream's ``USR_ACCESS``, so
      comparing this against a JTAG ``REGISTER.USR_ACCESS`` read detects
      firmware/bitstream skew with no firmware running on the other side;
    - ``sha``/``dirty`` — build commit (8 hex, ``"unknown"`` if not provisioned)
      and whether the tree had uncommitted changes. ``dirty`` is an ``int``
      (0/1) on the wire, mirroring ``ver32``'s flags byte;
    - ``lmb_kb`` — the LMB size this image was **linked** for. Load-bearing: the
      LMB decode ALIASES, so a 1024 image running on a 512 shell reads the wrong
      diagnostic mailbox and says nothing about it;
    - ``features`` — compile-time flags, a tuple in the firmware's fixed order
      (``clcd``, ``clcd_kvm``, ``touch``, ``hwicap_fifo``, ``windowed``), absent
      ones omitted. The fielded set (``PRODUCT=1``) is all five;
    - ``usr_access``/``skew`` — the **cross-check**. ``ver32`` is what the image
      was BUILT as; ``usr_access`` is what the FABRIC says it is, read back from
      the bitstream's ``USR_ACCESS`` (AXSS) register. One generator
      (``scripts/gen_version.py``) feeds both the firmware constant and
      ``build_dfx.tcl``'s ``BITSTREAM.CONFIG.USR_ACCESS``, so they agree by
      construction unless the ``.bit`` and the image baked into it came from
      different builds — the "flashable base whose ``updatemem`` was never
      re-run" hazard. ``skew`` is the FIRMWARE's verdict on its own two values,
      never computed here.

    **Three states, and the third is not a pass.** ``skew is False`` means the
    image and the bitstream agree. ``skew is True`` means they do not, and the
    board is carrying a firmware/bitstream mismatch. ``skew is None`` (with
    ``usr_access == ""``) means the fabric value could not be read, so **no
    comparison was made** — a shell with no ``DFXCTL.SHELL_USR_ACCESS`` register
    reports exactly this, and reading it as "fine" is the mistake the whole
    verdict exists to prevent. :attr:`skew_verdict` spells the three out.
    """

    ok: bool
    harness: str = ""
    ver32: str = ""
    sha: str = ""
    dirty: bool = False
    lmb_kb: int = 0
    features: tuple[str, ...] = ()
    #: what the FABRIC reports (``"0x01000001"``); ``""`` = could not be read
    usr_access: str = ""
    #: the firmware's verdict: ``False`` agree, ``True`` SKEW, ``None`` not checked
    skew: bool | None = None

    @property
    def skew_verdict(self) -> str:
        """``"ok"`` | ``"SKEW"`` | ``"unchecked"`` — never a silent default.

        Kept out of ``__bool__`` and out of ``ok`` on purpose: ``version`` still
        answered successfully when it reports a skew, and conflating "the verb
        worked" with "the board is consistent" is how a mismatch stays
        invisible. Callers that gate on consistency test THIS.
        """
        if self.skew is None:
            return "unchecked"
        return "SKEW" if self.skew else "ok"


#: ``net_proto.h``'s ``MPS3_DUTRX_CHUNK_MAX``: the most bytes of a frame one
#: ``dutrx`` reply can carry. Exported so a caller can size a read loop, and so
#: a test can assert the client never assumed a different number than the
#: firmware uses -- they are a matched pair.
DUTRX_CHUNK = 256


@dataclass(frozen=True)
class DutRxResponse:
    """``dutrx`` reply — ONE CHUNK of a frame the DUT transmitted
    (net-protocol.md v0.10 "DUT egress"; shell-regmap.md **DUTEGR**).

    This is the DUT's Ethernet RETURN path. Reception has been silicon-proven
    since 2026-07-30; until the capture block existed, every frame the DUT
    transmitted arrived at the bridge's management egress and was drained into a
    constant — **a DUT could be talked to and could not answer**.

    - ``frame_len`` — the head frame's TOTAL length; ``off``/``n`` locate this
      chunk inside it, and ``data`` is the raw bytes (decoded here from the
      wire's lowercase hex). Frames INCLUDE their 4-byte FCS.
    - ``more`` — bytes of THIS frame remain; ask again. ``last`` is the block's
      SECOND, independent end-of-frame record (the ``DATA[9]`` bit on this
      chunk's final byte) — reported raw beside the length, never reconciled
      with it, because their disagreement is what latches ``desync``.
    - ``frames`` — frames still waiting AFTER this chunk.
    - ``rx``/``drop_full``/``drop_giant`` — **read these**. The capture block
      cannot backpressure the bridge (that parks the whole bridge), so it
      DROPS, and ``rx + drop_full + drop_giant`` is its tally against frames
      presented. A caller that reads frames without reading these is counting
      only what survived.
    - ``ovf``/``desync`` — sticky status bits, raw.

    On a shell whose bitstream has **no** DUTEGR slave (the fielded one, minted
    before the block existed) the verb decodes but the handler declines:
    ``ok=False``, ``err == "dut_egress not present"``. That is deliberately NOT
    an empty-looking success: "this fabric cannot capture" must not read the
    same as "the DUT sent nothing".
    """

    ok: bool
    #: wire key ``len`` — renamed only here, where ``len`` would shadow a builtin
    frame_len: int = 0
    off: int = 0
    n: int = 0
    more: bool = False
    last: bool = False
    frames: int = 0
    rx: int = 0
    drop_full: int = 0
    drop_giant: int = 0
    ovf: bool = False
    desync: bool = False
    data: bytes = b""
    err: str = ""

    @property
    def drops(self) -> int:
        """``drop_full + drop_giant`` — frames the block ACCEPTED and could not
        keep. Non-zero means this capture is lossy; it does not mean the DUT
        misbehaved (``drop_full`` is nobody draining fast enough, ``drop_giant``
        is a frame over ``MAX_FRAME``)."""
        return self.drop_full + self.drop_giant


#: ``firmware/touch/touch.h``'s TOUCH_VERDICT_* -- the panel-continuity probe's
#: four possible answers, in the order the firmware numbers them. "unknown" is a
#: real answer (no probe ran, or it could not complete), never a stand-in for
#: one of the others.
TOUCH_VERDICT_WORDS = {
    0: "unknown",
    1: "chip-misconfigured",
    2: "panel-open",
    3: "panel-present",
}


@dataclass(frozen=True)
class DiagResponse:
    """``diag`` reply — the shell's always-on diagnostic counters (firmware
    ``diag.h``). The over-the-wire-reconfig RX-path instrumentation:

    - ``rx_recover``/``rx_dumps``/``rx_drops`` — LAN9220 RX-overrun recovery
      (all 0 = no MAC overflow, the HW-confirmed case);
    - ``icap_bytes`` — bytes written to HWICAP.WF (== ``got`` => ICAP keeps up);
    - ``got``/``expect`` — in-flight partial receive progress vs total;
    - ``rcv_wnd``/``rcv_ann_wnd`` — the 6910 TCP pcb's receive window (0 while
      stalled => the window is not reopening to the host);
    - ``rx_queued`` — bytes queued in the 6910 conn's pbuf chain;
    - ``pbuf_free`` — free lwIP PBUF_POOL buffers (0 => inbound frames dropped
      for want of a pbuf). ``~0`` (4294967295) means stats are compiled out.
    - ``grants_sent``/``grant_fails`` — windowed grant bytes lwIP ACCEPTED vs
      REFUSED on the 6910 send-back (splits the grant-deadlock: reached-and-
      accepted vs send-refused);
    - ``sndbuf`` — the 6910 pcb ``tcp_sndbuf`` (0 => a grant send is refused);
    - ``snd_wnd`` — the peer's advertised window (0 => an accepted grant can't
      egress).
    - v0.9 appends the 11 counters that were JTAG-only (TX-path
      ``tx_*``, ``icap_sr_last``/``icap_eos_status``, ``ovlstore_*``); an older
      shell simply omits them and they read 0 here.
    - v0.9.2 appends the superloop service telemetry (``svc_*``,
      ``pass_max_us``) — see the field comments below. ``svc_skipped != 0``
      means the loop has taken a service OUT of the rotation for overrunning
      its budget; nothing else in this reply says so.

    NOTE: 6900 is PARKED during a swap, so this verb is only reachable when
    idle; during a swap read the SAME counters from the fixed DMEM mailbox over
    JTAG-MDM (see firmware/common/diag.h)."""

    ok: bool
    rx_recover: int = 0
    rx_dumps: int = 0
    rx_drops: int = 0
    icap_bytes: int = 0
    got: int = 0
    expect: int = 0
    rcv_wnd: int = 0
    rcv_ann_wnd: int = 0
    rx_queued: int = 0
    pbuf_free: int = 0
    grants_sent: int = 0
    grant_fails: int = 0
    sndbuf: int = 0
    snd_wnd: int = 0
    # v0.9 -- the 11 counters that used to be JTAG-only (diag.h X-macro order).
    tx_frames_sent: int = 0
    tx_status_drained: int = 0
    tx_fifo_full_drops: int = 0
    tx_errors: int = 0
    tx_space_stalls: int = 0
    tx_iface_errors: int = 0
    tx_last_status: int = 0
    icap_sr_last: int = 0
    icap_eos_status: int = 0
    ovlstore_phase: int = 0
    ovlstore_detail: int = 0
    # v0.9.1 -- the STMPE811 panel-continuity probe (diag.h v7, X-macro order).
    # ``touch_verdict`` is the answer: 0 unknown / 1 chip-misconfigured /
    # 2 panel-open / 3 panel-present. The other three are its raw evidence --
    # packed register read-backs and 12-bit ADC samples, so read them as HEX
    # (firmware/touch/touch.h documents every field). A shell built without
    # TOUCH=1, or an older shell, leaves all four 0 = "no probe ran".
    touch_regs: int = 0
    touch_adc_x: int = 0
    touch_adc_y: int = 0
    touch_verdict: int = 0
    # DERIVED, not on the wire: the same four numbers spelled the way a human
    # reading `pyverify diag` needs them. A bare ``"touch_verdict": 2`` is a
    # lookup away from meaning anything and a packed register word in decimal is
    # unreadable -- which is how a diagnostic ends up unused. The raw ints above
    # stay authoritative; these are a rendering of them, filled in by
    # :meth:`ShellClient.diag`.
    touch_verdict_word: str = "unknown"
    touch_regs_hex: str = "0x00000000"
    touch_adc_x_hex: str = "0x00000000"
    touch_adc_y_hex: str = "0x00000000"
    # v0.9.2 -- SUPERLOOP SERVICE TELEMETRY (diag.h v8, X-macro order). The
    # superloop is a table (firmware/common/service.h) and it times itself, so
    # "which service ate the pass" is finally a number rather than a guess.
    #   svc_count      services in the table;
    #   pass_max_us    worst FULL pass, microseconds, high-water since boot;
    #   svc_max_us     worst SINGLE service, and svc_max_ix which one it was
    #                  (an INDEX into the table in firmware/platform/src/main.c);
    #   svc_overruns   budget overruns in total;
    #   svc_skips      healthy->sick EDGES (a service that STAYS sick does not
    #                  keep inflating this);
    #   svc_skipped    bitmask of services currently SKIPPED for having blown
    #                  their budget on MPS3_SVC_SICK_K consecutive passes.
    #                  NON-ZERO IS THE HEADLINE: the loop has taken a service
    #                  out of the rotation and is probing it once per cooldown.
    #   svc_us_0..5    per-service worst case, two per word, each a 16-bit
    #                  SATURATING microsecond count (service 2p in bits [15:0]
    #                  of svc_us_<p>, 2p+1 in [31:16]); 0xFFFF means ">= 65535".
    # An older shell omits all thirteen and they read 0 here -- which for a
    # pre-v8 image is the truth: it had no service table.
    svc_count: int = 0
    pass_max_us: int = 0
    svc_max_us: int = 0
    svc_max_ix: int = 0
    svc_overruns: int = 0
    svc_skips: int = 0
    svc_skipped: int = 0
    svc_us_0: int = 0
    svc_us_1: int = 0
    svc_us_2: int = 0
    svc_us_3: int = 0
    svc_us_4: int = 0
    svc_us_5: int = 0


# --------------------------------------------------------------------------- #
# Transport (real socket implementation + DI seam for tests)
# --------------------------------------------------------------------------- #


@runtime_checkable
class Transport(Protocol):
    """Minimal line-oriented transport ``ShellClient`` needs.

    One "line" == one JSON object per net-protocol.md; the newline is the
    frame delimiter, not part of the payload.
    """

    def send_line(self, payload: bytes) -> None: ...

    def recv_line(self) -> bytes: ...

    def close(self) -> None: ...


class SocketTransport:
    """Real TCP transport: connect, then newline-delimited send/recv.

    Buffers partial reads (TCP gives no framing guarantee — a single
    ``recv`` may return less than one line, or more than one if the shell
    ever pipelines, though net-protocol.md's control channel is strictly
    request/response so that shouldn't happen in practice).
    """

    def __init__(self, host: str, port: int = CONTROL_PORT, timeout: float = 5.0):
        self._sock = socket.create_connection((host, port), timeout=timeout)
        self._buf = b""

    def send_line(self, payload: bytes) -> None:
        self._sock.sendall(payload + b"\n")

    def recv_line(self) -> bytes:
        while b"\n" not in self._buf:
            chunk = self._sock.recv(4096)
            if not chunk:
                raise ConnectionError("shell control channel closed by peer")
            self._buf += chunk
        line, _, self._buf = self._buf.partition(b"\n")
        return line

    def close(self) -> None:
        self._sock.close()


# --------------------------------------------------------------------------- #
# Client
# --------------------------------------------------------------------------- #


class ShellClient:
    """Client for the shell coordinator's control channel (TCP 6900).

    Usage::

        with ShellClient("192.168.10.101") as shell:
            info = shell.ping()
            shell.set_clk("25mhz")
            shell.swap(rm="nanosoc", src="tftp")

    ``transport`` is an injection seam for tests (see module docstring);
    normal use leaves it ``None`` and lets :meth:`connect` build a real
    :class:`SocketTransport`.
    """

    def __init__(
        self,
        host: str,
        port: int = CONTROL_PORT,
        *,
        timeout: float = 5.0,
        transport: Transport | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self._transport = transport

    def connect(self) -> "ShellClient":
        if self._transport is None:
            self._transport = SocketTransport(self.host, self.port, self.timeout)
        return self

    def close(self) -> None:
        if self._transport is not None:
            self._transport.close()
            self._transport = None

    def __enter__(self) -> "ShellClient":
        return self.connect()

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    # -- core request/response -------------------------------------------- #

    def _send_op(self, op: dict[str, Any]) -> None:
        """Send one request line, WITHOUT awaiting the reply.

        Split out of :meth:`_request` because the ``swap`` verb genuinely needs
        it: the shell PARKS this connection for the whole reconfiguration and
        only listens for the bitstream push on 6910 once the swap FSM has
        reached its await-incoming states. So a deploy must send ``swap``, THEN
        push, THEN collect the reply — see :meth:`swap_begin`/:meth:`swap_await`.
        """
        if self._transport is None:
            raise ShellProtocolError(
                "ShellClient is not connected; call connect() or use "
                "'with ShellClient(...) as shell:'"
            )
        line = json.dumps(op, separators=(",", ":"))
        self._transport.send_line(line.encode("ascii"))

    def _recv_resp(self) -> dict[str, Any]:
        """Read + validate one response line (the half after :meth:`_send_op`)."""
        if self._transport is None:
            raise ShellProtocolError(
                "ShellClient is not connected; call connect() or use "
                "'with ShellClient(...) as shell:'"
            )
        raw = self._transport.recv_line()
        try:
            resp = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ShellProtocolError(
                f"malformed JSON line from shell: {raw!r}"
            ) from exc
        if not isinstance(resp, dict):
            raise ShellProtocolError(
                f"expected a JSON object, got {type(resp).__name__}: {resp!r}"
            )
        if "ok" not in resp:
            raise ShellProtocolError(f"response missing required 'ok' field: {resp!r}")
        return resp

    def _request(self, op: dict[str, Any]) -> dict[str, Any]:
        self._send_op(op)
        return self._recv_resp()

    # -- verbs (net-protocol.md "Control channel" table) ------------------- #

    def ping(self) -> PingResponse:
        """``{"op":"ping"}`` -> shell_id/rm_id identify the running image."""
        resp = self._request({"op": "ping"})
        return PingResponse(
            ok=bool(resp["ok"]),
            shell_id=str(resp.get("shell_id", "")),
            rm_id=str(resp.get("rm_id", "")),
        )

    def reset(self, target: str = "dut") -> ResetResponse:
        """``{"op":"reset","target":"dut"}`` — one of the three shell-driven
        resets (ARCHITECTURE_SPEC.md §5): DUT system reset by default.
        """
        resp = self._request({"op": "reset", "target": target})
        return ResetResponse(ok=bool(resp["ok"]))

    def set_clk(
        self,
        preset: str,
        *,
        presets: "Optional[Sequence[str]]" = None,
    ) -> SetClkResponse:
        """``{"op":"set_clk","preset":"25mhz"}`` — DRP MMCM DUT-clock preset
        (ARCHITECTURE_SPEC.md §5). Client-side preset validation is
        **opt-in** here: pass ``presets=DEFAULT_CLK_PRESETS`` (or any
        sequence) to get a ``ValueError`` on a typo instead of a
        round-trip; the default sends the string verbatim. Deliberate
        split (W-HOST-MISC): ``ShellClient`` is the raw protocol driver —
        the conformance suites (``tests/firmware_logic/test_json_golden.py``,
        ``tests/test_fakeshell.py``) drive *unknown* presets through it on
        purpose to prove the server rejects them cleanly. The user-facing
        :meth:`pyverify.board.Mps3Board.set_clk` facade validates **by
        default** against :data:`DEFAULT_CLK_PRESETS` (the placeholder
        table from ``firmware/clkrst/clkrst.c``; enumeration is still open
        as docs/contracts/OPEN_ISSUES.md I16).
        """
        validate_clk_preset(preset, presets)
        resp = self._request({"op": "set_clk", "preset": preset})
        return SetClkResponse(ok=bool(resp["ok"]), locked=bool(resp.get("locked", False)))

    def swap_begin(self, rm: str, src: str = "tftp") -> None:
        """Send ``{"op":"swap",...}`` and return IMMEDIATELY, without awaiting
        the reply.

        ⚠ THE PUSH MUST HAPPEN BETWEEN THIS AND :meth:`swap_await`. Verified on
        silicon 2026-07-14: the shell's swap FSM only listens for the bitstream
        on 6910 once this RPC has driven it into AWAIT_INCOMING_CLEARING /
        AWAIT_PARTIAL — which is exactly why it PARKS this 6900 connection for
        the duration. Pushing *before* the swap (the old
        ``push_pair()`` -> ``swap()`` order) hits a shell that is not expecting
        data, and it RESETS the 6910 connection (ECONNRESET, ``diag.got`` stays
        0). See :meth:`swap_await` and :mod:`pyverify.swap`.
        """
        self._send_op({"op": "swap", "rm": rm, "src": src})

    def swap_await(self) -> SwapResponse:
        """Collect the parked reply to a :meth:`swap_begin` (after pushing).

        Blocks for the whole server-side clearing -> partial -> verify -> release
        sequence, so this client needs a GENEROUS timeout — the 5 s default
        cannot survive a real reconfiguration.
        """
        resp = self._recv_resp()
        return SwapResponse(
            ok=bool(resp["ok"]),
            rm_id=str(resp.get("rm_id", "")),
            verified=bool(resp.get("verified", False)),
        )

    def swap(self, rm: str, src: str = "tftp") -> SwapResponse:
        """``{"op":"swap","rm":"nanosoc","src":"tftp"}`` — drives the
        server-side clearing->partial->verify->release sequence
        (net-protocol.md "Swap sequence").

        ⚠ This blocking form sends the RPC and waits, leaving NO window in which
        to push the bitstream — so it only works when the shell already holds the
        pair (e.g. a re-swap to a cached RM). For a real deploy use
        :meth:`swap_begin` -> push -> :meth:`swap_await`, which is what
        :meth:`pyverify.swap.SwapOrchestrator.deploy` does.
        """
        self.swap_begin(rm, src)
        return self.swap_await()

    def link(self, event: str) -> LinkResponse:
        """``{"op":"link","event":"down"}`` — virtual-PHY link injection
        (ARCHITECTURE_SPEC.md §8.1: host-injected link up/down/speed events).
        """
        resp = self._request({"op": "link", "event": event})
        return LinkResponse(ok=bool(resp["ok"]))

    def commit(self, rm: str) -> CommitResponse:
        """``{"op":"commit","rm":"nanosoc"}`` — persist ``rm`` as the new
        A/B default overlay slot (overlay-manifest.md; spec §8A.4-8A.5).
        """
        resp = self._request({"op": "commit", "rm": rm})
        return CommitResponse(ok=bool(resp["ok"]), slot=str(resp.get("slot", "")))

    def telemetry(self) -> TelemetryResponse:
        """``{"op":"telemetry"}`` -> ``{"ok":false,"err":"no power sensor",
        "lockup":<bool>}`` — **always a failure** (net-protocol.md v0.6).

        There is no power sensor on this platform, so there are no ``mv``/
        ``ma`` keys on the wire and no such fields on
        :class:`TelemetryResponse` to hold them. ``err`` is parsed (unlike
        :meth:`macgen`'s polymorphic ``err``, telemetry's is unambiguously
        the diagnostic string — there is no success shape for it to mean
        anything else in) and ``lockup`` is parsed regardless of ``ok``,
        because the failure line is the *only* line and it is what carries
        the real ``dut_lockup`` pin.
        """
        resp = self._request({"op": "telemetry"})
        return TelemetryResponse(
            ok=bool(resp["ok"]),
            err=str(resp.get("err", "")),
            lockup=bool(resp.get("lockup", False)),
        )

    def macgen(
        self,
        *,
        gen: bool = True,
        chk: bool = True,
        inject: str = "none",
        injects: "Optional[Sequence[str]]" = None,
    ) -> MacGenResponse:
        """``{"op":"macgen","gen":..,"chk":..,"inject":".."}`` — drive the
        shell's error-inject gen/checker (GENCHK) and read its counters back
        (net-protocol.md "MAC gen/checker control", I10 tail; spec §8).

        ``gen``/``chk`` set ``GENCHK.CTRL.gen_en``/``chk_en``; ``inject`` arms
        the next-frame fault (one of :data:`MACGEN_INJECTS`; ``"none"`` clears
        it). The reply carries ``tx``/``rx``/``err`` — the ``TX_CNT``/
        ``RX_CNT``/``ERR_CNT`` counters *after* the write.

        Inject validation is **opt-in** here (wire-transparent by default),
        mirroring :meth:`set_clk`: pass ``injects=MACGEN_INJECTS`` (or a
        custom sequence) to raise ``ValueError`` on a typo before any
        round-trip. The conformance suites drive *unknown* injects through
        the default to prove the server's own fail-closed rejection; the
        user-facing :meth:`pyverify.board.Mps3Board.macgen` validates by
        default.
        """
        validate_macgen_inject(inject, injects)
        resp = self._request(
            {"op": "macgen", "gen": bool(gen), "chk": bool(chk), "inject": inject}
        )
        ok = bool(resp["ok"])
        # Counters are meaningful only on success; on failure resp["err"] is
        # the diagnostic *string* (polymorphic key — net-protocol.md), so do
        # NOT int() it. Fail-closed to zeros.
        return MacGenResponse(
            ok=ok,
            tx=int(resp.get("tx", 0)) if ok else 0,
            rx=int(resp.get("rx", 0)) if ok else 0,
            err=int(resp.get("err", 0)) if ok else 0,
        )

    def version(self) -> VersionResponse:
        """``{"op":"version"}`` — the build identity of the running image
        (net-protocol.md v0.8): harness release, packed ``HARNESS_VER32``, build
        sha/dirty, the LMB size it was linked for, and its compile-time feature
        set. Build-time constants on the shell, plus one CSR read (the USRACC
        readback behind ``usr_access``, ``null`` where the fabric does not
        answer), so it still replies when the fabric is otherwise unhappy, and
        it is never held like ``swap``.

        Complements :meth:`ping` rather than replacing it: ``ping`` identifies
        the FABRIC (``static_id``) and the resident RM, ``version`` identifies
        the FIRMWARE — and, since Wave B, cross-checks the two against each
        other via ``usr_access``/``skew``. See :class:`VersionResponse`."""
        resp = self._request({"op": "version"})
        ok = bool(resp["ok"])
        features = resp.get("features", ()) if ok else ()
        if not isinstance(features, (list, tuple)):
            raise ShellProtocolError(
                f"version.features must be a JSON array, got {features!r}"
            )
        # `skew` is tri-state on the wire: true / false / null. `null` and an
        # ABSENT key mean the same thing -- no comparison was made -- and both
        # must survive as None. bool(resp.get("skew", False)) would turn "not
        # checked" into "checked, fine", which is the one reading this field
        # exists to prevent, so the null is carried through explicitly.
        raw_skew = resp.get("skew") if ok else None
        skew = None if raw_skew is None else bool(raw_skew)
        usr_access = resp.get("usr_access") if ok else None
        usr_access = "" if usr_access is None else str(usr_access)
        if skew is not None and not usr_access:
            raise ShellProtocolError(
                f"version reported skew={raw_skew!r} with no usr_access: a "
                f"verdict with nothing behind it is not a verdict"
            )
        return VersionResponse(
            ok=ok,
            harness=str(resp.get("harness", "")),
            ver32=str(resp.get("ver32", "")),
            sha=str(resp.get("sha", "")),
            # Wire form is an int (0/1) beside ver32's flags byte; bool() also
            # accepts a JSON bool from a lenient server without changing meaning.
            dirty=bool(resp.get("dirty", 0)),
            lmb_kb=int(resp.get("lmb_kb", 0)) if ok else 0,
            features=tuple(str(f) for f in features),
            usr_access=usr_access,
            skew=skew,
        )

    def diag(self) -> DiagResponse:
        """``{"op":"diag"}`` — read back the shell's diagnostic counter mailbox
        (firmware/common/diag.h). Idle-only over 6900 (the control channel is
        parked during a swap); during a swap read the same struct over JTAG-MDM
        at the fixed DMEM address. See :class:`DiagResponse` for the fields."""
        resp = self._request({"op": "diag"})
        _t_regs = int(resp.get("touch_regs", 0))
        _t_adc_x = int(resp.get("touch_adc_x", 0))
        _t_adc_y = int(resp.get("touch_adc_y", 0))
        _t_verdict = int(resp.get("touch_verdict", 0))
        return DiagResponse(
            ok=bool(resp["ok"]),
            rx_recover=int(resp.get("rx_recover", 0)),
            rx_dumps=int(resp.get("rx_dumps", 0)),
            rx_drops=int(resp.get("rx_drops", 0)),
            icap_bytes=int(resp.get("icap_bytes", 0)),
            got=int(resp.get("got", 0)),
            expect=int(resp.get("expect", 0)),
            rcv_wnd=int(resp.get("rcv_wnd", 0)),
            rcv_ann_wnd=int(resp.get("rcv_ann_wnd", 0)),
            rx_queued=int(resp.get("rx_queued", 0)),
            pbuf_free=int(resp.get("pbuf_free", 0)),
            grants_sent=int(resp.get("grants_sent", 0)),
            grant_fails=int(resp.get("grant_fails", 0)),
            sndbuf=int(resp.get("sndbuf", 0)),
            snd_wnd=int(resp.get("snd_wnd", 0)),
            tx_frames_sent=int(resp.get("tx_frames_sent", 0)),
            tx_status_drained=int(resp.get("tx_status_drained", 0)),
            tx_fifo_full_drops=int(resp.get("tx_fifo_full_drops", 0)),
            tx_errors=int(resp.get("tx_errors", 0)),
            tx_space_stalls=int(resp.get("tx_space_stalls", 0)),
            tx_iface_errors=int(resp.get("tx_iface_errors", 0)),
            tx_last_status=int(resp.get("tx_last_status", 0)),
            icap_sr_last=int(resp.get("icap_sr_last", 0)),
            icap_eos_status=int(resp.get("icap_eos_status", 0)),
            ovlstore_phase=int(resp.get("ovlstore_phase", 0)),
            ovlstore_detail=int(resp.get("ovlstore_detail", 0)),
            touch_regs=_t_regs,
            touch_adc_x=_t_adc_x,
            touch_adc_y=_t_adc_y,
            touch_verdict=_t_verdict,
            touch_verdict_word=TOUCH_VERDICT_WORDS.get(
                _t_verdict, f"invalid({_t_verdict})"),
            touch_regs_hex=f"0x{_t_regs:08x}",
            touch_adc_x_hex=f"0x{_t_adc_x:08x}",
            touch_adc_y_hex=f"0x{_t_adc_y:08x}",
            svc_count=int(resp.get("svc_count", 0)),
            pass_max_us=int(resp.get("pass_max_us", 0)),
            svc_max_us=int(resp.get("svc_max_us", 0)),
            svc_max_ix=int(resp.get("svc_max_ix", 0)),
            svc_overruns=int(resp.get("svc_overruns", 0)),
            svc_skips=int(resp.get("svc_skips", 0)),
            svc_skipped=int(resp.get("svc_skipped", 0)),
            svc_us_0=int(resp.get("svc_us_0", 0)),
            svc_us_1=int(resp.get("svc_us_1", 0)),
            svc_us_2=int(resp.get("svc_us_2", 0)),
            svc_us_3=int(resp.get("svc_us_3", 0)),
            svc_us_4=int(resp.get("svc_us_4", 0)),
            svc_us_5=int(resp.get("svc_us_5", 0)),
        )

    def dutrx(self) -> DutRxResponse:
        """``{"op":"dutrx"}`` — ONE CHUNK of the frame at the head of the DUT's
        egress capture FIFO (net-protocol.md v0.10). See :class:`DutRxResponse`.

        Takes no arguments: the block's ``DATA`` port is a DESTRUCTIVE read, so
        the FIFO is its own cursor — there is no offset to send and no state on
        the shell. **Every call CONSUMES** what it returns; a dropped reply is a
        lost frame, which is why this rides TCP and not a datagram.

        :meth:`read_dut_frame` is the loop most callers want."""
        resp = self._request({"op": "dutrx"})
        ok = bool(resp["ok"])
        if not ok:
            # The decline shape ("dut_egress not present" on a bitstream with no
            # 0x44B2 slave). Everything else stays at its zero default rather
            # than being parsed out of a failure line -- there is nothing behind
            # those numbers, and a zeroed counter beside ok=False reads exactly
            # like a healthy idle capture.
            return DutRxResponse(ok=False, err=str(resp.get("err", "")))
        raw = resp.get("data", "")
        if not isinstance(raw, str):
            raise ShellProtocolError(f"dutrx.data must be a hex string, got {raw!r}")
        try:
            data = bytes.fromhex(raw)
        except ValueError as exc:
            raise ShellProtocolError(f"dutrx.data is not hex: {exc}") from None
        n = int(resp.get("n", 0))
        if len(data) != n:
            # A torn or mis-encoded chunk. Refuse it rather than hand back a
            # short frame that would reassemble into a plausible WRONG one.
            raise ShellProtocolError(
                f"dutrx said n={n} but carried {len(data)} bytes of data"
            )
        return DutRxResponse(
            ok=True,
            frame_len=int(resp.get("len", 0)),
            off=int(resp.get("off", 0)),
            n=n,
            more=bool(resp.get("more", False)),
            last=bool(resp.get("last", False)),
            frames=int(resp.get("frames", 0)),
            rx=int(resp.get("rx", 0)),
            drop_full=int(resp.get("drop_full", 0)),
            drop_giant=int(resp.get("drop_giant", 0)),
            ovf=bool(resp.get("ovf", False)),
            desync=bool(resp.get("desync", False)),
            data=data,
        )

    def read_dut_frame(self) -> "tuple[Optional[bytes], DutRxResponse]":
        """Read ONE whole frame out of the DUT-egress FIFO, following ``more``
        across as many :meth:`dutrx` chunks as it takes.

        Returns ``(frame, last_chunk)``. ``frame`` is ``None`` when the FIFO had
        nothing waiting (a RESULT, not an error — an idle DUT looks exactly like
        this) or when the verb declined; ``last_chunk`` always carries the reply
        that ended the read, so the counters and the sticky flags are available
        either way. **Read them**: a capture that dropped frames reports it
        nowhere else.

        Two protocol errors are raised rather than papered over, because both
        produce a frame that LOOKS fine:

        - a chunk whose ``off`` does not continue the previous one — the
          reassembly would splice two frames into one plausible frame;
        - ``more`` with ``n == 0``, which makes no progress and would otherwise
          spin forever against a stuck shell.
        """
        chunk = self.dutrx()
        if not chunk.ok or chunk.n == 0:
            return None, chunk

        parts = [chunk.data]
        want = chunk.frame_len
        got = chunk.n
        while chunk.more:
            prev = chunk
            chunk = self.dutrx()
            if not chunk.ok:
                raise ShellProtocolError(
                    f"dutrx failed mid-frame ({chunk.err!r}): "
                    f"{got} of {want} bytes read"
                )
            if chunk.n == 0:
                raise ShellProtocolError(
                    f"dutrx made no progress mid-frame: more=True with n=0 at "
                    f"offset {got} of {want}"
                )
            if chunk.off != got or chunk.frame_len != want:
                raise ShellProtocolError(
                    f"dutrx chunk does not continue the frame: expected "
                    f"off={got} len={want}, got off={chunk.off} "
                    f"len={chunk.frame_len} (previous chunk ended at "
                    f"{prev.off + prev.n})"
                )
            parts.append(chunk.data)
            got += chunk.n
        return b"".join(parts), chunk

    def display(
        self,
        owner: str,
        *,
        owners: "Optional[Sequence[str]]" = None,
    ) -> DisplayResponse:
        """``{"op":"display","owner":"dut|harness|toggle"}`` — flip the on-board
        CLCD panel's owner via the shell's existing 6900 control channel (the
        remote arm of the CLCD KVM; the button ``USER_nPB[1]`` and a local CSR
        write are the other two request sources). Writes the frozen
        ``CLCDKVM.CTRL.src_sel`` (+ ``src_sel_we``) and reads ``STATUS.owner``
        back — a plain send-now response, NOT held like ``swap``.

        Owner validation is **opt-in** here (wire-transparent by default),
        mirroring :meth:`set_clk`/:meth:`macgen`: pass ``owners=DISPLAY_OWNERS``
        (or a custom sequence) to raise ``ValueError`` on a typo before any
        round-trip. The user-facing
        :meth:`pyverify.board.Mps3Board.set_display_owner` validates by default.

        See :meth:`display_owner` for the read-only query.
        """
        validate_display_owner(owner, owners)
        resp = self._request({"op": "display", "owner": owner})
        return DisplayResponse(
            ok=bool(resp["ok"]),
            owner=str(resp.get("owner", "")),
            err=str(resp.get("err", "")),
        )

    def display_owner(self) -> DisplayResponse:
        """``{"op":"display","owner":"query"}`` — report the CLCD KVM's current
        committed owner **without moving it** (a read-only ``display``). The
        reply's :attr:`~DisplayResponse.owner` is ``CLCDKVM.STATUS.owner``. On a
        board with no KVM slave this is the same ``clcd_kvm not present``
        failure as :meth:`display`."""
        resp = self._request({"op": "display", "owner": "query"})
        return DisplayResponse(
            ok=bool(resp["ok"]),
            owner=str(resp.get("owner", "")),
            err=str(resp.get("err", "")),
        )

    def display_settled(
        self,
        owner: str,
        *,
        timeout: float = 2.0,
        interval: float = 0.05,
        owners: "Optional[Sequence[str]]" = DISPLAY_OWNERS,
        _clock=None,
        _sleep=None,
    ) -> DisplaySettleResponse:
        """Flip the panel owner and WAIT for the handover to commit.

        `display` + a bounded re-`query` loop, and nothing else: no new wire
        verb, no firmware change, no contract edit. It exists because
        net-protocol.md's own "Display" section ends with *"a client confirms
        the landing with a follow-up query"* -- a step every caller has to get
        right, and the board proof in docs/CLCD_KVM_PLAN.md "Proving it" cannot
        be one command without.

        `"toggle"` is resolved to a CONCRETE target first (one read-only query,
        then the other side), because "did the toggle land?" is otherwise
        unanswerable: the reply and the eventual state can be the same value.

        Returns without raising in every ordinary outcome. `ok=False` is the
        shell declining (`clcd_kvm not present` on a KVM-less bitstream, or a
        bad owner). `ok=True, landed=False` is the honest "requested, did not
        commit in time" -- INCONCLUSIVE, and the caller must say so rather than
        report a flip that may not have happened.

        `_clock` / `_sleep` are seams for the tests; they default to
        `time.monotonic` / `time.sleep`.
        """
        validate_display_owner(owner, owners)
        clock = _clock or time.monotonic
        sleep = _sleep or time.sleep

        target = owner
        if owner == "toggle":
            pre = self.display_owner()
            if not pre.ok:
                return DisplaySettleResponse(ok=False, requested=owner,
                                             err=pre.err)
            target = "dut" if pre.owner == "harness" else "harness"

        t0 = clock()
        first = self.display(owner, owners=owners)
        if not first.ok:
            return DisplaySettleResponse(ok=False, requested=target,
                                         owner=first.owner, err=first.err)
        if first.owner == target:
            return DisplaySettleResponse(ok=True, requested=target,
                                         owner=first.owner, landed=True,
                                         polls=0, waited_s=clock() - t0)

        polls, last = 0, first
        while clock() - t0 < timeout:
            sleep(interval)
            polls += 1
            last = self.display_owner()
            if not last.ok:
                return DisplaySettleResponse(ok=False, requested=target,
                                             owner=last.owner, polls=polls,
                                             waited_s=clock() - t0,
                                             err=last.err)
            if last.owner == target:
                return DisplaySettleResponse(ok=True, requested=target,
                                            owner=last.owner, landed=True,
                                            polls=polls, waited_s=clock() - t0)
        return DisplaySettleResponse(
            ok=True, requested=target, owner=last.owner, landed=False,
            polls=polls, waited_s=clock() - t0,
            err=f"owner did not commit to {target!r} within {timeout}s "
                f"(last committed owner {last.owner!r})")
