"""``FakeShell`` — stdlib-only reference implementation of the shell's
network surface (``docs/contracts/net-protocol.md``).

Lets the entire host stack (:class:`pyverify.client.ShellClient`,
:class:`pyverify.swap.SwapOrchestrator`, the pusher,
:class:`pyverify.console.ConsoleReader`, :class:`pyverify.edge.EdgeDeviceApi`,
``pyverify.cli``) run end-to-end with **no hardware** — and doubles as the
**executable spec for A3's firmware**: every behaviour here cites the
contract clause or firmware file it mirrors, and the swap behaviour is
driven by the same :mod:`pyverify.testing.swap_model` Python port of
``firmware/coordinator/swap_fsm.c`` that the integration suite checks
against the C.

Services implemented (net-protocol.md port map; every port configurable,
``0`` = ephemeral, bound port exposed as an attribute after :meth:`start`):

===========  =====  ======================================================
default      proto  service
===========  =====  ======================================================
6900         TCP    control/status — JSON-lines request/response, all 8
                    verbs with the per-op response fields of the contract
                    (the 7 core verbs + macgen, net-protocol.md v0.4)
69           UDP    TFTP (RFC1350 WRQ/octet receive) bitstream push
6910         TCP    raw bitstream push (alt to TFTP)
6930/31/32   TCP    UART0/UART1/SWO consoles — configurable banner on
                    connect, then echo (or absorb)
===========  =====  ======================================================

Not implemented (out of W-FAKESHELL scope, per the port map's remaining
rows): XVC (2542) and SWD remote_bitbang (6920) — both are raw byte
protocols to *other* tools (Vivado/OpenOCD), not exercised by pyverify's
own code paths.

Bitstream receive validation mirrors ``firmware/config_agent/config_agent.c``
exactly (see :class:`ConfigAgentModel`): 24-byte ``"MPS3"`` header (reusing
the pusher's real framing via :mod:`pyverify.testing._pusher` — never
re-implemented), version, ``static_id`` match, kind, size bound, **I2
clearing-then-partial ordering**, then full-payload CRC32 — a torn or
mismatched transfer is rejected *before* any (modelled) ICAP write.

Synchronous, threaded design (``socketserver``/``threading``) to match
pyverify's synchronous style; no asyncio, no third-party deps.

Usage::

    with FakeShell.ephemeral() as fake:
        with ShellClient(fake.host, fake.control_port) as shell:
            shell.ping()
            ...

Known contract ambiguities surfaced by implementing this (flagged for A6,
contracts NOT edited here):

- **Raw-TCP push has no acknowledgement.** net-protocol.md defines no
  server->client response on 6910, so a client that does ``sendall`` +
  ``close`` cannot know the push was accepted (TFTP's final ACK gives that
  for free). This server closes the connection when it has finished
  validating; :func:`raw_tcp_put` waits for that EOF as a synchronisation
  point. A real pusher should either do the same or the contract should
  add an explicit status byte.
- **Push-vs-swap interleaving — RESOLVED ON SILICON (2026-07-14), see below.**
  This note used to read "net-protocol.md's swap sequence has the host push
  *both* files of the pair before ``swap`` ... A3's firmware will need
  two-slot staging or a stalling transport". The firmware went the other way,
  and the ordering is now enforced here (:meth:`FakeShell._op_swap`).
- **The receiver does not require clearing.rm_id == partial.rm_id** within
  a pair (config_agent.c has no such check; ordering is by *kind* only).
  If the pair files disagree, the swap still verifies against the
  *partial*'s rm_id per I14/I25. Worth an explicit contract statement.
- **link.event values**: the contract shows only ``"down"``; spec §8.1
  mentions up/down/**speed** events. This server accepts ``up``/``down``/
  ``pulse`` (matching the firmware, I31(b)) and rejects speed events
  (fail closed).

I31 RESOLVED (2026-07-07): (a) the failure-diagnostic key is now ``"err"``
here too, matching the firmware's ``mps3_ctrl_encode_response()`` and pinned
in net-protocol.md v0.2 — the test double follows the real server; (b)
``link.event`` accepts ``pulse`` as above. Clients still key only on ``ok``.

**SWAP ORDERING — THE FIDELITY FIX (2026-07-14).** This server used to accept a
bitstream push in ANY state and answer ``swap`` immediately. That made it **more
permissive than the firmware**, and it is exactly why a real host-side ordering
bug (``push_pair()`` then ``swap()``) stayed green in the whole E2E suite while
being dead on silicon. The real, hardware-verified sequence is::

    swap_begin()  ->  push clearing  ->  push partial  ->  swap_await()

so this server now models it:

1. ``{"op":"swap",...}`` does **not** reply. It runs the FSM to
   ``SWAP_AWAIT_INCOMING_CLEARING`` and then **parks the control connection**
   for the whole reconfiguration — which is *why* the real shell parks 6900.
   Only at that point does it start admitting bitstreams (:attr:`FakeShell.awaiting`).
2. The clearing is admitted, the FSM advances to ``SWAP_AWAIT_PARTIAL``, the
   partial is admitted, VERIFY runs, and only THEN does the parked reply go out.
3. **A push that arrives when the shell is not awaiting one is REJECTED**:
   raw-TCP gets an RST (the ECONNRESET the real shell gives; ``SO_LINGER`` 0),
   TFTP gets an ERROR packet. Recorded as a ``PushEvent`` with status
   ``ERR_NOT_AWAITING``.
4. Nothing arriving within ``swap_await_timeout`` fails the swap through the
   FSM's own ``await_timeout`` transition (``swap_fsm_transitions.c``: the
   ``SWAP_AWAIT_*`` states are the only ones with an idle timeout, and it is
   re-armed on RX progress — so an in-flight transfer keeps the swap alive).

Firmware provenance of the gate: ``swap_fsm.c``'s ``icap_direct_begin()`` fails
closed unless ``s_state == SWAP_AWAIT_PARTIAL`` (its own fail-closed fix, silicon
2026-07-10), and ``config_agent.c`` then closes the socket on that rejection.
The check sits where the C puts it — **after** header validation
(``begin_payload()``), so a bad magic/version/static_id/kind or an I2 ordering
violation is still reported as *that* error, not as ``ERR_NOT_AWAITING``.

Where this model is deliberately STRICTER than the C: config_agent.c only hits
the arming gate on the sink path (a payload larger than its RAM staging buffer);
a *small* clearing or partial lands in RAM and would be staged even while idle.
That leniency is an artefact of the staging fast path, not a protocol guarantee —
on real hardware every partial is MiB-scale and takes the ICAP-direct sink — and
it is precisely the slack the wrong ordering hid in. The reference server closes
it: a push is admitted only while a swap is awaiting exactly that kind.

**Uniform failure shape (2026-07-08):** every verb's failure reply is now
exactly ``{"ok":false,"err":"<diagnostic>"}`` — the fakeshell no longer echoes
per-verb steady-state fields on failure (``set_clk``'s ``locked``, ``swap``'s
``verified``/``rm_id``), because the firmware's ``mps3_ctrl_encode_response()``
emits none. That fakeshell-only divergence (the audit's I31 tail) is now caught
automatically by ``tests/firmware_logic/test_fakeshell_conformance.py``, which
runs one request list through BOTH the real ``ctrl_echo`` firmware binary and
this double and asserts the response *key sets*/types agree per verb (values
that legitimately depend on scenario/config are the only permitted delta). The
client response dataclasses default those dropped fields (``locked``/
``verified``/``rm_id``) to False/"" when absent, so nothing downstream regresses.
"""
from __future__ import annotations

import json
import socket
import socketserver
import struct
import threading
import time
import zlib
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional, Tuple

from ..client import CONTROL_PORT, MACGEN_INJECTS
from ..console import SWO_PORT, UART0_PORT, UART1_PORT
from ._pusher import (
    HEADER_SIZE,
    MAGIC,
    RAW_TCP_PORT,
    TFTP_PORT,
    BitstreamFramingError,
    BitstreamHeader,
    BitstreamKind,
)
from .swap_model import (
    DFXCTL_RM_STATUS_RM_ID_VALID,
    STATIC_ID,
    ClearingRef,
    SwapFsm,
    make_regs_confirmed,
    next_state,
)

__all__ = [
    "MPS3_BITSTREAM_VER",
    "MAX_PAYLOAD_WORDS",
    "NOT_AWAITING",
    "ConfigAgentStatus",
    "BitstreamInfo",
    "PushEvent",
    "ConfigAgentModel",
    "FakeShell",
    "TftpError",
    "tftp_put",
    "raw_tcp_put",
]

#: :attr:`PushEvent.status` for a push refused because no swap was awaiting one.
#:
#: Deliberately NOT a :class:`ConfigAgentStatus` member: that enum is a faithful
#: mirror of config_agent.h's ``config_agent_status_t``, and this rejection does
#: not come from the config agent at all — in the firmware it is
#: ``swap_fsm.c``'s ``icap_direct_begin()`` returning -1 because the FSM is not
#: in ``SWAP_AWAIT_PARTIAL``, which config_agent.c then turns into a closed
#: socket. Keeping it out of the enum keeps the mirror honest.
NOT_AWAITING = "ERR_NOT_AWAITING"

#: net_proto.h MPS3_BITSTREAM_VER — the one header version the config agent
#: accepts (frame_bitstream's default).
MPS3_BITSTREAM_VER = 1

#: config_agent.h MPS3_CFG_AGENT_MAX_PAYLOAD_WORDS (4 MiB of payload).
MAX_PAYLOAD_WORDS = 4 * 1024 * 1024 // 4

#: ``version`` feature names, in the firmware's FIXED bit order
#: (``net_proto.h``'s ``MPS3_FEATURE_*`` / ``net_proto.c``'s
#: ``s_feature_names``). The wire array is emitted in THIS order with absent
#: features omitted, so the two servers' lines compare byte-for-byte.
VERSION_FEATURES: Tuple[str, ...] = (
    "clcd", "clcd_kvm", "touch", "hwicap_fifo", "windowed",
)

#: ``diag`` counter keys, in the firmware's emitted order
#: (``net_proto.c``'s ``MPS3_OP_DIAG`` snprintf). Order matters: the
#: conformance suite compares the two servers' diag lines byte-for-byte, and a
#: Python dict preserves insertion order.
DIAG_COUNTERS: Tuple[str, ...] = (
    "rx_recover", "rx_dumps", "rx_drops", "icap_bytes", "got", "expect",
    "rcv_wnd", "rcv_ann_wnd", "rx_queued", "pbuf_free", "grants_sent",
    "grant_fails", "sndbuf", "snd_wnd",
    # v0.9: the verb now carries the WHOLE mailbox (diag.h MPS3_DIAG_FIELDS),
    # the 14 frozen keys above first, these 11 appended in X-macro order.
    "tx_frames_sent", "tx_status_drained", "tx_fifo_full_drops", "tx_errors",
    "tx_space_stalls", "tx_iface_errors", "tx_last_status", "icap_sr_last",
    "icap_eos_status", "ovlstore_phase", "ovlstore_detail",
    # v0.9.1: the STMPE811 panel-continuity probe (diag.h v7), appended in the
    # same X-macro order -- three packed evidence words and the verdict.
    "touch_regs", "touch_adc_x", "touch_adc_y", "touch_verdict",
    # v0.9.2: the superloop service telemetry (diag.h v8), appended in X-macro
    # order -- the per-pass/per-service worst-case microseconds, the
    # budget-overrun counters and the sick-service skip mask
    # (firmware/common/service.h).
    "svc_count", "pass_max_us", "svc_max_us", "svc_max_ix", "svc_overruns",
    "svc_skips", "svc_skipped",
    "svc_us_0", "svc_us_1", "svc_us_2", "svc_us_3", "svc_us_4", "svc_us_5",
)

#: ``dutrx`` chunk size -- ``net_proto.h``'s ``MPS3_DUTRX_CHUNK_MAX``. One
#: reply carries at most this many bytes of the head frame, hex-encoded. It is
#: a MATCHED PAIR with the firmware constant: a fake that chunked differently
#: would let a client that only ever ran against this double reassemble frames
#: by an offset arithmetic the real shell does not use.
DUTRX_CHUNK = 256

_TFTP_BLOCK = 512  # RFC1350 fixed block size
_OP_RRQ, _OP_WRQ, _OP_DATA, _OP_ACK, _OP_ERROR = 1, 2, 3, 4, 5


class ConfigAgentStatus(Enum):
    """Python mirror of config_agent.h's ``config_agent_status_t``."""

    OK = "ok"
    ERR_MAGIC = "header magic != 'MPS3' (or short header)"
    ERR_VERSION = "unsupported header version"
    ERR_STATIC_ID = "static_id mismatch (overlay-manifest.md: partials are only valid against their exact static)"
    ERR_KIND = "kind not clearing(0)/partial(1)"
    ERR_CRC = "payload crc32 mismatch"
    ERR_ORDER = "partial pushed before its pair's clearing (I2 ordering)"
    ERR_SIZE = "payload length disagrees with header len_words"
    ERR_TRUNCATED = "transport ended before len_words*4 payload bytes arrived"


@dataclass(frozen=True)
class BitstreamInfo:
    """Python mirror of config_agent.h's ``config_agent_bitstream_info_t``
    (+ kind/rm_slot, which the C keeps in the staged header)."""

    kind: BitstreamKind
    rm_slot: int
    rm_id: int
    static_id: int
    len_words: int
    crc32: int

    @classmethod
    def from_header(cls, header: BitstreamHeader) -> "BitstreamInfo":
        return cls(
            kind=header.kind, rm_slot=header.rm_slot, rm_id=header.rm_id,
            static_id=header.static_id, len_words=header.len_words,
            crc32=header.crc32,
        )


@dataclass(frozen=True)
class PushEvent:
    """One accepted or rejected bitstream transfer, for test assertions."""

    transport: str            # "tftp" | "tcp"
    ok: bool
    status: str               # ConfigAgentStatus.name, or a transport-level reason
    info: Optional[BitstreamInfo] = None   # header info, if the header parsed


class ConfigAgentModel:
    """Stateful port of ``firmware/config_agent/config_agent.c``: header
    validation order (magic -> ver -> static_id -> kind -> size -> I2
    ordering), payload length + CRC32 check, and the
    ``s_ordering_seen_clearing`` flag semantics (set when a clearing
    completes; reset when the paired partial is accepted) — widened to
    stage one full {clearing, partial} pair, per the "push-vs-swap
    interleaving" ambiguity in the module docstring.

    Not thread-safe by itself; :class:`FakeShell` serialises access.
    """

    def __init__(self, running_static_id: int, *, max_payload_words: int = MAX_PAYLOAD_WORDS):
        self.running_static_id = running_static_id
        self.max_payload_words = max_payload_words
        self._ordering_seen_clearing = False
        self._staged_clearing: Optional[BitstreamInfo] = None
        self._staged_partial: Optional[BitstreamInfo] = None

    # -- header time (BEFORE any payload/ICAP handling) --------------------- #

    def validate_header(self, header_bytes: bytes) -> Tuple[ConfigAgentStatus, Optional[BitstreamHeader]]:
        """config_agent_validate_header_ex(), same check order as the C.

        The version field is peeked manually (2 big-endian bytes) only so
        the *order* of checks matches the C exactly (ver before kind);
        everything else defers to the pusher's real unpack.
        """
        if len(header_bytes) < HEADER_SIZE or header_bytes[:4] != MAGIC:
            return ConfigAgentStatus.ERR_MAGIC, None
        ver = int.from_bytes(header_bytes[4:6], "big")
        if ver != MPS3_BITSTREAM_VER:
            return ConfigAgentStatus.ERR_VERSION, None
        try:
            header = BitstreamHeader.unpack(header_bytes)
        except BitstreamFramingError:
            # Magic/length/version already vetted above; the only remaining
            # unpack failure is an unknown kind byte.
            return ConfigAgentStatus.ERR_KIND, None
        if header.static_id != self.running_static_id:
            return ConfigAgentStatus.ERR_STATIC_ID, header
        if header.len_words > self.max_payload_words:
            return ConfigAgentStatus.ERR_SIZE, header
        if header.kind == BitstreamKind.PARTIAL and not self._ordering_seen_clearing:
            return ConfigAgentStatus.ERR_ORDER, header
        return ConfigAgentStatus.OK, header

    # -- payload complete ---------------------------------------------------- #

    def finish_payload(self, header: BitstreamHeader, payload: bytes) -> ConfigAgentStatus:
        """config_agent_check_payload_crc() + the RECV_PAYLOAD->RECV_DONE
        bookkeeping. On OK the bitstream is staged for :meth:`take_pair`."""
        expected = header.len_words * 4
        if len(payload) < expected:
            return ConfigAgentStatus.ERR_TRUNCATED
        if len(payload) > expected:
            return ConfigAgentStatus.ERR_SIZE
        if zlib.crc32(payload) & 0xFFFFFFFF != header.crc32:
            return ConfigAgentStatus.ERR_CRC
        info = BitstreamInfo.from_header(header)
        if header.kind == BitstreamKind.CLEARING:
            # A clearing starts a (new) pair; any stale partial is dropped.
            self._staged_clearing = info
            self._staged_partial = None
            self._ordering_seen_clearing = True
        else:
            self._staged_partial = info
            # Mirrors config_agent_take_validated_partial(): the ordering
            # flag resets once the pair is complete, so the NEXT pair must
            # again start with a clearing.
            self._ordering_seen_clearing = False
        return ConfigAgentStatus.OK

    # -- hand-off to the swap FSM ------------------------------------------- #

    @property
    def pair_ready(self) -> bool:
        return self._staged_clearing is not None and self._staged_partial is not None

    def take_clearing(self) -> Optional[BitstreamInfo]:
        """Mirrors config_agent_take_validated_clearing(): the swap FSM's
        ``step_await_incoming_clearing()`` consumes the staged clearing the
        moment it lands — it does NOT wait for the whole pair (the FSM has to
        reach ``SWAP_AWAIT_PARTIAL`` before the partial is even admitted)."""
        info, self._staged_clearing = self._staged_clearing, None
        return info

    def take_partial(self) -> Optional[BitstreamInfo]:
        """Mirrors config_agent_take_validated_partial(): consumed by
        ``step_await_partial()``."""
        info, self._staged_partial = self._staged_partial, None
        return info

    def take_pair(self) -> Optional[Tuple[BitstreamInfo, BitstreamInfo]]:
        """Both halves at once (all-or-nothing). Retained for callers that
        pre-stage a pair out-of-band and just want it back; the swap itself
        takes them one at a time, in the order the FSM awaits them."""
        if not self.pair_ready:
            return None
        return (self.take_clearing(), self.take_partial())


# --------------------------------------------------------------------------- #
# socketserver plumbing
# --------------------------------------------------------------------------- #


class _ShellTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, addr, handler_cls, shell: "FakeShell", **extra):
        self.shell = shell
        for key, value in extra.items():
            setattr(self, key, value)
        super().__init__(addr, handler_cls)


class _ControlHandler(socketserver.StreamRequestHandler):
    """TCP 6900: one JSON object per ``\\n``-terminated line, strict
    request->response (net-protocol.md "Control channel")."""

    def handle(self):
        shell = self.server.shell
        for raw in self.rfile:
            line = raw.strip()
            if not line:
                continue
            try:
                request = json.loads(line.decode("utf-8"))
                if not isinstance(request, dict):
                    raise ValueError("request must be a JSON object")
            except (ValueError, UnicodeDecodeError) as exc:
                response = {"ok": False, "err": f"malformed request line: {exc}"}
            else:
                response = shell.handle_control(request)
            self.wfile.write(json.dumps(response, separators=(",", ":")).encode("ascii") + b"\n")
            self.wfile.flush()


class _RawPushHandler(socketserver.BaseRequestHandler):
    """TCP 6910: 24-byte header then len_words*4 payload bytes; the server
    closes the connection once validation finishes (accept or reject) —
    see the "no acknowledgement" ambiguity note in the module docstring."""

    def handle(self):
        shell = self.server.shell
        shell._transfer_begin()
        try:
            self._receive(shell)
        finally:
            shell._transfer_end()

    def _receive(self, shell: "FakeShell"):
        sock = self.request
        sock.settimeout(shell.transfer_timeout)
        header_bytes = _recv_exactly(sock, HEADER_SIZE)
        status, header = shell._ca_validate_header("tcp", header_bytes)
        if status is not ConfigAgentStatus.OK:
            # Reject BEFORE reading the payload — the config agent must
            # never touch ICAP (here: never even accumulate) on a bad
            # header (net-protocol.md "Bitstream framing").
            return
        if not shell._admit_push("tcp", header):
            # No swap is awaiting this bitstream. The real shell RESETS the
            # connection here (swap_fsm.c's icap_direct_begin() fails closed,
            # config_agent.c closes the socket, the host sees ECONNRESET and
            # the shell's `diag.got` never leaves 0). Force a genuine RST —
            # SO_LINGER with a zero timeout — instead of relying on the
            # incidental "close with unread bytes queued" RST, so the client
            # sees the same failure regardless of how much of the payload it
            # had managed to send.
            _force_rst_on_close(sock)
            return
        expected = header.len_words * 4
        # Read one byte beyond the declared length: a well-formed client
        # then just delivers EOF; anything extra is a framing violation
        # (ERR_SIZE), and anything less is a torn payload (ERR_TRUNCATED).
        payload = _recv_exactly(sock, expected + 1)
        shell._ca_finish("tcp", header, payload)


class _ConsoleHandler(socketserver.BaseRequestHandler):
    """TCP 6930/6931/6932: raw byte stream — banner on connect, then echo
    or absorb (net-protocol.md port map; pyverify.console is the client)."""

    def handle(self):
        shell = self.server.shell
        banner = shell.banners.get(self.server.console_name, b"")
        if banner:
            self.request.sendall(banner)
        while True:
            try:
                data = self.request.recv(4096)
            except OSError:
                break
            if not data:
                break
            if shell.console_echo:
                self.request.sendall(data)


def _force_rst_on_close(sock: socket.socket) -> None:
    """Make this socket's ``close()`` emit a TCP RST rather than a FIN, so the
    peer sees ``ECONNRESET`` — the failure the real shell gives a push it is not
    expecting. ``SO_LINGER`` with ``l_onoff=1, l_linger=0`` is the portable way
    to ask for that (struct linger = two native ints)."""
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
    except OSError:  # pragma: no cover — platform without SO_LINGER
        pass


def _recv_exactly(sock: socket.socket, count: int) -> bytes:
    """Read up to ``count`` bytes; stops early on EOF or timeout (the
    caller distinguishes a short result as torn/truncated)."""
    buf = bytearray()
    while len(buf) < count:
        try:
            chunk = sock.recv(count - len(buf))
        except socket.timeout:
            break
        except OSError:
            break
        if not chunk:
            break
        buf.extend(chunk)
    return bytes(buf)


def _hex32(value: int) -> str:
    return "0x%08x" % (value & 0xFFFFFFFF)


# --------------------------------------------------------------------------- #
# Driving the swap FSM in stages (the parked-swap model)
# --------------------------------------------------------------------------- #


def _step_until(fsm: SwapFsm, targets: Tuple[str, ...], max_steps: int = 30) -> None:
    """Step the FSM until it settles in one of ``targets``.

    Stops *on* the target without stepping out of it — the AWAIT_* states are
    self-loops until their input arrives, and DONE/FAILED would fall back to
    IDLE (so ``fsm.history[-1]`` stays the state that actually failed).
    """
    for _ in range(max_steps):
        if fsm.state in targets:
            return
        fsm.step()
    raise TimeoutError(  # pragma: no cover — a model bug, not a scenario
        f"FSM did not reach any of {targets} within {max_steps} steps "
        f"(stuck in {fsm.state})"
    )


def _fail_await_timeout(fsm: SwapFsm) -> None:
    """The swap's IDLE timeout fired while it sat in an AWAIT_* state: nothing
    was pushed into the parked swap. Taken through the model's own pure
    transition table (``swap_fsm_transitions.c``: ``await_timeout`` is the one
    input that fails a SWAP_AWAIT_* state) rather than by assigning FAILED, so
    the fake cannot drift from the C on what a timeout does.
    """
    fsm.history.append(fsm.state)
    fsm.state = next_state(fsm.state, await_timeout=True)


# --------------------------------------------------------------------------- #
# The fake shell
# --------------------------------------------------------------------------- #


class FakeShell:
    """Threaded fake of the MicroBlaze shell firmware's network surface.

    Parameters (all keyword-only except ``host``) — defaults are the
    contract's real port numbers; pass ``0`` (or use
    :meth:`FakeShell.ephemeral`) for OS-assigned ports in tests. After
    :meth:`start` the *bound* ports are exposed as ``control_port``,
    ``tftp_port``, ``raw_tcp_port``, ``uart0_port``, ``uart1_port``,
    ``swo_port`` (and the ``console_ports`` mapping).

    Configurable identity/behaviour:

    - ``static_id`` — the running shell's static id (ping.shell_id; pushes
      with any other ``static_id`` are rejected).
    - ``boot_rm_id`` — rm_id reported at boot (default 0 = greybox, which
      :mod:`pyverify.edge` reads as "no RM loaded").
    - ``known_rm_ids`` — optional ``{rm_name: rm_id}``; when given,
      ``swap``/``commit`` verbs reject unknown RM names.
    - ``clk_presets`` — optional iterable of accepted ``set_clk`` presets
      (``None`` accepts anything, since the preset table is still open —
      I16); ``clk_locked`` is what a successful set_clk reports.
    - ``banners`` — per-console connect banner overrides
      (``{"uart0"/"uart1"/"swo": bytes}``); ``console_echo`` selects echo
      vs absorb after the banner.
    - ``telemetry_lockup`` — the raw ``dut_lockup`` pin the ``telemetry``
      verb reports on its (always-failing) reply. There are deliberately no
      ``telemetry_mv``/``telemetry_ma`` seeds: net-protocol.md v0.6 removed
      ``mv``/``ma`` from the protocol (there is no power sensor on this
      platform), so a fake shell that could still be seeded with a rail
      voltage would be modelling hardware that does not exist.
    - ``boot_active_slot`` — A/B store's active slot at boot; each
      ``commit`` writes the inactive slot and flips (overlay-manifest.md).
    - ``rm_id_readback_override`` / ``rm_id_valid`` — fault injection for
      the swap's VERIFY step (what DFXCTL.RM_ID/RM_STATUS "read back").
    - ``greybox_clearing_available`` — set False to model a shell image
      missing its greybox clearing seed (first swap then fails closed at
      STREAM_CLEARING, exactly like the firmware).

    Observability for tests: ``push_events`` (accepted + rejected
    transfers), ``swaps``, ``resets``, ``commits``, ``link_events``,
    ``pair_ready``, plus :meth:`wait_push_events`.
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        *,
        control_port: int = CONTROL_PORT,
        tftp_port: int = TFTP_PORT,
        raw_tcp_port: int = RAW_TCP_PORT,
        uart0_port: int = UART0_PORT,
        uart1_port: int = UART1_PORT,
        swo_port: int = SWO_PORT,
        static_id: int = STATIC_ID,
        boot_rm_id: int = 0,
        known_rm_ids: Optional[Dict[str, int]] = None,
        clk_presets: Optional[Iterable[str]] = None,
        clk_locked: bool = True,
        reset_targets: Tuple[str, ...] = ("dut", "rp", "dbg"),
        boot_active_slot: str = "A",
        banners: Optional[Dict[str, bytes]] = None,
        console_echo: bool = True,
        telemetry_lockup: bool = False,
        harness_version: str = "0.0.0",
        harness_ver32: int = 0,
        harness_sha: str = "unknown",
        harness_dirty: bool = False,
        harness_usr_access: Optional[int] = None,
        lmb_kb: int = 1024,
        features: Iterable[str] = (),
        diag_counters: Optional[Dict[str, int]] = None,
        has_clcd_kvm: bool = True,
        has_dut_egress: bool = True,
        dut_frames: Optional[Iterable[bytes]] = None,
        dutegr_drop_full: int = 0,
        dutegr_drop_giant: int = 0,
        dutegr_ovf: bool = False,
        dutegr_desync: bool = False,
        boot_display_owner: str = "harness",
        display_commit_polls: int = 0,
        macgen_frames_per_call: int = 8,
        greybox_clearing_available: bool = True,
        greybox_clearing_len_words: int = 4,
        transfer_timeout: float = 5.0,
        swap_await_timeout: float = 10.0,
        swap_arm_grace: float = 1.0,
    ):
        if boot_active_slot not in ("A", "B"):
            raise ValueError("boot_active_slot must be 'A' or 'B'")
        self.host = host
        self.control_port = control_port
        self.tftp_port = tftp_port
        self.raw_tcp_port = raw_tcp_port
        self.uart0_port = uart0_port
        self.uart1_port = uart1_port
        self.swo_port = swo_port

        # Identity / behaviour config.
        self.static_id = static_id
        self.known_rm_ids = dict(known_rm_ids) if known_rm_ids is not None else None
        self.clk_presets = frozenset(clk_presets) if clk_presets is not None else None
        self.clk_locked = clk_locked
        self.reset_targets = tuple(reset_targets)
        self.banners = {"uart0": b"nanosoc boot\n", "uart1": b"", "swo": b""}
        if banners:
            self.banners.update(banners)
        self.console_echo = console_echo
        self.telemetry_lockup = telemetry_lockup
        # Build identity the `version` verb reports (net-protocol.md v0.8 /
        # firmware coordinator_handle_version). DEFAULTS are the firmware's own
        # honest "not provisioned" answer -- the weak mps3_harness_*() seam's
        # 0.0.0 / ver32 0 / sha "unknown" / not dirty -- which is exactly what
        # ctrl_echo reports, because it links only the weak TU. A test modelling
        # a PROVISIONED board passes real values.
        #
        # `features` is the FIRMWARE's compile-time flag set; `has_clcd_kvm`
        # above is the FABRIC's 0x44AD slave. They are different facts and the
        # firmware keeps them separate too (a CLCD_KVM=1 image on a KVM-less
        # bitstream still lists "clcd_kvm" and still answers "clcd_kvm not
        # present"), so a scenario modelling a real board sets BOTH.
        self.harness_version = harness_version
        self.harness_ver32 = harness_ver32
        self.harness_sha = harness_sha
        self.harness_dirty = harness_dirty
        # Wave-B cross-check (net_proto.h "usr_access"/"skew"): what the FABRIC
        # says it is (the bitstream's USR_ACCESS/AXSS register), beside
        # harness_ver32's "what the IMAGE was built as". None (the default) is
        # ctrl_echo's own answer -- coordinator_handle_version() sets no
        # usr_access, so the real firmware's memset(&resp, 0, ...) leaves it
        # empty and the wire carries "usr_access":null,"skew":null: a THIRD
        # state (could not be read), not a pass. A scenario modelling a real
        # board's readback passes the raw u32; `skew` is then DERIVED (never
        # stored) by _op_version, exactly like the firmware derives it in
        # mps3_ctrl_encode_response() -- comparing the two _hex32() strings, not
        # the two ints, so there is one rendering and one comparison.
        self.harness_usr_access: Optional[int] = harness_usr_access
        self.lmb_kb = lmb_kb
        unknown = [f for f in features if f not in VERSION_FEATURES]
        if unknown:
            raise ValueError(
                f"unknown version features {unknown!r} "
                f"(known: {list(VERSION_FEATURES)})"
            )
        # Canonicalised to the firmware's bit order regardless of the order the
        # caller listed them -- the wire array's order is contract.
        self.features: Tuple[str, ...] = tuple(
            f for f in VERSION_FEATURES if f in set(features)
        )
        # `diag` counter mailbox (firmware/common/diag.h). All zero by default:
        # that is a healthy idle shell AND what ctrl_echo reports (its mocks
        # publish nothing), so a scenario-matched fake is byte-identical. A test
        # wanting a wedged-RX scenario overrides the counters it cares about.
        self.diag_counters: Dict[str, int] = {k: 0 for k in DIAG_COUNTERS}
        if diag_counters:
            unknown_diag = [k for k in diag_counters if k not in self.diag_counters]
            if unknown_diag:
                raise ValueError(f"unknown diag counters {unknown_diag!r}")
            self.diag_counters.update(diag_counters)
        # CLCD KVM (net-protocol.md "display"). has_clcd_kvm models whether the
        # running bitstream has the 0x44AD slave: on today's board it does NOT,
        # and the verb answers {"ok":false,"err":"clcd_kvm not present"} exactly
        # like coordinator_handle_display()'s OFF-build path. Default True: this
        # double is the executable spec of the FUTURE (Wave-4) board pyverify is
        # written against. `display_owner` is the committed owner.
        #
        # `display_commit_polls` models THE HANDOVER LAG, which is a documented
        # part of the contract and not a simulation nicety: net-protocol.md
        # "Display" says a flip takes a drain -> panel reset -> settle -> grant
        # (~7-9 ms) to commit, so "immediately after a flip the reply can still
        # report the OUTGOING owner". 0 (the default) keeps the previous
        # idealized instant handover, so every existing test and every existing
        # caller is unchanged. N > 0 means the next N `display` requests after a
        # flip still report the OUTGOING owner, and the (N+1)th reports the new
        # one -- which is what makes `ShellClient.display_settled`'s
        # confirm-then-poll loop testable, and what makes its ABSENCE visible:
        # with N > 0 a bare `display` reports the owner that is going away.
        self.has_clcd_kvm = has_clcd_kvm
        if boot_display_owner not in ("harness", "dut"):
            raise ValueError("boot_display_owner must be 'harness' or 'dut'")
        if display_commit_polls < 0:
            raise ValueError("display_commit_polls must be >= 0")
        self.display_commit_polls = display_commit_polls
        self.display_owner = boot_display_owner
        #: The owner the KVM is heading towards; equals display_owner when no
        #: handover is in flight.
        self.display_target = boot_display_owner
        self._display_pending = 0
        self.macgen_frames_per_call = macgen_frames_per_call
        self.transfer_timeout = transfer_timeout
        #: How long an arriving push waits for a swap's gate to open before it is
        #: rejected — absorbs the thread-scheduling skew between this server's
        #: control and push listeners (see :meth:`_admit_push`). Small enough
        #: that a genuine push-before-swap still fails promptly; comfortably
        #: larger than localhost thread-wakeup latency even under load.
        self.swap_arm_grace = swap_arm_grace
        #: How long a parked swap waits, IDLE, for the bitstream it is awaiting
        #: before failing through the FSM's ``await_timeout`` transition. Idle,
        #: not total: an in-flight transfer re-arms it (swap_fsm.c re-arms the
        #: deadline on every byte of RX progress), so a multi-MB push cannot
        #: trip it. Tests that deliberately never push want this SMALL.
        self.swap_await_timeout = swap_await_timeout

        # VERIFY-step fault injection (what the "hardware" reads back).
        self.rm_id_readback_override: Optional[int] = None
        self.rm_id_valid = True

        # Mutable shell state (mirrors g_shell_state + the A/B store header).
        self.current_rm_id = boot_rm_id
        if greybox_clearing_available:
            # swap_fsm_init()'s boot seed: the greybox's clearing ships
            # inside the shell image (overlay-manifest.md).
            self._current_clearing = ClearingRef(
                valid=True, rm_id=boot_rm_id, static_id=static_id,
                len_words=greybox_clearing_len_words, crc32=0,
            )
        else:
            self._current_clearing = ClearingRef()
        self.active_slot = boot_active_slot
        self.link_up = True
        self.config_agent = ConfigAgentModel(static_id)

        # GENCHK gen/checker model (net-protocol.md "MAC gen/checker control").
        # Counters the `macgen` verb reads back; the register enables + armed
        # inject are the last-written CTRL/INJECT. Counters are monotonic
        # *within* an enabled session but the RTL CLEARS all three on a
        # gen_en/chk_en 0→1 rising edge (shell-regmap.md v0.4 "Counter
        # semantics") — _op_macgen models that clear-on-enable-rise so the
        # divergence is pinned, not silent.
        self.genchk_gen_en = False
        self.genchk_chk_en = False
        self.genchk_inject = "none"
        self.genchk_tx = 0
        self.genchk_rx = 0
        self.genchk_err = 0

        # DUT-egress capture model (net-protocol.md v0.10 "DUT egress";
        # shell-regmap.md DUTEGR; fpga/shell/ip/dut_egress/).
        #
        # `has_dut_egress` is the FABRIC's 0x44B2 slave, exactly like
        # `has_clcd_kvm` above -- and like it, the default models the board this
        # client is WRITTEN for (the block is in the BD, so it arrives at the
        # next mint), while today's fielded bitstream is has_dut_egress=False
        # and answers "dut_egress not present".
        #
        # `dut_frames` are whole frames waiting in the capture FIFO. WHOLE is
        # the word: the block is store-and-forward, so a frame becomes readable
        # only once every byte of it is committed and a torn frame can never be
        # observed -- which is what lets a chunked read be stateless, and why
        # this list holds complete frames rather than a byte stream.
        self.has_dut_egress = has_dut_egress
        self.dut_frames: List[bytes] = [bytes(f) for f in (dut_frames or ())]
        #: bytes of the head frame already handed out (the FIFO IS the cursor)
        self._dutrx_off = 0
        #: DUTEGR.RX_FRAMES -- frames captured WHOLE. Seeded from the queue so a
        #: scenario does not have to keep two numbers in step; push_dut_frame()
        #: advances it, exactly as the block does on a commit.
        self.dutegr_rx_frames = len(self.dut_frames)
        #: DROP_FULL / DROP_GIANT. Settable because the interesting scenario is
        #: a capture that LOST frames: the block cannot backpressure the bridge,
        #: so it drops, and rx + drop_full + drop_giant == frames presented is
        #: the invariant a host checks. A fake that could not model a drop could
        #: not test the client half of that.
        self.dutegr_drop_full = int(dutegr_drop_full)
        self.dutegr_drop_giant = int(dutegr_drop_giant)
        #: STATUS.OVF / STATUS.DESYNC -- sticky, reported raw, never interpreted
        self.dutegr_ovf = bool(dutegr_ovf)
        self.dutegr_desync = bool(dutegr_desync)
        #: every dutrx reply, for tests to assert the chunk sequence on
        self.dutrx_reads: List[Dict[str, Any]] = []

        # Observability.
        self.push_events: List[PushEvent] = []
        self.swaps: List[Dict[str, Any]] = []
        self.resets: List[str] = []
        self.commits: List[Tuple[str, str]] = []
        self.link_events: List[str] = []
        self.clk_requests: List[str] = []
        self.macgen_calls: List[Dict[str, Any]] = []
        self.display_requests: List[str] = []

        # Concurrency plumbing.
        self._lock = threading.RLock()
        self._cond = threading.Condition(self._lock)
        self._active_transfers = 0
        #: THE ARMING GATE. ``None`` = the shell is not expecting a bitstream and
        #: every push is reset; otherwise it is the ONE :class:`BitstreamKind` a
        #: parked swap is currently awaiting (the FSM's ``SWAP_AWAIT_INCOMING_
        #: CLEARING`` / ``SWAP_AWAIT_PARTIAL``).
        #:
        #: It is advanced CLEARING -> PARTIAL -> None **atomically with each
        #: acceptance**, inside :meth:`_ca_finish` under the lock — NOT by the
        #: parked swap's thread when it gets around to stepping the FSM. That
        #: matters: the real client is single-threaded and opens the partial's
        #: connection the instant the clearing's push returns, so a gate that
        #: only opened once the FSM thread had been rescheduled would race and
        #: reject a perfectly correct push. The FSM (the behaviour model) then
        #: follows the gate; the gate is what admission is decided on.
        self._await_kind: Optional[BitstreamKind] = None
        self._swap_in_flight = False
        #: When the parked swap last saw RX progress — the idle-timeout datum.
        self._await_since = 0.0
        self._stop = threading.Event()
        self._servers: List[socketserver.BaseServer] = []
        self._threads: List[threading.Thread] = []
        self._tftp_sock: Optional[socket.socket] = None
        self._started = False

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    @classmethod
    def ephemeral(cls, host: str = "127.0.0.1", **kwargs) -> "FakeShell":
        """A FakeShell with every port OS-assigned (for tests)."""
        for key in ("control_port", "tftp_port", "raw_tcp_port",
                    "uart0_port", "uart1_port", "swo_port"):
            kwargs.setdefault(key, 0)
        return cls(host, **kwargs)

    def start(self) -> "FakeShell":
        if self._started:
            return self
        self._stop.clear()

        control = _ShellTCPServer((self.host, self.control_port), _ControlHandler, self)
        self.control_port = control.server_address[1]
        raw = _ShellTCPServer((self.host, self.raw_tcp_port), _RawPushHandler, self)
        self.raw_tcp_port = raw.server_address[1]
        consoles = []
        for name, port_attr in (("uart0", "uart0_port"), ("uart1", "uart1_port"), ("swo", "swo_port")):
            server = _ShellTCPServer(
                (self.host, getattr(self, port_attr)), _ConsoleHandler, self,
                console_name=name,
            )
            setattr(self, port_attr, server.server_address[1])
            consoles.append(server)
        self.console_ports = {
            "uart0": self.uart0_port, "uart1": self.uart1_port, "swo": self.swo_port,
        }

        self._tftp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._tftp_sock.bind((self.host, self.tftp_port))
        self.tftp_port = self._tftp_sock.getsockname()[1]
        self._tftp_sock.settimeout(0.2)

        self._servers = [control, raw] + consoles
        self._threads = [
            threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True)
            for server in self._servers
        ]
        self._threads.append(threading.Thread(target=self._tftp_serve, daemon=True))
        for thread in self._threads:
            thread.start()
        self._started = True
        return self

    def stop(self) -> None:
        if not self._started:
            return
        self._stop.set()
        for server in self._servers:
            server.shutdown()
            server.server_close()
        if self._tftp_sock is not None:
            self._tftp_sock.close()
            self._tftp_sock = None
        for thread in self._threads:
            thread.join(timeout=2.0)
        self._servers = []
        self._threads = []
        self._started = False

    def __enter__(self) -> "FakeShell":
        return self.start()

    def __exit__(self, *exc_info) -> None:
        self.stop()

    # ------------------------------------------------------------------ #
    # Control channel (TCP 6900) — the 12 verbs of net-protocol.md v0.10
    # ------------------------------------------------------------------ #
    #
    # This tuple is the double's whole verb set and must equal the firmware's
    # s_op_table (net_proto.c). `diag` was missing from it until v0.8 -- the
    # firmware had shipped the verb for weeks and the reference server answered
    # "unknown op 'diag'", which is precisely the class of drift
    # tests/firmware_logic/test_fakeshell_conformance.py exists to catch and
    # could not, because no conformance case sent `diag`. Both are fixed
    # together: the verb is here, and a case sends it.

    def handle_control(self, request: Dict[str, Any]) -> Dict[str, Any]:
        op = request.get("op")
        if not isinstance(op, str) or op not in (
            "ping", "reset", "set_clk", "swap", "link", "commit", "telemetry",
            "macgen", "display", "diag", "version", "dutrx",
        ):
            return {"ok": False, "err": f"unknown op {op!r}"}
        return getattr(self, f"_op_{op}")(request)

    def _op_ping(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # net-protocol.md: {"ok":true,"shell_id":"<static_id>","rm_id":"<id>"}
        with self._lock:
            return {
                "ok": True,
                "shell_id": _hex32(self.static_id),
                "rm_id": _hex32(self.current_rm_id),
            }

    def _op_reset(self, request: Dict[str, Any]) -> Dict[str, Any]:
        target = request.get("target", "dut")
        if target not in self.reset_targets:
            return {"ok": False, "err": f"unknown reset target {target!r}"}
        with self._lock:
            self.resets.append(target)
        return {"ok": True}

    def _op_set_clk(self, request: Dict[str, Any]) -> Dict[str, Any]:
        preset = request.get("preset")
        # Failure shape is the firmware's uniform {"ok":false,"err":...} — the
        # coordinator's mps3_ctrl_encode_response() emits NO per-op fields on
        # failure (net_proto.c), so the reference server must not either. The
        # earlier "locked":false echo here was a fakeshell-only divergence the
        # firmware↔fakeshell conformance suite (tests/firmware_logic/
        # test_fakeshell_conformance.py) now pins closed; the client defaults
        # SetClkResponse.locked to False when the key is absent, so nothing
        # downstream needs it.
        if not isinstance(preset, str) or not preset:
            return {"ok": False, "err": "set_clk requires a 'preset' string"}
        if self.clk_presets is not None and preset not in self.clk_presets:
            return {"ok": False, "err": f"unknown clk preset {preset!r} (I16 preset table)"}
        with self._lock:
            self.clk_requests.append(preset)
        return {"ok": True, "locked": self.clk_locked}

    def _op_link(self, request: Dict[str, Any]) -> Dict[str, Any]:
        event = request.get("event")
        # net-protocol.md v0.2 + firmware coordinator_handle_link accept
        # down/up/pulse (I31(b) — align with the real server). Speed events
        # remain undefined in the contract → fail closed.
        if event not in ("up", "down", "pulse"):
            return {"ok": False, "err": f"unknown link event {event!r}"}
        with self._lock:
            if event in ("up", "down"):
                self.link_up = event == "up"
            # "pulse" is a momentary event: recorded, steady state unchanged.
            self.link_events.append(event)
        return {"ok": True}

    def _op_commit(self, request: Dict[str, Any]) -> Dict[str, Any]:
        rm = request.get("rm")
        if not isinstance(rm, str) or not rm:
            return {"ok": False, "err": "commit requires an 'rm' string"}
        if self.known_rm_ids is not None and rm not in self.known_rm_ids:
            return {"ok": False, "err": f"unknown rm {rm!r}"}
        with self._lock:
            # overlay-manifest.md A/B store: commit writes the INACTIVE
            # slot, verifies, then flips active_slot — respond with the
            # newly-active slot.
            new_slot = "B" if self.active_slot == "A" else "A"
            self.active_slot = new_slot
            self.commits.append((rm, new_slot))
        return {"ok": True, "slot": new_slot}

    def _op_telemetry(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # net-protocol.md v0.6 / firmware coordinator_handle_telemetry():
        # telemetry has NO SUCCESS SHAPE. There is no power sensor reachable
        # from this design (TELEM's sample inputs are tied to ground in the
        # block design, its INA228 I2C engine was never written, its pads are
        # not on the top level, and the MPS3 MCC refuses voltage reads), so
        # the old {"ok":true,"mv":950,"ma":120,...} was a reading-shaped lie.
        # The verb now fails loudly and the mv/ma keys are ABSENT, not zeroed.
        #
        # This reply is the ONE declared carve-out to the uniform failure
        # shape: it carries "lockup" (a real partition pin) on the failure
        # line, because that failure line is the only line telemetry has.
        #
        # The err string is byte-pinned to the firmware's
        # (coordinator.c: set_err(resp, "no power sensor")) and the key ORDER
        # is pinned to net_proto.c's snprintf, because
        # tests/firmware_logic/test_fakeshell_conformance.py compares the two
        # servers' telemetry lines BYTE-FOR-BYTE. Change one, change both.
        with self._lock:
            return {
                "ok": False,
                "err": "no power sensor",
                "lockup": self.telemetry_lockup,
            }

    def _op_macgen(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # net-protocol.md "MAC gen/checker control" / firmware
        # coordinator_handle_macgen: gen/chk are required JSON bools driving
        # GENCHK.CTRL; inject is a required fault name (INJECT one-hot) from
        # the closed MACGEN_INJECTS set. Fail closed on a missing/mistyped arg
        # ("bad args" — mirrors the firmware decode's EBADARGS) or an unknown
        # fault ("bad inject" — mirrors coordinator_handle_macgen). On success
        # the reply's "err" is the ERR_CNT *counter* (int), NOT a diagnostic.
        gen = request.get("gen")
        chk = request.get("chk")
        inject = request.get("inject")
        # Decode-level: a missing/wrong-typed gen/chk/inject is EBADARGS in the
        # firmware ("bad args"); the handler then rejects an unknown fault
        # *string* as "bad inject". Mirror that two-stage split exactly.
        if (not isinstance(gen, bool) or not isinstance(chk, bool)
                or not isinstance(inject, str)):
            return {"ok": False, "err": "bad args"}
        if inject not in MACGEN_INJECTS:
            return {"ok": False, "err": "bad inject"}

        with self._lock:
            # Model the gen/checker: with gen enabled a batch of frames is
            # generated (TX advances); with chk enabled they are checked
            # (RX advances). An armed inject (non-"none") makes exactly the
            # next generated frame fail the checker, so ERR advances by one —
            # only when there is actually a checked frame (gen+chk on). A
            # clean run ("none") never touches ERR.
            #
            # Clear-on-enable-rise (shell-regmap.md v0.4 "Counter semantics"):
            # the RTL zeroes all three counters on a gen_en/chk_en 0→1 rising
            # edge, so a MAC test that toggles an enable off then on sees the
            # counters restart — monotonic within a session, NOT across a
            # toggle. Detect the rise against the last-written enables BEFORE
            # updating them.
            gen_rise = gen and not self.genchk_gen_en
            chk_rise = chk and not self.genchk_chk_en
            if gen_rise or chk_rise:
                self.genchk_tx = 0
                self.genchk_rx = 0
                self.genchk_err = 0
            self.genchk_gen_en = gen
            self.genchk_chk_en = chk
            self.genchk_inject = inject
            frames = self.macgen_frames_per_call if gen else 0
            self.genchk_tx += frames
            if chk:
                self.genchk_rx += frames
                if frames > 0 and inject != "none":
                    self.genchk_err += 1
            reply = {
                "ok": True,
                "tx": self.genchk_tx,
                "rx": self.genchk_rx,
                "err": self.genchk_err,
            }
            self.macgen_calls.append(
                {"gen": gen, "chk": chk, "inject": inject,
                 "tx": self.genchk_tx, "rx": self.genchk_rx, "err": self.genchk_err}
            )
            return reply

    def _op_display(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # net-protocol.md "display" / firmware coordinator_handle_display: the
        # CLCD KVM remote ownership flip. Drives the same frozen
        # CLCDKVM.CTRL.src_sel the button + a local CSR write drive, then reports
        # STATUS.owner. A plain send-now response (never held like swap).
        #
        # OFF-build parity: if this modelled bitstream has no KVM slave, the
        # verb declines exactly like the firmware's !CLCD_KVM_PRESENT path.
        if not self.has_clcd_kvm:
            return {"ok": False, "err": "clcd_kvm not present"}
        owner = request.get("owner")
        if not isinstance(owner, str):
            return {"ok": False, "err": "bad args"}
        with self._lock:
            if owner == "query":
                pass  # read-only: report the committed owner, move nothing
            elif owner == "toggle":
                # A toggle flips the requested TARGET, exactly like a button
                # press -- so a second toggle mid-handover cancels the first
                # (net-protocol.md "Display").
                self.display_target = (
                    "dut" if self.display_target == "harness" else "harness")
                self._display_pending = self.display_commit_polls
                self.display_requests.append(owner)
            elif owner in ("harness", "dut"):
                self.display_target = owner
                self._display_pending = self.display_commit_polls
                self.display_requests.append(owner)
            else:
                return {"ok": False, "err": "bad owner"}

            # Commit the handover after display_commit_polls further requests.
            # With the default 0 this is the previous idealized instant
            # handover: the committed owner equals the target in the same reply.
            if self._display_pending > 0:
                self._display_pending -= 1
            else:
                self.display_owner = self.display_target
            # The reply carries STATUS.owner -- the COMMITTED owner, which is
            # the outgoing one while a handover is still in flight.
            return {"ok": True, "owner": self.display_owner}

    def _op_diag(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # net-protocol.md "diag" / firmware coordinator_handle_diag: a pure
        # readback of the always-on diagnostic mailbox (firmware/common/diag.h).
        # No arguments, never held, and no failure mode -- the counters are RAM,
        # so the only reply is ok:true.
        #
        # The KEY ORDER below is the firmware's snprintf order (DIAG_COUNTERS),
        # not alphabetical: the conformance suite compares these lines
        # byte-for-byte. Values are ints, matching the firmware's %lu.
        with self._lock:
            reply: Dict[str, Any] = {"ok": True}
            reply.update({k: int(self.diag_counters[k]) for k in DIAG_COUNTERS})
            return reply

    def push_dut_frame(self, frame: bytes) -> None:
        """Commit one WHOLE frame into the capture FIFO, as the block does when
        the DUT transmits one. Advances ``RX_FRAMES`` with it: the counter
        counts frames captured whole, so the two cannot drift apart here the way
        they could if a scenario set both by hand."""
        with self._lock:
            self.dut_frames.append(bytes(frame))
            self.dutegr_rx_frames += 1

    def _op_dutrx(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # net-protocol.md v0.10 "DUT egress" / firmware coordinator_handle_dutrx:
        # ONE CHUNK (<= DUTRX_CHUNK bytes) of the frame at the head of the
        # DUT-egress capture FIFO, hex-encoded. No arguments -- the destructive
        # DATA port is its own cursor, so there is no offset to send and no
        # per-connection state to keep. Send-now, never held like swap.
        #
        # OFF-build parity, first: a bitstream with no 0x44B2 slave declines,
        # exactly like the firmware's !DUTEGR_PRESENT path. It must NOT answer
        # ok:true with zeroes -- "this fabric cannot capture" and "the DUT sent
        # nothing" would be the same line, which is the reading-shaped lie v0.6
        # took out of `telemetry`.
        if not self.has_dut_egress:
            return {"ok": False, "err": "dut_egress not present"}

        with self._lock:
            head = self.dut_frames[0] if self.dut_frames else b""
            total = len(head)
            remain = total - self._dutrx_off
            n = min(remain, DUTRX_CHUNK)
            chunk = head[self._dutrx_off:self._dutrx_off + n]
            off = self._dutrx_off

            if self.dut_frames:
                self._dutrx_off += n
                if self._dutrx_off >= total:
                    # The descriptor retires with the frame's LAST byte: the
                    # frame leaves the queue here, which is why `frames` below
                    # (read AFTER the pops, like the firmware reads LEVEL) does
                    # not count a frame this reply just finished.
                    self.dut_frames.pop(0)
                    self._dutrx_off = 0

            reply: Dict[str, Any] = {
                "ok": True,
                "len": total,
                "off": off,
                "n": n,
                "more": (remain - n) > 0,
                # `last` is the raw DATA[9] bit as the firmware saw it on this
                # chunk's final byte -- the block's SECOND, independent record
                # of where the frame ends (the first is the descriptor length).
                # Reported, not reconciled: when the two disagree the block
                # latches DESYNC and this pair is the evidence.
                "last": n > 0 and (off + n) == total,
                "frames": len(self.dut_frames),
                "rx": int(self.dutegr_rx_frames),
                "drop_full": int(self.dutegr_drop_full),
                "drop_giant": int(self.dutegr_drop_giant),
                "ovf": bool(self.dutegr_ovf),
                "desync": bool(self.dutegr_desync),
                # Key ORDER is the firmware's snprintf order (net_proto.c's
                # MPS3_OP_DUTRX arm) -- the conformance suite compares these
                # lines byte-for-byte. `data` is LOWERCASE hex, last, so the one
                # variable-length field sits at the end of the line.
                "data": chunk.hex(),
            }
            self.dutrx_reads.append(dict(reply))
            return reply

    def _op_version(self, request: Dict[str, Any]) -> Dict[str, Any]:
        # net-protocol.md v0.8 "version" / firmware coordinator_handle_version:
        # what IMAGE is this? `ping` answers which FABRIC (static_id) and what
        # is in the RP (rm_id); neither says which firmware release is running
        # or which compile-time features are in it. One static_id serves many
        # harness releases, so those questions are genuinely independent.
        #
        # Every field is a build-time constant on the real server (no register
        # access), which is why this verb answers even on a board whose fabric
        # is unhappy -- and why the double can model it with plain attributes.
        # `dirty` is an INT (0/1), not a bool, matching the firmware's %d; the
        # conformance suite type-checks that. `features` is emitted in the
        # firmware's fixed bit order with absent features omitted.
        #
        # `usr_access`/`skew`: the cross-check, mirroring
        # mps3_ctrl_encode_response()'s MPS3_OP_VERSION arm exactly.
        # harness_usr_access is None (fabric value not read) on the
        # ctrl_echo-matched default, which emits `null` for BOTH keys -- a
        # third state, not a pass. Set, it is compared as a STRING against
        # ver32's own _hex32() rendering (not the two raw ints), so there is
        # one formatter and one comparison, same as the firmware.
        with self._lock:
            reply: Dict[str, Any] = {
                "ok": True,
                "harness": self.harness_version,
                "ver32": _hex32(self.harness_ver32),
                "sha": self.harness_sha,
                "dirty": 1 if self.harness_dirty else 0,
                "lmb_kb": int(self.lmb_kb),
                "features": list(self.features),
            }
            if self.harness_usr_access is None:
                reply["usr_access"] = None
                reply["skew"] = None
            else:
                usr_access_hex = _hex32(self.harness_usr_access)
                reply["usr_access"] = usr_access_hex
                reply["skew"] = usr_access_hex != _hex32(self.harness_ver32)
            return reply

    def _op_swap(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """``swap`` — THE PARKED VERB (see the module docstring's ordering note).

        Does NOT reply until the incoming RM's clearing+partial have been pushed
        *into* it. The caller (a control-channel handler thread, or a test
        driving :meth:`handle_control` directly) blocks here for the whole
        reconfiguration, which is exactly what the real shell does to its 6900
        connection — and exactly what makes the bitstream push possible, since
        the push transports only admit data while this is parked.
        """
        rm = request.get("rm")
        src = request.get("src", "tftp")
        # Uniform firmware failure shape {"ok":false,"err":...} — see the note
        # in _op_set_clk. The client defaults SwapResponse.verified to False and
        # .rm_id to "" when those keys are absent, so dropping the failure-only
        # "verified"/"rm_id" echoes here matches net_proto.c byte-for-byte
        # without losing anything the client reads (pinned by the conformance
        # suite).
        #
        # All of these reject BEFORE arming: a swap the shell never accepted
        # must not leave the push transports open (and the host must not be
        # left pushing into a shell that already said no).
        if not isinstance(rm, str) or not rm:
            return {"ok": False, "err": "swap requires an 'rm' string"}
        if src not in ("tftp", "tcp"):
            return {"ok": False, "err": f"unknown swap src {src!r}"}
        if self.known_rm_ids is not None and rm not in self.known_rm_ids:
            return {"ok": False, "err": f"unknown rm {rm!r}"}
        with self._cond:
            if self._swap_in_flight:
                # swap_fsm_start() returns -1 unless the FSM is SWAP_IDLE.
                return {"ok": False, "err": "a swap is already in flight"}
            self._swap_in_flight = True
        try:
            return self._run_swap(rm, src)
        finally:
            with self._cond:
                self._swap_in_flight = False
                self._await_kind = None   # the gate closes with the swap
                self._cond.notify_all()

    def _run_swap(self, rm: str, src: str) -> Dict[str, Any]:
        # The real behaviour model (the same Python port of swap_fsm.c the
        # integration suite cross-checks against the C), against an idealized
        # instantly-confirming decoupler and a "hardware" RM_ID readback we
        # control (fault-injectable).
        regs = make_regs_confirmed()
        fsm = SwapFsm(regs, current_clearing=self._current_clearing,
                      running_static_id=self.static_id)
        fsm.current_rm_id = self.current_rm_id
        fsm.start(rm)

        # GATE -> DECOUPLE_ASSERT -> STREAM_CLEARING -> AWAIT_INCOMING_CLEARING.
        # This can already FAIL without a single byte being pushed: a shell image
        # with no greybox clearing seed fails closed at STREAM_CLEARING (I2). The
        # host is never invited to push in that case — which is the point of
        # running the FSM this far BEFORE arming the transports.
        _step_until(fsm, ("AWAIT_INCOMING_CLEARING", "FAILED"))
        if fsm.state != "FAILED":
            # ARM. From here until the pair is complete (or the idle timeout),
            # the push transports admit exactly what the FSM is awaiting.
            with self._cond:
                self._await_kind = BitstreamKind.CLEARING
                self._await_since = time.monotonic()
                self._cond.notify_all()

            clearing = self._await_bitstream(BitstreamKind.CLEARING)
            if clearing is None:
                _fail_await_timeout(fsm)
            else:
                fsm.deliver_incoming_clearing(
                    rm_id=clearing.rm_id, len_words=clearing.len_words,
                    static_id=clearing.static_id, crc32=clearing.crc32,
                )
                _step_until(fsm, ("AWAIT_PARTIAL", "FAILED"))

        if fsm.state == "AWAIT_PARTIAL":
            partial = self._await_bitstream(BitstreamKind.PARTIAL)
            if partial is None:
                _fail_await_timeout(fsm)
            else:
                fsm.deliver_partial(
                    rm_id=partial.rm_id, len_words=partial.len_words,
                    static_id=partial.static_id, crc32=partial.crc32,
                )
                # What the "hardware" reads back at DFXCTL.RM_ID/RM_STATUS when
                # VERIFY looks (I25). Known only now — the target rm_id comes
                # from the PARTIAL's own header, not from the swap's rm name.
                readback = (
                    self.rm_id_readback_override
                    if self.rm_id_readback_override is not None
                    else partial.rm_id
                )
                regs.dfxctl_rm_id = readback
                regs.dfxctl_rm_status = (
                    DFXCTL_RM_STATUS_RM_ID_VALID if self.rm_id_valid else 0
                )
                fsm.run_to_completion()

        final = fsm.state
        with self._cond:
            # On DONE the FSM promoted the incoming clearing into the
            # current-clearing cache (net-protocol.md step 5); on FAILED it
            # left the old cache object untouched — either way this is the
            # coordinator's new resident reference.
            self._current_clearing = fsm.current_clearing
            self.swaps.append({
                "rm": rm, "src": src, "final": final,
                "history": list(fsm.history), "rm_id": fsm.current_rm_id,
            })
            if final == "DONE":
                self.current_rm_id = fsm.current_rm_id
                return {"ok": True, "rm_id": _hex32(self.current_rm_id), "verified": True}
        failed_at = fsm.history[-1] if fsm.history else "?"
        # Uniform failure shape (no rm_id/verified echo) — matches the
        # firmware even on the VERIFY-failure path, where net_proto.c still
        # emits only {"ok":false,"err":...}.
        return {
            "ok": False,
            "err": f"swap failed (at {failed_at}); RP left decoupled and held in reset",
        }

    def _await_bitstream(self, kind: BitstreamKind) -> Optional[BitstreamInfo]:
        """Block until the config agent has staged a validated bitstream of
        ``kind``, or the swap's IDLE timeout expires (``None``).

        Idle, not total: while a transfer is actually in flight the deadline is
        pushed out, mirroring swap_fsm.c's "re-armed on every byte of RX
        progress" — so a multi-MB partial cannot time its own swap out.

        Does not touch :attr:`_await_kind`: the gate is advanced by whoever
        ACCEPTS a push (:meth:`_ca_finish`), atomically with the acceptance —
        see the attribute's own comment for why that must not be done here.
        """
        take = (
            self.config_agent.take_clearing
            if kind is BitstreamKind.CLEARING
            else self.config_agent.take_partial
        )
        with self._cond:
            while True:
                staged = take()
                if staged is not None:
                    return staged
                if self._active_transfers > 0:
                    # RX in progress: not idle. Re-arm and re-check shortly.
                    self._await_since = time.monotonic()
                    self._cond.wait(0.05)
                    continue
                idle = time.monotonic() - self._await_since
                remaining = self.swap_await_timeout - idle
                if remaining <= 0:
                    return None
                self._cond.wait(min(remaining, 0.05))

    @property
    def awaiting(self) -> Optional[BitstreamKind]:
        """The bitstream kind a parked swap is currently awaiting, or ``None``
        when the shell would reset any push that arrived right now."""
        with self._lock:
            return self._await_kind

    # ------------------------------------------------------------------ #
    # Bitstream receive bookkeeping (shared by TFTP + raw TCP)
    # ------------------------------------------------------------------ #

    def _transfer_begin(self) -> None:
        with self._cond:
            self._active_transfers += 1
            self._await_since = time.monotonic()   # RX progress re-arms the idle timeout
            self._cond.notify_all()

    def _transfer_end(self) -> None:
        with self._cond:
            self._active_transfers -= 1
            self._cond.notify_all()

    def _ca_validate_header(self, transport: str, header_bytes: bytes):
        with self._cond:
            status, header = self.config_agent.validate_header(header_bytes)
            if status is not ConfigAgentStatus.OK:
                self._record_event(transport, status, header)
            return status, header

    def _admit_push(self, transport: str, header: BitstreamHeader) -> bool:
        """THE ARMING GATE (see :attr:`_await_kind`). ``True`` iff a parked swap
        is awaiting a bitstream of exactly this kind.

        Called from the transports at the point config_agent.c's
        ``begin_payload()`` calls ``sink->begin()`` — i.e. AFTER the header has
        validated, so a bad magic/version/static_id/kind or an I2 ordering
        violation is still reported as *that* error. A refusal is recorded as a
        ``PushEvent`` (``ERR_NOT_AWAITING``) and the transport then resets the
        connection.

        A swap whose gate has not opened yet makes this **wait** a bounded grace
        (:attr:`swap_arm_grace`) rather than rejecting. That is not politeness,
        it is fidelity: the real shell is a single-threaded poll loop, so the
        ``swap`` line — which the correct client sends on 6900 *before* it opens
        the push transport — is already in the shell's receive buffer when the
        push arrives, and the shell processes it (decoupling, streaming the
        outgoing clearing to ICAP, reaching ``SWAP_AWAIT_INCOMING_CLEARING``)
        before it ever looks at the push. This server's listeners are separate
        THREADS with no such ordering, so a push can reach this gate before the
        control thread has even dispatched a swap that was sent first. Waiting a
        short grace for the gate to open absorbs that scheduling skew — a fake
        that rejects a correct client for a race the firmware cannot have is as
        wrong as one that accepts a broken one.

        It does NOT accept the wrong order. A genuine push-before-swap (the bug
        this whole fix exists to catch) sends no swap first, so nothing arms the
        gate within the grace and the push is rejected — exactly as on silicon.
        The tests that drive the wrong order push with the swap sent strictly
        *after* the push has completed, so no swap can sneak the gate open inside
        a push's grace window.

        Rejection is therefore reserved for what it means on the board: no swap
        arrived to open the gate (or one did, and this is not the bitstream it
        is awaiting).
        """
        with self._cond:
            deadline = time.monotonic() + self.swap_arm_grace
            while self._await_kind is not header.kind:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                self._cond.wait(remaining)
            if self._await_kind is header.kind:
                return True
            self._record_event(transport, NOT_AWAITING, header)
            return False

    def wait_awaiting(self, kind: Optional[BitstreamKind], timeout: float = 5.0) -> bool:
        """Block until the arming gate reads ``kind`` (``None`` = shut). For
        tests that want to observe the gate rather than race it — ``swap_begin``
        only *sends*, so the shell has not necessarily armed when it returns."""
        with self._cond:
            deadline = time.monotonic() + timeout
            while self._await_kind is not kind:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                self._cond.wait(remaining)
            return True

    def _ca_finish(self, transport: str, header: BitstreamHeader, payload: bytes) -> ConfigAgentStatus:
        with self._cond:
            status = self.config_agent.finish_payload(header, payload)
            if status is ConfigAgentStatus.OK and self._await_kind is header.kind:
                # Advance the gate ATOMICALLY with the acceptance, so the next
                # push in a single-threaded client's back-to-back sequence can
                # never lose a race against the parked swap's FSM stepping.
                self._await_kind = (
                    BitstreamKind.PARTIAL
                    if header.kind is BitstreamKind.CLEARING
                    else None   # pair complete: the swap takes it from here
                )
            self._record_event(transport, status, header)
            return status

    def _record_event(self, transport: str, status, header: Optional[BitstreamHeader], detail: str = "") -> None:
        # Caller holds the lock.
        name = status.name if isinstance(status, ConfigAgentStatus) else str(status)
        if detail:
            name = f"{name}:{detail}"
        self.push_events.append(PushEvent(
            transport=transport,
            ok=(status is ConfigAgentStatus.OK),
            status=name,
            info=BitstreamInfo.from_header(header) if header is not None else None,
        ))
        self._cond.notify_all()

    @property
    def accepted_pushes(self) -> List[PushEvent]:
        with self._lock:
            return [e for e in self.push_events if e.ok]

    @property
    def rejected_pushes(self) -> List[PushEvent]:
        with self._lock:
            return [e for e in self.push_events if not e.ok]

    @property
    def pair_ready(self) -> bool:
        with self._lock:
            return self.config_agent.pair_ready

    def wait_push_events(self, count: int, timeout: float = 5.0) -> bool:
        """Block until at least ``count`` push events (accepted or
        rejected) have been recorded. For tests using clients that don't
        synchronise on the transport themselves."""
        with self._cond:
            deadline = time.monotonic() + timeout
            while len(self.push_events) < count:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                self._cond.wait(remaining)
            return True

    # ------------------------------------------------------------------ #
    # TFTP server (UDP; RFC1350 WRQ + octet receive only)
    # ------------------------------------------------------------------ #

    def _tftp_serve(self) -> None:
        sock = self._tftp_sock
        while not self._stop.is_set():
            try:
                packet, client = sock.recvfrom(65536)
            except socket.timeout:
                continue
            except OSError:
                break
            if len(packet) < 2:
                continue
            opcode = int.from_bytes(packet[:2], "big")
            if opcode == _OP_WRQ:
                # One transfer at a time, handled inline — mirrors the
                # firmware's single receive session (config_agent.c).
                self._transfer_begin()
                try:
                    self._tftp_receive(client, packet)
                finally:
                    self._transfer_end()
            elif opcode == _OP_RRQ:
                self._tftp_send_error_from(None, client, 4, "reads not supported (push-only server)")
            # anything else on the main socket: ignore (stale/foreign TID)

    def _tftp_send_error_from(self, sock: Optional[socket.socket], addr, code: int, message: str) -> None:
        # RFC1350's ErrMsg is netascii. "replace" (not strict) so a stray
        # non-ASCII character in a diagnostic can never take the TFTP server
        # thread down with a UnicodeEncodeError instead of answering the client.
        packet = struct.pack(">HH", _OP_ERROR, code) + message.encode("ascii", "replace") + b"\0"
        if sock is None:
            temp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                temp.sendto(packet, addr)
            finally:
                temp.close()
        else:
            sock.sendto(packet, addr)

    def _tftp_receive(self, client, wrq_packet: bytes) -> None:
        parts = wrq_packet[2:].split(b"\0")
        if len(parts) < 2:
            self._tftp_send_error_from(None, client, 4, "malformed WRQ")
            with self._cond:
                self._record_event("tftp", "MALFORMED_WRQ", None)
            return
        mode = parts[1]
        if mode.lower() != b"octet":
            # net-protocol.md's payload is binary; netascii would corrupt it.
            self._tftp_send_error_from(None, client, 0, "only octet mode is supported")
            with self._cond:
                self._record_event("tftp", "NON_OCTET_MODE", None)
            return

        # RFC1350: the server answers from a NEW TID (ephemeral port); the
        # client must address all further packets to that TID.
        tsock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            tsock.bind((self.host, 0))
            tsock.settimeout(self.transfer_timeout)
            tsock.sendto(struct.pack(">HH", _OP_ACK, 0), client)

            buf = bytearray()
            header: Optional[BitstreamHeader] = None
            expected_block = 1
            while True:
                try:
                    packet, addr = tsock.recvfrom(65536)
                except socket.timeout:
                    with self._cond:
                        self._record_event("tftp", ConfigAgentStatus.ERR_TRUNCATED, header,
                                           detail="timed out mid-transfer")
                    return
                if addr != client or len(packet) < 4:
                    continue
                opcode = int.from_bytes(packet[:2], "big")
                if opcode == _OP_ERROR:
                    with self._cond:
                        self._record_event("tftp", ConfigAgentStatus.ERR_TRUNCATED, header,
                                           detail="client aborted with TFTP ERROR")
                    return
                if opcode != _OP_DATA:
                    self._tftp_send_error_from(tsock, client, 4, "expected DATA")
                    return
                block = int.from_bytes(packet[2:4], "big")
                if block == (expected_block - 1) & 0xFFFF:
                    # Retransmitted block (our ACK was lost) — re-ACK, drop.
                    tsock.sendto(struct.pack(">HH", _OP_ACK, block), client)
                    continue
                if block != expected_block & 0xFFFF:
                    self._tftp_send_error_from(tsock, client, 4, f"unexpected block {block}")
                    return
                data = packet[4:]
                buf.extend(data)

                if header is None and len(buf) >= HEADER_SIZE:
                    status, header = self._ca_validate_header("tftp", bytes(buf[:HEADER_SIZE]))
                    if status is not ConfigAgentStatus.OK:
                        # Reject BEFORE accepting more payload ("before any
                        # ICAP write") — TFTP ERROR aborts the transfer.
                        self._tftp_send_error_from(tsock, client, 0, f"rejected: {status.name}")
                        return
                    if not self._admit_push("tftp", header):
                        # No swap is awaiting this bitstream (the arming gate —
                        # see the module docstring). TFTP's ERROR packet is this
                        # transport's equivalent of the raw-TCP RST, and unlike
                        # the RST it is unambiguous on the wire, so the pusher
                        # raises rather than silently "succeeding".
                        self._tftp_send_error_from(
                            tsock, client, 0,
                            f"rejected: {NOT_AWAITING} (the shell only accepts a "
                            "bitstream while a swap is awaiting one: issue the "
                            "'swap' RPC FIRST, then push into it)",
                        )
                        return

                final = len(data) < _TFTP_BLOCK
                if final:
                    if header is None:
                        # Transfer too short to even carry a header.
                        with self._cond:
                            status, header = self.config_agent.validate_header(bytes(buf))
                            self._record_event("tftp", status, header)
                        self._tftp_send_error_from(tsock, client, 0, f"rejected: {status.name}")
                        return
                    status = self._ca_finish("tftp", header, bytes(buf[HEADER_SIZE:]))
                    if status is not ConfigAgentStatus.OK:
                        # ERROR instead of the final ACK: the client learns
                        # the push was refused (torn/CRC/size).
                        self._tftp_send_error_from(tsock, client, 0, f"rejected: {status.name}")
                        return
                    tsock.sendto(struct.pack(">HH", _OP_ACK, block), client)
                    return
                tsock.sendto(struct.pack(">HH", _OP_ACK, block), client)
                expected_block = (expected_block + 1) & 0xFFFF
        finally:
            tsock.close()


# --------------------------------------------------------------------------- #
# Reference push clients (test-side counterparts of the two transports).
# The production pusher (W-PUSH) is the real client; these exist so the fake
# shell's own test suite has zero dependency on that concurrent workstream.
# --------------------------------------------------------------------------- #


class TftpError(Exception):
    """The server answered a TFTP transfer with an ERROR packet."""


def tftp_put(host: str, port: int, data: bytes, *, filename: str = "bitstream.bin",
             timeout: float = 5.0) -> None:
    """Minimal RFC1350 TFTP PUT (octet mode). Raises :class:`TftpError` if
    the server rejects the transfer (including the fake shell's
    header/CRC/ordering rejections). Returns only once the server has
    ACKed the final block — i.e. the push is fully validated server-side.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout)
    try:
        wrq = struct.pack(">H", _OP_WRQ) + filename.encode("ascii") + b"\0octet\0"
        sock.sendto(wrq, (host, port))

        def expect_ack(block: int, server_addr=None):
            while True:
                packet, addr = sock.recvfrom(65536)
                if server_addr is not None and addr != server_addr:
                    continue
                opcode = int.from_bytes(packet[:2], "big")
                if opcode == _OP_ERROR:
                    code = int.from_bytes(packet[2:4], "big")
                    message = packet[4:].split(b"\0", 1)[0].decode("ascii", "replace")
                    raise TftpError(f"server error {code}: {message}")
                if opcode == _OP_ACK and int.from_bytes(packet[2:4], "big") == block & 0xFFFF:
                    return addr
                # stale/duplicate ACK — keep waiting

        # RFC1350: the first response fixes the server's transfer TID.
        server_addr = expect_ack(0)
        block = 1
        offset = 0
        while True:
            chunk = data[offset:offset + _TFTP_BLOCK]
            sock.sendto(struct.pack(">HH", _OP_DATA, block & 0xFFFF) + chunk, server_addr)
            expect_ack(block, server_addr)
            offset += len(chunk)
            if len(chunk) < _TFTP_BLOCK:
                return
            block += 1
    finally:
        sock.close()


def raw_tcp_put(host: str, port: int, frame: bytes, *, timeout: float = 5.0) -> None:
    """Push one framed bitstream over the raw-TCP transport (6910): send,
    half-close, then wait for the server to close — with the fake shell,
    EOF means validation has finished and the push state is observable
    (see the "no acknowledgement" ambiguity note in the module docstring;
    unlike :func:`tftp_put` there is no accept/reject signal on the wire).

    A server-side *rejection* races with the send: when the fake shell
    refuses the header it returns without draining the payload, so its
    ``close()`` of a socket with unread bytes emits a TCP RST. Depending
    on exactly when that RST lands relative to this client's syscalls,
    ``sendall``/``shutdown``/``recv`` raise ``ECONNRESET``/``EPIPE``/
    ``ENOTCONN`` instead of delivering a clean EOF (this was a real,
    test-order-dependent flake). Any :class:`OSError` after the
    connection is established therefore means the same thing as EOF: the
    server has finished with this transfer — and since the fake shell
    always records the :class:`PushEvent` *before* its handler returns
    (and the RST can only be generated by the close that follows), the
    push outcome is already observable when we swallow the error.
    """
    sock = socket.create_connection((host, port), timeout=timeout)
    try:
        sock.settimeout(timeout)
        try:
            sock.sendall(frame)
            sock.shutdown(socket.SHUT_WR)
            while sock.recv(4096):
                pass
        except OSError:
            pass  # reset by a rejecting server: as synchronised as EOF (above)
    finally:
        sock.close()
