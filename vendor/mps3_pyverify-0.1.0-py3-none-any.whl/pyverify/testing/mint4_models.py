"""FakeShell models of net-protocol v0.20 (mint 4): hostio, sensors, mcc, cosim.

The executable spec the firmware/harnessd lane is held to (docs/contracts/
net-protocol.md "Mint 4 -- hostio streams, `sensors`, `mcc`, `cosim`, `hostio`").
Each model is created by FakeShell only when the engine feature name is on, and
answers through ``op(request, peer)`` with the contract's order of refusals:
act known -> hard deny -> claim lock -> argument checks -> block/route/state -> act.
"""
from __future__ import annotations

import re
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

from .. import mint4 as m4

Reply = Dict[str, Any]


def _fail(err: str, code: str) -> Reply:
    return {"ok": False, "err": err, "code": code}


def _int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _locked(verb: str) -> Reply:
    return _fail(f"{verb} locked: board claimed (use ssh)", "locked")


# --------------------------------------------------------------------------- #
# hostio
# --------------------------------------------------------------------------- #
class HostioModel:
    """The hostio bridge: mode (CTRL.MODE latched at RP release), two byte channels."""

    def __init__(self, shell: Any, cfg: Optional[Dict[str, Any]]) -> None:
        cfg = dict(cfg or {})
        bad = set(cfg) - {"mode", "present", "echo", "rp_held"}
        if bad:
            raise ValueError(f"unknown hostio config keys {sorted(bad)}")
        self.shell = shell
        self.present = bool(cfg.get("present", True))      # False: the block does not answer
        self.mode = cfg.get("mode", "console")             # what the RP sees (rp_mode_o)
        self.pending = self.mode                           # CTRL.MODE
        self.echo = bool(cfg.get("echo", False))           # ADP/USRT1 loopback in hostio4 mode
        self.rp_held = bool(cfg.get("rp_held", False))     # the RP is held in reset
        if self.mode not in m4.HOSTIO_MODES:
            raise ValueError("hostio mode must be console|hostio4")
        self.clients: Dict[int, Any] = {}                  # channel -> live socket
        self.from_host: Dict[int, bytearray] = {0: bytearray(), 1: bytearray()}
        self.drops: Dict[int, int] = {0: 0, 1: 0}
        self.discarded: Dict[int, int] = {0: 0, 1: 0}      # a non-holder's bytes on 6931
        self.lock = threading.Lock()

    @property
    def held(self) -> bool:
        return self.rp_held or self.shell._swap_in_flight

    def rp_released(self) -> None:
        """The RP's reset was released (a swap, `reset rp`): CTRL.MODE is latched and
        both channels are flushed (nothing read after a swap came from the old RM)."""
        with self.lock:
            self.mode = self.pending
            for ch in (0, 1):
                self.from_host[ch].clear()

    def dut_send(self, ch: int, data: bytes) -> int:
        """The DUT transmits ``data`` on channel ``ch`` (0 ADP, 1 USRT1). Only in
        hostio mode; with no client the bytes are dropped and counted."""
        if self.mode != "hostio4":
            return 0
        sock = self.clients.get(ch)
        if sock is None:
            self.drops[ch] = (self.drops[ch] + len(data)) & 0xFFFF
            return 0
        try:
            sock.sendall(data)
        except OSError:
            self.drops[ch] = (self.drops[ch] + len(data)) & 0xFFFF
            return 0
        return len(data)

    def on_host_bytes(self, ch: int, data: bytes, peer: Optional[str]) -> None:
        if ch == 1 and self.shell._claim_locked(peer):
            self.discarded[1] += len(data)                 # 6931 is read-only for a non-holder
            return
        with self.lock:
            buf = self.from_host[ch]
            room = 1024 - len(buf)
            buf.extend(data[:max(room, 0)])
        if self.echo and self.mode == "hostio4":
            self.dut_send(ch, data)

    def take_host_bytes(self, ch: int) -> bytes:
        with self.lock:
            out = bytes(self.from_host[ch])
            self.from_host[ch].clear()
        return out

    def _body(self, act: str) -> Reply:
        lv = lambda ch: {"en": True, "rx": 0, "tx": len(self.from_host[ch])}   # noqa: E731
        return {"ok": True, "op": "hostio", "act": act, "mode": self.mode,
                "pending": self.pending, "held": bool(self.held),
                "target_rst": bool(self.held), "ch0": lv(0), "ch1": lv(1),
                "drops": {"ch0": self.drops[0], "ch1": self.drops[1]}}

    def op(self, req: Reply, peer: Optional[str]) -> Reply:
        act = req.get("act", "get")
        if act not in ("get", "set"):
            return _fail("invalid act: get|set", "invalid")
        if act == "set" and self.shell._claim_locked(peer):
            return _locked("hostio")
        if not self.present:
            return _fail("hostio: no hostio", "no_hw")
        if act == "get":
            return self._body("get")
        mode = req.get("mode")
        if mode not in m4.HOSTIO_MODES:
            return _fail("invalid mode: console|hostio4", "invalid")
        if not (self.held or self.shell.current_rm_id == 0):
            return _fail(f"hostio mode: RP is running 0x{self.shell.current_rm_id:08x} "
                         "(hold it or swap the greybox first)", "not_held")
        self.pending = mode
        return {"ok": True, "op": "hostio", "act": "set", "mode": self.mode,
                "pending": self.pending, "applies": "rp_release"}


# --------------------------------------------------------------------------- #
# sensors (SYSMON)
# --------------------------------------------------------------------------- #
_ALARM_VAUX = (1.71, 1.89)
_ALARM_VBRAM = (0.90, 1.00)


class SensorsModel:
    """SYSMON on the static die. Values are set with :meth:`set_values`; the model
    derives the raw codes with the datasheet formulas the contract names."""

    def __init__(self, shell: Any, cfg: Optional[Dict[str, Any]]) -> None:
        cfg = dict(cfg or {})
        bad = set(cfg) - {"temp_c", "vccint_v", "vccaux_v", "vccbram_v", "ref", "k", "cal",
                          "touch_temp_c", "persist", "present"}
        if bad:
            raise ValueError(f"unknown sysmon config keys {sorted(bad)}")
        self.shell = shell
        self.present = bool(cfg.get("present", True))
        self.ref = cfg.get("ref", "internal")
        if self.ref not in ("internal", "external"):
            raise ValueError("sysmon ref must be internal|external")
        self.k = float(cfg.get("k", 1.0 if self.ref == "external" else 0.0))
        self.cal = cfg.get("cal", "none" if self.k in (0.0, 1.0) else "persist")
        self.persist = bool(cfg.get("persist", True))
        self.touch_temp_c = cfg.get("touch_temp_c")
        self.thr = {"temp_hi_c": 80.0, "temp_ot_c": 100.0, "vccint_lo_v": 0.922, "vccint_hi_v": 0.978}
        self.alm = 0
        self.temp_raw_c = float(cfg.get("temp_c", 41.2))
        self.vccint_v = float(cfg.get("vccint_v", 0.951))
        self.vccaux_v = float(cfg.get("vccaux_v", 1.801))
        self.vccbram_v = float(cfg.get("vccbram_v", 0.952))
        self.max_raw_c = self.min_raw_c = self.temp_raw_c
        self.vmax = {"vccint": self.vccint_v, "vccaux": self.vccaux_v, "vccbram": self.vccbram_v}
        self.vmin = dict(self.vmax)

    # -- the physics ---------------------------------------------------------- #
    def set_values(self, *, temp_c: Optional[float] = None, vccint_v: Optional[float] = None,
                   vccaux_v: Optional[float] = None, vccbram_v: Optional[float] = None) -> None:
        """Move the sensors (tests); max/min track like SYSMON's registers."""
        if temp_c is not None:
            self.temp_raw_c = float(temp_c)
            self.max_raw_c = max(self.max_raw_c, self.temp_raw_c)
            self.min_raw_c = min(self.min_raw_c, self.temp_raw_c)
        for key, val in (("vccint", vccint_v), ("vccaux", vccaux_v), ("vccbram", vccbram_v)):
            if val is not None:
                setattr(self, f"{key}_v", float(val))
                self.vmax[key] = max(self.vmax[key], float(val))
                self.vmin[key] = min(self.vmin[key], float(val))

    def _temp_code(self, t: float) -> int:
        if self.ref == "external":
            return int(round((t + 273.8195) * 65536 / 502.9098)) & 0xFFFF
        return int(round((t + 273.6777) * 65536 / 501.3743)) & 0xFFFF

    def _cal(self, raw_c: float) -> float:
        if self.ref == "external":
            return (raw_c + 273.8195) * self.k - 273.8195
        return raw_c + self.k

    @staticmethod
    def _vcode(v: float) -> int:
        return int(round(v * 65536 / 3)) & 0xFFFF

    def _latch(self) -> None:
        t = self._cal(self.temp_raw_c)
        if t >= self.thr["temp_ot_c"]:
            self.alm |= 1
        if t >= self.thr["temp_hi_c"]:
            self.alm |= 2
        if not self.thr["vccint_lo_v"] <= self.vccint_v <= self.thr["vccint_hi_v"]:
            self.alm |= 4
        if not _ALARM_VAUX[0] <= self.vccaux_v <= _ALARM_VAUX[1]:
            self.alm |= 8
        if not _ALARM_VBRAM[0] <= self.vccbram_v <= _ALARM_VBRAM[1]:
            self.alm |= 16

    def stats_block(self) -> Dict[str, int]:
        self._latch()
        tc = self._temp_code
        out = {"temp": tc(self.temp_raw_c), "temp_max": tc(self.max_raw_c),
               "temp_min": tc(self.min_raw_c)}
        for key in ("vccint", "vccaux", "vccbram"):
            out[key] = self._vcode(getattr(self, f"{key}_v"))
            out[f"{key}_max"] = self._vcode(self.vmax[key])
            out[f"{key}_min"] = self._vcode(self.vmin[key])
        out["flag"] = 0x200 if self.ref == "external" else 0
        out["alm"] = self.alm
        return out

    def _body(self, act: str) -> Reply:
        self._latch()
        r = lambda v, n: round(v, n)          # noqa: E731
        return {"ok": True, "op": "sensors", "act": act, "ref": self.ref,
                "k": self.k, "cal": self.cal,
                "temp_c": r(self._cal(self.temp_raw_c), 1), "temp_raw_c": r(self.temp_raw_c, 1),
                "temp_max_c": r(self._cal(self.max_raw_c), 1),
                "temp_min_c": r(self._cal(self.min_raw_c), 1),
                "vccint_v": r(self.vccint_v, 3), "vccaux_v": r(self.vccaux_v, 3),
                "vccbram_v": r(self.vccbram_v, 3), "touch_temp_c": self.touch_temp_c,
                "alm": self.alm, "thr": dict(self.thr)}

    def op(self, req: Reply, peer: Optional[str]) -> Reply:
        act = req.get("act", "get")
        if act not in m4.SENSORS_ACTS:
            return _fail("invalid act: get|set|clear_alm", "invalid")
        if act != "get" and self.shell._claim_locked(peer):
            return _locked("sensors")
        if act == "set":
            err = self._check_set(req)
            if err:
                return _fail(err, "invalid")
        if not self.present:
            return _fail("sensors: no sysmon", "no_hw")
        if act == "get":
            return self._body("get")
        if act == "clear_alm":
            self.alm = 0
            return self._body("clear_alm")
        for key in m4.SENSORS_SET_KEYS:
            if key in req:
                if key == "k":
                    self.k, self.cal = float(req[key]), "set"
                else:
                    self.thr[key] = float(req[key])
        body = self._body("set")
        body["persisted"] = self.persist
        return body

    def _check_set(self, req: Reply) -> Optional[str]:
        given = {k: req[k] for k in m4.SENSORS_SET_KEYS if k in req}
        if not given:
            return "invalid request: nothing to set"
        for k, v in given.items():
            if not _num(v):
                return f"invalid {k}: not a number"
        thr = dict(self.thr)
        thr.update({k: float(v) for k, v in given.items() if k != "k"})
        if not 0 < thr["temp_hi_c"] < thr["temp_ot_c"] <= 125:
            return "invalid temp_hi_c: need 0 < temp_hi_c < temp_ot_c <= 125"
        if not 0.5 <= thr["vccint_lo_v"] < thr["vccint_hi_v"] <= 1.2:
            return "invalid vccint_lo_v: need 0.5 <= lo < hi <= 1.2"
        if "k" in given:
            lo, hi = (0.5, 2.0) if self.ref == "external" else (-20.0, 20.0)
            if not lo <= float(given["k"]) <= hi:
                return f"invalid k: {lo}..{hi} for ref {self.ref}"
        return None


# --------------------------------------------------------------------------- #
# mcc
# --------------------------------------------------------------------------- #
_DEFAULT_OSC = {0: 25_000_000, 1: 100_000_000, 2: 50_000_000, 3: 12_000_000,
                4: 50_000_000, 5: 50_000_000, 6: 100_000_000, 7: 50_000_000}
_TOKEN = re.compile(r"^[0-9A-Fa-f]{8,32}$")
LOG_CHUNK = 256


class MccModel:
    """The MCC over the SCC (feature ``mccif``) and the USB loopback (``mcc_local``)."""

    def __init__(self, shell: Any, cfg: Optional[Dict[str, Any]]) -> None:
        cfg = dict(cfg or {})
        bad = set(cfg) - {"scc", "loopback", "temp_c", "osc", "reboot_ack", "tty", "msd"}
        if bad:
            raise ValueError(f"unknown mcc config keys {sorted(bad)}")
        self.shell = shell
        feats = shell.features
        self.scc = bool(cfg.get("scc", True)) and "mccif" in feats
        self.loopback = bool(cfg.get("loopback", True)) and "mcc_local" in feats
        self.temp_c = float(cfg.get("temp_c", 35.0))
        self.osc = dict(_DEFAULT_OSC)
        self.osc.update(cfg.get("osc", {}))
        self.reboot_ack = bool(cfg.get("reboot_ack", True))
        self.tty = cfg.get("tty", "/dev/ttyUSB0")
        self.msd = bool(cfg.get("msd", False))
        self.mbox_in: List[int] = [0, 0, 0, 0]
        self.mbox_out: List[int] = [0, 0, 0, 0]
        self.last_reboot: Optional[Dict[str, str]] = None
        self.reboots: List[str] = []                        # tokens accepted, in order
        self.busy = False                                   # a second opener holds the console
        self.logs = {"loopback": bytearray(b"Cmd> \r\n"), "scc": bytearray(b"MCCIF trace: scc_seen 1\r\n")}
        self.log_dropped = 0
        self.warm_resets = 0
        self.ddr_resets = 0

    # -- scenario helpers ------------------------------------------------------ #
    def avail(self, route: str) -> bool:
        return self.scc if route == "scc" else self.loopback

    def _status(self) -> Reply:
        scc = ({"brev": 2, "aclk_hz": 100_000_000, "gate": "cb", "gate_ms": 0, "cb_events": 0,
                "osc1_hz": self.osc[1], "cfgclk_hz": 500_000, "osc2_hz": self.osc[2],
                "mbox_in": list(self.mbox_in)} if self.scc else None)
        lb = ({"tty": self.tty, "prompt": True, "msd": self.msd, "busy": self.busy,
               "last_reboot": dict(self.last_reboot) if self.last_reboot else None}
              if self.loopback else None)
        return {"ok": True, "op": "mcc", "act": "status", "route": "none",
                "scc": scc, "loopback": lb}

    def _deny(self, act: str, req: Reply) -> Optional[Reply]:
        if act in m4.MCC_DENY_ACTS:
            return _fail(f"mcc {act} denied: never served", "denied")
        if act == "osc_set" and _int(req.get("dev")) and req["dev"] in m4.MCC_OSC_PROTECTED:
            return _fail(f"mcc osc_set denied: dev {req['dev']} is "
                         f"{m4.MCC_OSC_WHY[req['dev']]}", "denied")
        if act == "probe" and _int(req.get("func")) and req["func"] not in m4.MCC_PROBE_FUNCS:
            return _fail(f"mcc probe denied: func {req['func']} (read-only funcs 1, 2, 4)", "denied")
        return None

    def op(self, req: Reply, peer: Optional[str]) -> Reply:
        act = req.get("act")
        if not isinstance(act, str) or (act not in m4.MCC_ACTS and act not in m4.MCC_DENY_ACTS):
            return _fail("invalid act: " + "|".join(m4.MCC_ACTS), "invalid")
        denied = self._deny(act, req)
        if denied:
            return denied
        if (act in ("osc_set", "reboot")
                or (act == "mbox" and any(k in req for k in ("w0", "w1", "w2", "w3")))) \
                and self.shell._claim_locked(peer):
            return _locked("mcc")
        err = self._check_args(act, req)
        if err:
            return _fail(err, "invalid")
        route = req.get("route")
        if act == "status":
            return self._status()
        allowed = m4.MCC_ACT_ROUTES[act]
        if route is not None and route not in allowed:
            return _fail(f"invalid route: {act} uses {'|'.join(allowed)}", "invalid")
        if route is None:
            route = next((r for r in allowed if self.avail(r)), allowed[0])
        if not self.avail(route):
            return _fail(f"mcc {act}: no {route} route", "no_route")
        return getattr(self, f"_act_{act}")(req, route)

    def _check_args(self, act: str, req: Reply) -> Optional[str]:
        route = req.get("route")
        if route is not None and route not in m4.MCC_ROUTES:
            return "invalid route: scc|loopback"
        if act in ("osc", "osc_set"):
            dev = req.get("dev")
            if not _int(dev) or not 0 <= dev <= 7:
                return "invalid dev: 0..7"
        if act == "osc_set":
            hz = req.get("hz")
            if not _int(hz) or not m4.OSC_HZ_MIN <= hz <= m4.OSC_HZ_MAX:
                return f"invalid hz: {m4.OSC_HZ_MIN}..{m4.OSC_HZ_MAX}"
            if req.get("arm") is not True:
                return "invalid arm: osc_set must be armed"
        if act == "probe":
            dev = req.get("dev", 0)
            if not _int(req.get("func")):
                return "invalid func: an integer"
            if not _int(dev) or not 0 <= dev <= 4095:
                return "invalid dev: 0..4095"
        if act == "mbox":
            for k in ("w0", "w1", "w2", "w3"):
                if k in req and (not _int(req[k]) or not 0 <= req[k] <= 0xFFFFFFFF):
                    return f"invalid {k}: a u32"
        if act == "log":
            off = req.get("off", 0)
            if not _int(off) or off < 0:
                return "invalid off: an integer >= 0"
        if act == "reboot":
            tok = req.get("token")
            if not isinstance(tok, str) or not _TOKEN.match(tok):
                return "invalid token: 8-32 hex digits"
        return None

    # -- the acts -------------------------------------------------------------- #
    def _head(self, act: str, route: str) -> Reply:
        return {"ok": True, "op": "mcc", "act": act, "route": route}

    def _act_temp(self, req: Reply, route: str) -> Reply:
        return {**self._head("temp", route), "temp_c": self.temp_c, "age_s": 0}

    def _act_osc(self, req: Reply, route: str) -> Reply:
        return {**self._head("osc", route), "dev": req["dev"], "hz": self.osc[req["dev"]],
                "ms": 3 if route == "scc" else 5200}

    def _act_osc_set(self, req: Reply, route: str) -> Reply:
        if req["dev"] not in m4.MCC_OSC_ALLOWED:           # defence in depth: unreachable
            return _fail("mcc osc_set denied: protected", "denied")
        self.osc[req["dev"]] = req["hz"]
        return {**self._head("osc_set", route), "dev": req["dev"], "hz_set": req["hz"],
                "measured_hz": req["hz"] if route == "scc" else None}

    def _act_probe(self, req: Reply, route: str) -> Reply:
        func, dev = req["func"], req.get("dev", 0)
        data = {1: self.osc.get(dev & 7, 0), 2: 1, 4: int(self.temp_c * 1000)}[func]
        return {**self._head("probe", route), "func": func, "dev": dev,
                "data": f"0x{data:08x}", "stat": "0x00000000"}

    def _act_mbox(self, req: Reply, route: str) -> Reply:
        for i in range(4):
            if f"w{i}" in req:
                self.mbox_out[i] = req[f"w{i}"]
        return {**self._head("mbox", route), "mbox_in": list(self.mbox_in),
                "mbox_out": list(self.mbox_out)}

    def _act_log(self, req: Reply, route: str) -> Reply:
        buf = self.logs[route]
        off = req.get("off", 0)
        chunk = bytes(buf[off:off + LOG_CHUNK])
        return {**self._head("log", route), "off": off, "n": len(chunk),
                "more": off + len(chunk) < len(buf), "dropped": self.log_dropped,
                "data": chunk.hex()}

    def _act_reboot(self, req: Reply, route: str) -> Reply:
        sh = self.shell
        slots_busy = bool(sh.slots is not None and (sh.slots.poll() or sh.slots.busy()))
        if self.busy or sh._swap_in_flight or slots_busy or sh._commit_in_flight:
            return _fail("busy: a card job or a second opener holds the MCC console", "busy")
        tok = req["token"]
        self.reboots.append(tok)
        self.last_reboot = {"token": tok, "state": "done" if self.reboot_ack else "failed"}
        if self.reboot_ack:
            t = threading.Timer(0.05, sh._simulate_restart)
            t.daemon = True
            t.start()
        return {**self._head("reboot", route), "accepted": True, "token": tok,
                "eta_min_s": 100, "eta_max_s": 180}

    # -- reset targets ----------------------------------------------------------- #
    def reset(self, target: str, peer: Optional[str]) -> Reply:
        sh = self.shell
        if sh._claim_locked(peer):
            return _locked("reset")
        slots_busy = bool(sh.slots is not None and (sh.slots.poll() or sh.slots.busy()))
        if sh._swap_in_flight or slots_busy or sh._commit_in_flight:
            return _fail("busy: EBUSY (a swap or a card job is running)", "busy")
        if not self.scc:
            return _fail("reset: no mccif", "no_hw")
        if target == "mcc_warm":
            self.warm_resets += 1
            in_ms = 1500
            t = threading.Timer(in_ms / 1000.0, sh._simulate_restart)
            t.daemon = True
            t.start()
            return {"ok": True, "op": "reset", "target": "mcc_warm", "in_ms": in_ms}
        self.ddr_resets += 1
        return {"ok": True, "op": "reset", "target": "ddr"}


# --------------------------------------------------------------------------- #
# cosim (CLKCTL)
# --------------------------------------------------------------------------- #
class CosimModel:
    """CLKCTL: RUN / HALT / STEP over a 64-bit count of enabled DUT clock cycles.
    While running the count advances with wall time at the DUT clock; halted, it
    is frozen; a step adds exactly ``n`` and halts."""

    def __init__(self, shell: Any, cfg: Optional[Dict[str, Any]]) -> None:
        cfg = dict(cfg or {})
        bad = set(cfg) - {"cycles", "present", "mode"}
        if bad:
            raise ValueError(f"unknown cosim config keys {sorted(bad)}")
        self.shell = shell
        self.present = bool(cfg.get("present", True))
        self._base = int(cfg.get("cycles", 0))
        self._t_run: Optional[float] = None
        self.running = True
        if cfg.get("mode", "run") == "halt":
            self.running = False
        if self.running:
            self._t_run = time.monotonic()
        self.steps: List[int] = []

    def _mhz(self) -> int:
        preset = self.shell.clk_requests[-1] if self.shell.clk_requests else None
        if preset and preset.endswith("mhz") and preset[:-3].isdigit():
            return int(preset[:-3])
        return 50

    def cycles(self) -> int:
        if self.running and self._t_run is not None:
            return self._base + int((time.monotonic() - self._t_run) * self._mhz() * 1_000_000)
        return self._base

    def _freeze(self) -> None:
        self._base = self.cycles()
        self.running, self._t_run = False, None

    def force_run(self) -> None:
        """A swap / `reset dut` / `reset rp` restores RUN."""
        if not self.running:
            self.running, self._t_run = True, time.monotonic()

    def _body(self, act: str, **extra: Any) -> Reply:
        return {"ok": True, "op": "cosim", "act": act, "mode": "run" if self.running else "halt",
                "running": self.running, "cycles": self.cycles(), "remaining": 0, **extra}

    def op(self, req: Reply, peer: Optional[str]) -> Reply:
        act = req.get("act")
        if not isinstance(act, str) or act not in m4.COSIM_ACTS:
            return _fail("invalid act: step|halt|run|cycles", "invalid")
        if act != "cycles" and self.shell._claim_locked(peer):
            return _locked("cosim")
        if act == "step":
            n = req.get("n")
            if not _int(n) or not 1 <= n <= m4.COSIM_STEP_MAX:
                return _fail(f"invalid n: 1..{m4.COSIM_STEP_MAX}", "invalid")
        if not self.present:
            return _fail("cosim: no clkctl", "no_hw")
        if act == "cycles":
            return self._body("cycles")
        if act == "halt":
            self._freeze()
            return self._body("halt")
        if act == "run":
            self.force_run()
            return self._body("run")
        self._freeze()
        self._base += n
        self.steps.append(n)
        return self._body("step", n=n)
