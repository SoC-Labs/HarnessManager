"""FakeShell model of the board lease and panel access (net-protocol v0.21, lane P2).

The executable spec harnessd's lease lanes are held to (parity with the harnessd mock in
harnessd tests/test_fakeshell_parity.py). Created by FakeShell only when the engine
feature ``board_lease`` is on; answers through ``op(request, peer)``.

It enforces the gate the way the board does (reports/sec_interface.md): panel access first
(``busy_access``), then the claim (``locked``), then, in single-user mode, the lease
(``leased`` / ``lease_required`` / ``bad_token``) on every MUTATE row; reads stay open.

Time is RELATIVE seconds on an injectable clock: ``cfg["clock"]`` (a callable returning
seconds) or, by default, an internal counter moved by :meth:`advance`.

Session identity: the board identifies a waiter by its ``who`` together with the SSH session
that carried its request; here a session is the ``peer`` string FakeShell passes. The owner
key (``mode``) is any peer in ``cfg["owner_peers"]`` (default: every key holder is owner).

Choices the contract leaves open (parity lanes: confirm against harnessd):
  * a SUSPENDED holder (after :meth:`reboot`) is refused ``leased`` on gated verbs, token or
    not, until its ``heartbeat`` reclaims within ``reclaim_s``;
  * ``revoke`` vacates the lease and reserves the head (plain ``ok`` reply, no token);
  * a malformed ``"lease"`` token is ``bad_token`` (the contract table), not ``bad args``.
"""
from __future__ import annotations

import random
import secrets
from typing import Any, Callable, Dict, List, Optional, Tuple

from ..board_lease import (ACTS, DEFAULT_TTL_S, LOCAL_HOLD_S, MODE_OPEN, MODE_SINGLE, QUEUE_MAX,
                           RECLAIM_S, REQUEST_WINDOW_S)

Reply = Dict[str, Any]

IDLE_S = 1800
CAP_S = 4 * 3600
HISTORY_N = 8
TTL_MIN, TTL_MAX = 300, 14400
_HEXD = frozenset("0123456789abcdef")

#: Rows whose enforcement point asks panel access first.
ACCESS_VERBS = ("display", "touch_cal", "reboot", "panel", "locate")


def _fail(err: str, code: str) -> Reply:
    return {"ok": False, "err": err, "code": code}


def _is_token(v: Any) -> bool:
    return isinstance(v, str) and len(v) == 32 and set(v) <= _HEXD


def mutation_verb(request: Dict[str, Any]) -> Tuple[Optional[str], bool]:
    """(verb, lease_gated) for a 6900 request: ``verb`` is the claim-table MUTATE row's verb
    (None for READ/INVALID rows and for ``lease`` itself). The second item is False for the
    rows that are access-only (``locate``)."""
    op = request.get("op")
    act = request.get("act")
    if op in ("set_clk", "swap", "link", "commit", "macgen", "dutrx", "reboot", "reset"):
        return op, True
    if op == "identity_set":
        return "identity", True
    if op == "usd":
        a = request.get("action", "")
        return ("usd", True) if a not in ("", None) else (None, False)
    if op == "slot":
        return ("slot", True) if act in ("commit", "rollback") else (None, False)
    if op == "panel":
        return ("panel", True) if "page" in request else (None, False)
    if op == "display":
        return ("display", True) if request.get("owner") in ("dut", "harness", "toggle") else (None, False)
    if op == "touch_cal":
        return ("touch_cal", True) if act in ("set", "default") else (None, False)
    if op == "hostio":
        return ("hostio", True) if act == "set" else (None, False)
    if op == "sensors":
        return ("sensors", True) if act in ("set", "clear_alm") else (None, False)
    if op == "mcc":
        w = any(k in request for k in ("w0", "w1", "w2", "w3"))
        return ("mcc", True) if (act in ("osc_set", "reboot") or (act == "mbox" and w)) else (None, False)
    if op == "cosim":
        return ("cosim", True) if act in ("step", "halt", "run") else (None, False)
    return None, False


def _access_row(request: Dict[str, Any]) -> Optional[str]:
    """The verb of a row that asks panel access (step 0), or None."""
    op = request.get("op")
    if op == "locate":
        return "locate"
    verb, _ = mutation_verb(request)
    return verb if verb in ("display", "touch_cal", "reboot", "panel") else None


class BoardLeaseModel:
    """The board's lease table and the access state machine, in memory (relative time)."""

    def __init__(self, shell: Any, cfg: Optional[Dict[str, Any]] = None) -> None:
        cfg = dict(cfg or {})
        bad = set(cfg) - {"clock", "mode", "persistent", "owner_peers", "seed", "label"}
        if bad:
            raise ValueError(f"unknown board_lease config keys {sorted(bad)}")
        self._shell = shell
        self.cfg = cfg
        self._clock: Optional[Callable[[], float]] = cfg.get("clock")
        self._t = 0.0
        self.mode = cfg.get("mode", MODE_OPEN)
        if self.mode not in (MODE_OPEN, MODE_SINGLE):
            raise ValueError("board_lease mode must be open|single_user")
        self.persistent = bool(cfg.get("persistent", True))
        self.owner_peers = cfg.get("owner_peers")
        self._rng = random.Random(cfg["seed"]) if cfg.get("seed") is not None else None
        self.holder: Optional[Dict[str, Any]] = None
        self.queue: List[Dict[str, Any]] = []
        self.resv: Optional[Dict[str, Any]] = None        # {"id","until"}
        self.hold_until = 0.0                              # local hold (panel break)
        self.suspended_until: Optional[float] = None
        self._history: List[Dict[str, Any]] = []
        self.access_armed = False

    # ---- time -------------------------------------------------------------- #
    def now(self) -> float:
        return self._clock() if self._clock is not None else self._t

    def advance(self, seconds: float) -> None:
        """Move the internal clock (not with an injected ``clock``) and run expiries."""
        if self._clock is not None:
            raise RuntimeError("advance(): the model runs on an injected clock")
        self._t += seconds
        self._tick()

    @property
    def label(self) -> str:
        sh = self._shell
        if self.cfg.get("label"):
            return self.cfg["label"]
        ident = getattr(sh, "identity", None)
        if ident is not None:
            return ident.running["label"]
        return getattr(sh, "board", "")

    # ---- helpers ----------------------------------------------------------- #
    def _token(self) -> str:
        return "%032x" % (self._rng.getrandbits(128) if self._rng else secrets.randbits(128))

    def _id(self) -> str:
        return "%08x" % (self._rng.getrandbits(32) if self._rng else secrets.randbits(32))

    def _ev(self, ev: str, who: str = "", info: str = "") -> None:
        self._history.append({"ev": ev, "who": who, "at": self.now(), "info": info})
        del self._history[:-HISTORY_N]

    def _left(self) -> int:
        h = self.holder
        if h is None:
            return 0
        if self.suspended_until is not None:
            return max(0, int(h["remaining"]))
        return max(0, int(h["deadline"] - self.now()))

    def _is_holder_tok(self, tok: Any) -> bool:
        return self.holder is not None and tok == self.holder["token"]

    def _find(self, who: str, peer: Optional[str]) -> Optional[Dict[str, Any]]:
        """A waiter is keyed by ``who``; the session (``peer``) only breaks a tie between two
        live waiters with the same ``who``. A re-poll from a new connection keeps its place
        (and the entry follows the new session)."""
        same = [w for w in self.queue if w["who"] == who]
        w = next((x for x in same if x["peer"] == peer), same[0] if same else None)
        if w is not None:
            w["peer"] = peer
        return w

    def _vacate(self, ev: str, who: str = "", info: str = "", reserve: bool = True) -> None:
        """The holder goes. ``who`` is the ACTOR ("" = the board: expiry, idle, cap)."""
        self.holder = None
        self.suspended_until = None
        self._ev(ev, who, info)
        if reserve and self.queue:
            self.resv = {"id": self.queue[0]["id"], "until": self.now() + REQUEST_WINDOW_S}
            self._ev("reserve", "", self.queue[0]["who"])
        else:
            self.resv = None

    def _cap_deadline(self) -> float:
        return self.holder["t0"] + CAP_S

    def _set_deadline(self, seconds: float) -> None:
        h = self.holder
        h["deadline"] = self.now() + seconds
        if h.get("keep_until") is not None:             # R9: a Keep is binding
            h["deadline"] = min(h["deadline"], h["keep_until"])
        if self.queue and h["deadline"] > self._cap_deadline():
            h["deadline"] = self._cap_deadline()

    def _tick(self) -> None:
        """Run every time-driven transition up to now."""
        now = self.now()
        # reservation passes to the next waiter after 120 s
        while self.resv is not None and now >= self.resv["until"]:
            ids = [w["id"] for w in self.queue]
            if self.resv["id"] not in ids:
                self.resv = None
                break
            i = ids.index(self.resv["id"])
            lapsed = self.queue.pop(i)                  # R5: the lapsed head is DROPPED
            self._ev("cancel", lapsed["who"], "lapsed")
            if i < len(self.queue):                     # the next head: a fresh 120 s
                self.resv = {"id": self.queue[i]["id"], "until": self.resv["until"] + REQUEST_WINDOW_S}
                self._ev("reserve", "", self.queue[i]["who"])
            else:
                self.resv = None
        h = self.holder
        if h is None:
            return
        if self.suspended_until is not None:
            if now >= self.suspended_until:
                self._vacate("expire", "", "reclaim window")
            return
        if self.queue and h["deadline"] > self._cap_deadline():
            h["deadline"] = self._cap_deadline()
        if now >= h["deadline"]:
            # R11: cap iff the deadline reached the cap instant with somebody waiting
            self._vacate("cap" if self.queue and h["deadline"] >= self._cap_deadline() else "expire")
        elif now >= h["last_act"] + IDLE_S:
            self._vacate("idle")

    def _show(self, tok: Any = None, peer: Optional[str] = None) -> Reply:
        now = self.now()
        h = self.holder
        holder = None
        if h is not None:
            holder = {"who": h["who"], "app": h["app"], "held_s": int(now - h["t0"]),
                      "expires_in_s": self._left(), "you": bool(tok) and tok == h["token"]}
        queue = [{"id": w["id"], "who": w["who"], "msg": w["msg"] if w["req_t"] is not None else "",
                  "age_s": int(now - w["t_enq"])} for w in self.queue]
        return {"ok": True, "op": "lease", "act": "show", "mode": self.mode,
                "persistent": self.persistent, "owner": self._is_owner(peer), "holder": holder, "queue": queue,
                "local_hold_s": max(0, int(self.hold_until - now)) if self.hold_until > now else 0,
                "reclaim_s": (max(0, int(self.suspended_until - now))
                              if self.suspended_until is not None else 0)}

    def _grant(self, who: str, app: str, ttl: int, peer: Optional[str], ev: str = "grant") -> Reply:
        now = self.now()
        self.holder = {"who": who, "app": app, "peer": peer, "token": self._token(), "t0": now,
                       "ttl": ttl, "deadline": now, "last_act": now, "keep_until": None}
        self._set_deadline(ttl)
        self._ev(ev, who)
        return {"ok": True, "op": "lease", "act": "acquire", "granted": True,
                "token": self.holder["token"], "expires_in_s": self._left()}

    # ---- test / simulation hooks ------------------------------------------- #
    def reboot(self) -> None:
        """A simulated board reboot: the mode survives on a card, the live lease comes back
        SUSPENDED for ``reclaim_s``; the queue and the local hold are lost."""
        # R1: the panel local hold SURVIVES a reboot (a remote reboot must not bypass the panel)
        self.queue, self.resv, self.access_armed = [], None, False
        if not self.persistent:
            self.mode, self.holder, self.suspended_until = MODE_OPEN, None, None
            return
        if self.holder is not None:
            self.holder["remaining"] = self._left()
            self.suspended_until = self.now() + RECLAIM_S
            self._ev("suspend", "", self.holder["who"])

    def unclaim(self) -> None:
        """``mps3-unclaim``: clears the mode and the lease."""
        self.mode, self.holder, self.queue, self.resv, self.suspended_until = MODE_OPEN, None, [], None, None
        self._ev("clear")

    def access_arm(self) -> None:
        """The override attempt starts at the panel (event ``access_arm``)."""
        self.access_armed = True
        self._panel_event("access_arm")

    def access_cancel(self) -> None:
        self.access_armed = False

    def local_break(self) -> Reply:
        """What the touchscreen override's commit does: the lease ends, the mode is ``open``,
        ``single_user`` is refused for ``LOCAL_HOLD_S``; the queue is kept (not promoted)."""
        self._tick()
        self.access_armed = False
        h = self.holder
        self.holder, self.suspended_until, self.resv = None, None, None
        self._ev("break", "", h["who"] if h else "")
        if self.mode != MODE_OPEN:
            self.mode = MODE_OPEN
        self.hold_until = self.now() + LOCAL_HOLD_S
        self._panel_event("lease_break")
        return self._show()

    def _panel_event(self, k: str) -> None:
        panel = getattr(self._shell, "panel", None)
        if panel is not None:
            panel.tap(k)

    def identify_lease(self) -> Reply:
        """The identify ``lease`` object (never a token)."""
        self._tick()
        r: Reply = {"mode": self.mode, "held": self.holder is not None}
        if self.holder is not None:
            r["who"], r["left_s"] = self.holder["who"], self._left()
        r["queue"] = len(self.queue)
        return r

    # ---- the gate ---------------------------------------------------------- #
    def gate(self, verb: str, request: Dict[str, Any], peer: Optional[str]) -> Optional[Reply]:
        """None to allow a mutating ``verb``; else the refusal reply. Order: panel access,
        claim, lease (single-user only). ``request`` may be any 6900 request; a READ row
        (``mutation_verb`` None and not an access row) is allowed."""
        self._tick()
        sh = self._shell
        if request.get("op") != "hello" and "lease" in request and not isinstance(request["lease"], str):
            return {"ok": False, "err": "bad args"}
        acc = _access_row(request)
        mverb, _ = mutation_verb(request)
        if acc is not None and self.access_armed and "panel_access" in sh.features:
            return _fail(f"{acc} refused: board access in progress at the panel", "busy_access")
        if mverb is None:
            return None
        if sh._claim_locked(peer):
            return _fail(f"{mverb} locked: board claimed (use ssh)", "locked")
        if self.mode != MODE_SINGLE:
            return None
        tok = request.get("lease")
        h = self.holder
        if h is None:
            if tok is None:
                return _fail(f"{mverb} leased: single-user mode (acquire the board lease first)",
                             "lease_required")
            return _fail(f"{mverb} leased: lease token not current", "bad_token")
        if self.suspended_until is None and _is_token(tok) and tok == h["token"]:
            h["last_act"] = self.now()
            return None
        if tok is None or self.suspended_until is not None:
            return _fail(f"{mverb} leased: held by {h['who']} ({self._left()} s left)", "leased")
        return _fail(f"{mverb} leased: lease token not current", "bad_token")

    # ---- the verb ----------------------------------------------------------- #
    def op(self, request: Dict[str, Any], peer: Optional[str]) -> Reply:
        """The ``lease`` verb."""
        act = request.get("act")
        if not isinstance(act, str) or act not in ACTS:
            return _fail("invalid act: " + "|".join(ACTS), "invalid")
        self._tick()
        if act not in ("show", "history") and self._shell._claim_locked(peer):
            return _fail("lease locked: board claimed (use ssh)", "locked")
        tok = request.get("lease")
        if act == "show":
            return self._show(tok, peer)
        if act == "history":
            n = request.get("n", HISTORY_N)
            if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= HISTORY_N:
                return _fail("invalid n: 1-8", "invalid")
            now = self.now()
            return {"ok": True, "op": "lease", "act": "history",
                    "events": [{"ev": e["ev"], "who": e["who"], "age_s": int(now - e["at"]),
                                "info": e["info"]} for e in self._history[-n:]]}
        if act == "mode" and request.get("mode") == MODE_SINGLE and not self._is_owner(peer):
            return _fail("lease mode: only the owner key can turn single-user on", "denied")
        err = self._validate(act, request)
        if err is not None:
            return err
        if self.access_armed and "panel_access" in self._shell.features:
            return _fail("lease refused: board access in progress at the panel", "busy_access")
        return getattr(self, f"_act_{act}")(request, peer)

    def _validate(self, act: str, r: Dict[str, Any]) -> Optional[Reply]:
        def bad(field: str) -> Reply:
            return _fail(f"invalid {field}", "invalid")
        if "lease" in r and not isinstance(r["lease"], str):
            return {"ok": False, "err": "bad args"}
        if act in ("acquire", "request"):
            who = r.get("who")
            if not isinstance(who, str) or not who or len(who) > 24:
                return bad("who")
        if act in ("acquire", "mode") and "ttl_s" in r or act == "acquire":
            if act == "acquire" and not isinstance(r.get("app", ""), str):
                return bad("app")
            ttl = r.get("ttl_s", DEFAULT_TTL_S)
            if not isinstance(ttl, int) or isinstance(ttl, bool) or not TTL_MIN <= ttl <= TTL_MAX:
                return bad("ttl_s")
        if act == "heartbeat" and r.get("ttl_s") is not None:
            ttl = r["ttl_s"]
            if not isinstance(ttl, int) or isinstance(ttl, bool) or not TTL_MIN <= ttl <= TTL_MAX:
                return bad("ttl_s")
        if act == "request":
            msg = r.get("msg", "")
            if not isinstance(msg, str) or not msg or len(msg) > 48:
                return bad("msg")
        if act in ("respond", "cancel") and not isinstance(r.get("id"), str):
            return bad("id")
        if act == "cancel" and "who" in r and (not isinstance(r["who"], str) or not r["who"]
                                               or len(r["who"]) > 24):
            return bad("who")
        if act == "respond":
            if not isinstance(r.get("accept"), bool):
                return bad("accept")
            if not r["accept"]:
                m = r.get("minutes")
                if not isinstance(m, int) or isinstance(m, bool) or not 5 <= m <= 60:
                    return bad("minutes")
        if act == "revoke" and not isinstance(r.get("confirm"), str):
            return bad("confirm")
        if act == "mode" and r.get("mode") not in (MODE_OPEN, MODE_SINGLE):
            return bad("mode")
        return None

    def _is_owner(self, peer: Optional[str]) -> bool:
        """This caller presented the owner key. An unresolvable caller (no peer) is not."""
        return peer is not None and (self.owner_peers is None or peer in self.owner_peers)

    def _owner_name(self, peer: Optional[str]) -> str:
        return f"owner#{(peer or 'local')[-4:]}"

    def _holder_check(self, act: str, r: Dict[str, Any]) -> Optional[Reply]:
        tok = r.get("lease")
        if tok is None:
            return _fail(f"lease {act}: not the holder", "not_holder")
        if not _is_token(tok) or not self._is_holder_tok(tok):
            return _fail(f"lease {act}: lease token not current", "bad_token")
        return None

    def _act_acquire(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        who, app, ttl = r["who"], r.get("app", "")[:12], r.get("ttl_s", DEFAULT_TTL_S)   # R17: clip
        h = self.holder
        if h is not None and (h["who"] == who or self._is_holder_tok(r.get("lease"))):
            return _fail("lease already held by you", "lease_held")     # R12: any who
        if h is None:
            mine = self._find(who, peer)
            if self.resv is not None:
                if mine is None or mine["id"] != self.resv["id"]:
                    return self._enqueue(who, peer)
            if mine is not None:
                self.queue.remove(mine)
            self.resv = None
            return self._grant(who, app, ttl, peer)
        return self._enqueue(who, peer, app, ttl)

    def _enqueue(self, who: str, peer: Optional[str], app: str = "", ttl: int = DEFAULT_TTL_S) -> Reply:
        w = self._find(who, peer)
        if w is None:
            if len(self.queue) >= QUEUE_MAX:
                return _fail(f"lease queue full ({QUEUE_MAX} waiting)", "queue_full")
            w = {"id": self._id(), "who": who, "peer": peer, "msg": "", "req_t": None,
                 "t_enq": self.now(), "app": app, "ttl": ttl}
            self.queue.append(w)
            self._ev("queue", who)
        return {"ok": True, "op": "lease", "act": "acquire", "granted": False,
                "position": self.queue.index(w) + 1, "id": w["id"], "code": "lease_held"}

    def _act_heartbeat(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        err = self._holder_check("heartbeat", r)
        if err:
            return err
        h = self.holder
        if self.suspended_until is not None:
            self.suspended_until = None
            h["deadline"] = self.now() + h.pop("remaining")
            self._ev("reclaim", h["who"])
        h["last_act"] = self.now()
        self._set_deadline(r.get("ttl_s") or h["ttl"])
        if r.get("ttl_s"):
            h["ttl"] = r["ttl_s"]
        self._ev("renew", h["who"])
        rep = self._show(r["lease"], peer)
        rep["act"] = "heartbeat"
        return rep

    def _act_release(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        err = self._holder_check("release", r)
        if err:
            return err
        self._vacate("release", self.holder["who"])
        return {"ok": True, "op": "lease", "act": "release"}

    def _act_request(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        if self.holder is None:
            return _fail("lease request: nobody holds the lease", "invalid")
        who = r["who"]
        if self.holder["who"] == who:
            return _fail("lease already held by you", "lease_held")
        w = self._find(who, peer)
        if w is not None and w["req_t"] is not None:    # R6: same id, nothing changes
            return {"ok": True, "op": "lease", "act": "request", "id": w["id"]}
        if w is None:
            if len(self.queue) >= QUEUE_MAX:
                return _fail(f"lease queue full ({QUEUE_MAX} waiting)", "queue_full")
            w = {"id": self._id(), "who": who, "peer": peer, "msg": "", "req_t": None,
                 "t_enq": self.now(), "app": "", "ttl": DEFAULT_TTL_S}
            self.queue.append(w)
            self._ev("queue", who)
        w["msg"], w["req_t"] = r.get("msg", ""), self.now()
        self._ev("request", who, w["msg"])
        return {"ok": True, "op": "lease", "act": "request", "id": w["id"]}

    def _act_respond(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        err = self._holder_check("respond", r)
        if err:
            return err
        w = next((x for x in self.queue if x["id"] == r["id"] and x["req_t"] is not None), None)
        if w is None:
            return _fail("invalid id: no such request", "invalid")
        if r["accept"]:
            self._vacate("give", self.holder["who"], w["who"])
            return {"ok": True, "op": "lease", "act": "respond"}
        w["req_t"], w["msg"] = None, ""
        self.holder["keep_until"] = self.now() + r["minutes"] * 60
        self._set_deadline(r["minutes"] * 60)
        self.holder["last_act"] = self.now()
        self._ev("keep", self.holder["who"], f"keep {r['minutes']}")
        return {"ok": True, "op": "lease", "act": "respond", "expires_in_s": self._left()}

    def _act_cancel(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        w = next((x for x in self.queue if x["id"] == r["id"]), None)
        if w is None:
            return _fail("invalid id: no such request", "invalid")
        if (w["who"] != r["who"]) if isinstance(r.get("who"), str) else (w["peer"] != peer):
            return _fail("invalid id: no such request", "invalid")     # R14: no id oracle
        was_resv = self.resv is not None and self.resv["id"] == w["id"]
        i = self.queue.index(w)
        self.queue.remove(w)
        self._ev("cancel", w["who"])
        if was_resv:
            if i < len(self.queue):
                self.resv = {"id": self.queue[i]["id"], "until": self.resv["until"]}
            else:
                self.resv = None
        return {"ok": True, "op": "lease", "act": "cancel"}

    def _act_revoke(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        if self.holder is None or not self.queue or self.queue[0]["peer"] != peer:
            return _fail("lease revoke: not the queue head", "not_holder")
        head = self.queue[0]
        if r["confirm"] != self.label:
            return _fail("lease revoke: confirm must be the board's label", "invalid")
        if head["req_t"] is None:
            return _fail("lease revoke: no unanswered request", "busy")
        left = REQUEST_WINDOW_S - int(self.now() - head["req_t"])
        if left > 0:
            return _fail(f"lease revoke: the holder has {left} s to answer", "busy")
        self._vacate("revoke", head["who"], "from " + self.holder["who"])
        return {"ok": True, "op": "lease", "act": "revoke"}

    def _act_mode(self, r: Dict[str, Any], peer: Optional[str]) -> Reply:
        mode = r["mode"]
        is_owner = self._is_owner(peer)
        if mode == MODE_SINGLE:
            now = self.now()
            if now < self.hold_until:
                return _fail(f"lease mode: ended at the panel {int(LOCAL_HOLD_S - (self.hold_until - now))} s ago "
                             f"(wait {int(self.hold_until - now)} s)", "local_hold")
            if (self.mode == MODE_SINGLE and self.holder is not None
                    and not self._is_holder_tok(r.get("lease"))):
                return _fail("lease mode: single-user is already on", "lease_held")     # R7
            was_on = self.mode == MODE_SINGLE
            self.mode = MODE_SINGLE
            if not was_on:
                self._ev("mode_on", self._owner_name(peer))
            h = self.holder
            if h is not None and self._is_holder_tok(r.get("lease")):
                if self.suspended_until is not None:                                     # R8
                    self.suspended_until = None
                    h["deadline"] = self.now() + h.pop("remaining")
                    h["last_act"] = self.now()
                    self._ev("reclaim", h["who"])
                grant: Reply = {"token": h["token"], "expires_in_s": self._left()}
            else:
                if h is not None:
                    self._vacate("revoke", self._owner_name(peer), "from " + h["who"], reserve=False)
                g = self._grant(self._owner_name(peer), "", r.get("ttl_s", DEFAULT_TTL_S), peer)
                grant = {"token": g["token"], "expires_in_s": g["expires_in_s"]}
            rep = self._show(grant["token"], peer)
            rep["act"] = "mode"
            rep.update(grant)
            return rep
        # off: owner or holder
        if not (is_owner or self._is_holder_tok(r.get("lease"))):
            return _fail("lease mode: only the owner or the holder can turn single-user off", "denied")
        if self.mode == MODE_SINGLE:
            self.mode = MODE_OPEN
            self._ev("mode_off", self.holder["who"] if self._is_holder_tok(r.get("lease"))
                     else self._owner_name(peer))
        rep = self._show(r.get("lease"), peer)
        rep["act"] = "mode"
        return rep
